<?php
/**
 * List-style card (horizontal thumbnail + title + meta)
 * Used in magazine and featured-list layouts.
 *
 * @package NewsPress
 */
?>
<article class="np-card np-card-list">
    <?php if ( has_post_thumbnail() ) : ?>
    <a href="<?php the_permalink(); ?>" class="np-card-list-thumb" tabindex="-1" aria-hidden="true">
        <?php the_post_thumbnail( 'newspress-card', array( 'loading' => 'lazy', 'decoding' => 'async', 'alt' => esc_attr( get_the_title() ) ) ); ?>
    </a>
    <?php endif; ?>
    <div class="np-card-list-body">
        <?php if ( get_theme_mod( 'np_show_cats', true ) ) newspress_category_badge(); ?>
        <h3 class="np-card-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>
        <?php newspress_post_meta(); ?>
    </div>
</article>
