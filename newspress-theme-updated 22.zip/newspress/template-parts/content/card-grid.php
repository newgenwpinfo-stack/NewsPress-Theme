<?php
/**
 * Post Card Template Part
 * - Skips posts with no title
 * - No image = text-only card (no placeholder, no blank space)
 *
 * @package NewsPress
 */

// Never render a card with no title
if ( ! get_the_title() ) {
    return;
}

$badge_pos   = get_theme_mod( 'np_badge_position', 'above-title' );
$has_thumb   = has_post_thumbnail();
$thumb_ratio = get_theme_mod( 'np_card_image_ratio', '16-9' ); // 16-9 | 4-3 | 1-1 | 3-2
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $has_thumb ? 'np-card' : 'np-card np-card-no-thumb' ); ?>>

    <?php if ( $has_thumb ) : ?>
    <div class="np-card-thumb np-ratio-<?php echo esc_attr( $thumb_ratio ); ?><?php echo $badge_pos === 'over-image' ? ' np-card-thumb-has-badge' : ''; ?>">
        <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
            <?php the_post_thumbnail( 'newspress-card', array(
                'loading'  => 'lazy',
                'decoding' => 'async',
                'alt'      => esc_attr( get_the_title() ),
                'width'    => 420,
                'height'   => 280,
                // Accurate sizes for 3-col → 2-col → 1-col grid breakpoints
                'sizes'    => '(max-width: 480px) 95vw, (max-width: 768px) 45vw, (max-width: 1200px) 30vw, 360px',
            ) ); ?>
        </a>
        </a>
        <?php if ( $badge_pos === 'over-image' ) : ?>
        <div class="np-card-thumb-badge"><?php newspress_category_badge(); ?></div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="np-card-body">
        <?php if ( $badge_pos === 'above-title' || ( ! $has_thumb && $badge_pos === 'over-image' ) ) : ?>
            <?php newspress_category_badge(); ?>
        <?php endif; ?>

        <h2 class="np-card-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>

        <?php if ( $badge_pos === 'below-title' ) : ?>
            <?php newspress_category_badge(); ?>
        <?php endif; ?>

        <?php if ( get_theme_mod( 'np_show_excerpt', true ) ) : ?>
        <p class="np-card-excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
        <?php endif; ?>

        <?php if ( $badge_pos === 'above-meta' ) : ?>
            <?php newspress_category_badge(); ?>
        <?php endif; ?>

        <?php newspress_post_meta(); ?>
    </div>

</article>
