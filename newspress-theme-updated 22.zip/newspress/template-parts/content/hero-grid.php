<?php
/**
 * Hero – Grid Layout
 *
 * Performance notes:
 *  - Main hero image: eager + fetchpriority="high" (LCP element)
 *  - Explicit sizes attribute overrides WordPress default "100vw"
 *    so browsers fetch the correctly sized image for the 2/3-width column
 *  - Side images: eager (above fold) but normal priority
 *  - Both images have width+height from registered size for CLS=0
 *  - Missing thumbnails degrade gracefully — no empty containers
 *
 * @package NewsPress
 */

global $np_hero_posts;
$posts = ! empty( $np_hero_posts ) ? $np_hero_posts : array();
if ( empty( $posts ) ) return;

$main       = $posts[0];
$sides      = array_slice( $posts, 1, 2 );
$date_fmt   = get_theme_mod( 'np_date_format', 'M j, Y' );

// Registered image dimensions — used for explicit width/height (CLS prevention)
$hero_w = 1280; $hero_h = 720;  // matches add_image_size('newspress-hero', ...)
$card_w = 420;  $card_h = 280;  // matches add_image_size('newspress-card', ...)
?>
<section class="np-featured-section" aria-label="<?php esc_attr_e( 'Featured Stories', 'newspress' ); ?>">
    <div class="np-hero-grid">

        <!-- Main Hero Post (LCP element) -->
        <div class="np-hero-main">
            <a href="<?php echo esc_url( get_permalink( $main ) ); ?>"
               aria-label="<?php echo esc_attr( get_the_title( $main ) ); ?>"
               tabindex="-1" aria-hidden="true">
                <?php if ( has_post_thumbnail( $main ) ) :
                    // sizes: hero occupies ~66vw desktop, 100vw mobile
                    // This prevents loading 1280px for a 530px displayed column
                    echo get_the_post_thumbnail( $main, 'newspress-hero', array(
                        'loading'        => 'eager',
                        'fetchpriority'  => 'high',
                        'decoding'       => 'sync',
                        'alt'            => esc_attr( get_the_title( $main ) ),
                        'width'          => $hero_w,
                        'height'         => $hero_h,
                        'sizes'          => '(max-width: 768px) 100vw, (max-width: 1200px) 60vw, 800px',
                    ) );
                else : ?>
                    <div class="np-hero-placeholder" aria-hidden="true"
                         style="width:100%;height:400px;background:var(--np-bg-alt);display:flex;align-items:center;justify-content:center;">
                        <span style="font-size:3rem;opacity:.3;">&#x1F4F0;</span>
                    </div>
                <?php endif; ?>
            </a>
            <div class="np-post-overlay">
                <?php
                $cats = get_the_category( $main->ID );
                if ( $cats ) {
                    echo '<a href="' . esc_url( get_category_link( $cats[0]->term_id ) ) . '" class="np-category-badge">' . esc_html( $cats[0]->name ) . '</a>';
                }
                ?>
                <h2 class="np-post-title">
                    <a href="<?php echo esc_url( get_permalink( $main ) ); ?>"><?php echo esc_html( get_the_title( $main ) ); ?></a>
                </h2>
                <p class="np-post-meta">
                    <span><?php echo esc_html( get_the_author_meta( 'display_name', $main->post_author ) ); ?></span> &mdash;
                    <time datetime="<?php echo esc_attr( get_the_date( 'c', $main ) ); ?>"><?php echo esc_html( get_the_date( $date_fmt, $main ) ); ?></time>
                </p>
            </div>
        </div>

        <!-- Side Posts (above fold, eager, not LCP) -->
        <?php foreach ( $sides as $side ) : ?>
        <div class="np-hero-side">
            <a href="<?php echo esc_url( get_permalink( $side ) ); ?>"
               aria-label="<?php echo esc_attr( get_the_title( $side ) ); ?>"
               tabindex="-1" aria-hidden="true">
                <?php if ( has_post_thumbnail( $side ) ) :
                    echo get_the_post_thumbnail( $side, 'newspress-card', array(
                        'loading'  => 'eager',
                        'decoding' => 'async',
                        'alt'      => esc_attr( get_the_title( $side ) ),
                        'width'    => $card_w,
                        'height'   => $card_h,
                        'sizes'    => '(max-width: 768px) 100vw, (max-width: 1200px) 30vw, 400px',
                    ) );
                else : ?>
                    <div class="np-hero-placeholder" aria-hidden="true"
                         style="width:100%;height:188px;background:var(--np-bg-alt);"></div>
                <?php endif; ?>
            </a>
            <div class="np-post-overlay">
                <?php
                $cats = get_the_category( $side->ID );
                if ( $cats ) {
                    echo '<a href="' . esc_url( get_category_link( $cats[0]->term_id ) ) . '" class="np-category-badge">' . esc_html( $cats[0]->name ) . '</a>';
                }
                ?>
                <h3 class="np-post-title">
                    <a href="<?php echo esc_url( get_permalink( $side ) ); ?>"><?php echo esc_html( get_the_title( $side ) ); ?></a>
                </h3>
                <p class="np-post-meta">
                    <time datetime="<?php echo esc_attr( get_the_date( 'c', $side ) ); ?>"><?php echo esc_html( get_the_date( $date_fmt, $side ) ); ?></time>
                </p>
            </div>
        </div>
        <?php endforeach; ?>

    </div>
</section>
