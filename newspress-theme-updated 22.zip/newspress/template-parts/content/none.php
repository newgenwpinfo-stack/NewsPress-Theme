<?php
/**
 * No Results Template
 *
 * @package NewsPress
 */
?>
<section class="np-no-results">
    <h2><?php esc_html_e('Nothing Found','newspress'); ?></h2>
    <p><?php esc_html_e('Sorry, but nothing matched your search terms. Please try again with some different keywords.','newspress'); ?></p>
    <?php get_search_form(); ?>
</section>
