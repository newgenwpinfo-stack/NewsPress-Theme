<?php
/**
 * Homepage Category Section Block
 *
 * Renders one category block on the homepage builder.
 * Called by newspress_render_home_section() in template-functions.php
 *
 * Expects $args array:
 *   cat_id    — category ID (0 = latest posts)
 *   layout    — grid-2 | grid-3 | grid-4 | list | featured-list | magazine
 *   count     — number of posts
 *   show_more — bool
 *   title     — override section title
 *
 * @package NewsPress
 */

if ( ! isset( $args ) ) return;

$cat_id    = isset( $args['cat_id'] )    ? (int) $args['cat_id']           : 0;
$layout    = isset( $args['layout'] )    ? sanitize_key( $args['layout'] ) : 'grid-3';
$count     = isset( $args['count'] )     ? (int) $args['count']            : 6;
$show_more = isset( $args['show_more'] ) ? (bool) $args['show_more']       : true;
$title_override = isset( $args['title'] ) ? $args['title']                 : '';
$tab_cats   = isset( $args['tab_cats']   ) ? (array) $args['tab_cats']      : array();
$show_pager = isset( $args['show_pager'] ) ? (bool) $args['show_pager']     : false;

// Determine section title and link
if ( $cat_id ) {
    $category  = get_category( $cat_id );
    $sec_title = $title_override ?: ( $category ? $category->name : '' );
    $sec_link  = $category ? get_category_link( $cat_id ) : '';
} else {
    $sec_title = $title_override ?: __( 'Latest News', 'newspress' );
    $sec_link  = get_permalink( get_option( 'page_for_posts' ) );
}

// Use pre-built query if passed (avoids double query on default homepage)
if ( isset( $args['_query'] ) && $args['_query'] instanceof WP_Query ) {
    $q = $args['_query'];
} else {
    // Cache section queries: key = cat_id + count + layout
    $cache_key = 'np_section_' . (int) $cat_id . '_' . (int) $count;
    $cached_ids = get_transient( $cache_key );

    if ( false === $cached_ids ) {
        $q_args = array(
            'post_type'              => 'post',
            'post_status'            => 'publish',
            'posts_per_page'         => $count,
            'no_found_rows'          => true,
            'ignore_sticky_posts'    => true,
            'fields'                 => 'ids',
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        );
        if ( $cat_id ) {
            $q_args['cat'] = $cat_id;
        }
        $id_query   = new WP_Query( $q_args );
        $cached_ids = $id_query->posts ?: array();
        set_transient( $cache_key, $cached_ids, 5 * MINUTE_IN_SECONDS );
    }

    if ( empty( $cached_ids ) ) return;

    // Re-query by IDs so post objects are available for template parts
    $q = new WP_Query( array(
        'post_type'           => 'post',
        'post__in'            => $cached_ids,
        'orderby'             => 'post__in',
        'posts_per_page'      => count( $cached_ids ),
        'no_found_rows'       => true,
        'ignore_sticky_posts' => true,
    ) );
}
if ( ! $q->have_posts() ) return;

$grid_cls = newspress_grid_class( $layout );
?>
<section class="np-home-section np-section-<?php echo esc_attr( $layout ); ?>" aria-labelledby="sec-<?php echo esc_attr( $cat_id ?: 'latest' ); ?>">

    <?php newspress_section_heading( $sec_title, $show_more ? $sec_link : '', __( 'View all', 'newspress' ), $tab_cats ); ?>

    <?php if ( $layout === 'magazine' ) : ?>
    <?php /* Magazine: 1 large left + stacked small right */ ?>
    <div class="np-magazine-block">
        <div class="np-magazine-main">
            <?php $q->the_post(); get_template_part( 'template-parts/content/card', 'grid' ); ?>
        </div>
        <div class="np-magazine-side">
            <?php while ( $q->have_posts() ) : $q->the_post(); ?>
                <?php get_template_part( 'template-parts/content/card', 'list' ); ?>
            <?php endwhile; ?>
        </div>
    </div>

    <?php elseif ( $layout === 'featured-list' ) : ?>
    <?php /* Featured-list: 1 big hero + horizontal list below */ ?>
    <div class="np-featured-list-block">
        <?php $q->the_post(); ?>
        <div class="np-featured-list-hero">
            <?php get_template_part( 'template-parts/content/card', 'grid' ); ?>
        </div>
        <?php if ( $q->have_posts() ) : ?>
        <div class="np-featured-list-rest">
            <?php while ( $q->have_posts() ) : $q->the_post(); ?>
                <?php get_template_part( 'template-parts/content/card', 'list' ); ?>
            <?php endwhile; ?>
        </div>
        <?php endif; ?>
    </div>

    <?php elseif ( $layout === 'list' ) : ?>
    <ul class="np-posts-list">
        <?php while ( $q->have_posts() ) : $q->the_post(); ?>
            <?php get_template_part( 'template-parts/content/card', 'grid' ); ?>
        <?php endwhile; ?>
    </ul>

    <?php else : ?>
    <div class="<?php echo esc_attr( $grid_cls ); ?>">
        <?php while ( $q->have_posts() ) : $q->the_post(); ?>
            <?php if ( ! get_the_title() ) continue; ?>
            <?php get_template_part( 'template-parts/content/card', 'grid' ); ?>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>

    <?php if ( $show_pager ) : ?>
    <div class="np-section-footer">
        <div class="np-section-pager">
            <button aria-label="<?php esc_attr_e('Previous','newspress'); ?>">&#8249;</button>
            <button aria-label="<?php esc_attr_e('Next','newspress'); ?>">&#8250;</button>
        </div>
    </div>
    <?php endif; ?>

</section>
<?php
wp_reset_postdata();
