<?php
/**
 * Sidebar Template
 *
 * @package NewsPress
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) return;
?>
<aside id="secondary" class="np-sidebar" role="complementary" aria-label="<?php esc_attr_e( 'Sidebar', 'newspress' ); ?>">
    <?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>
