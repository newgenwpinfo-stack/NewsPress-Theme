<?php
/**
 * Comments Template
 *
 * @package NewsPress
 */

if ( post_password_required() ) return;
?>

<div id="comments" class="np-comments-area">

    <?php if ( have_comments() ) : ?>
    <h3 class="np-comments-title">
        <?php printf( _n('%1$s Comment on &ldquo;%2$s&rdquo;', '%1$s Comments on &ldquo;%2$s&rdquo;', get_comments_number(), 'newspress'),
            number_format_i18n( get_comments_number() ), get_the_title() ); ?>
    </h3>

    <ol class="comment-list">
        <?php wp_list_comments( [
            'style'       => 'ol',
            'short_ping'  => true,
            'avatar_size' => 50,
        ] ); ?>
    </ol>

    <?php the_comments_navigation(); ?>

    <?php endif; ?>

    <?php if ( ! comments_open() && '0' !== get_comments_number() ) : ?>
    <p class="no-comments"><?php esc_html_e('Comments are closed.','newspress'); ?></p>
    <?php endif; ?>

    <?php
    comment_form( [
        'class_form'           => 'np-comment-form',
        'class_submit'         => 'np-btn',
        'submit_button'        => '<input type="submit" name="%1$s" id="%2$s" class="%3$s" value="%4$s">',
        'title_reply'          => __( 'Leave a Comment', 'newspress' ),
        'title_reply_before'   => '<h3 class="np-comment-form-title">',
        'title_reply_after'    => '</h3>',
        'comment_notes_before' => '',
    ] );
    ?>
</div>
