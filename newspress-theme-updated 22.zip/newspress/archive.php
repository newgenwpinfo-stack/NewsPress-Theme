<?php
/**
 * Archive / Category Template
 *
 * Layout controlled by:
 *  np_archive_layout   — grid-2 | grid-3 | grid-4 | list
 *  np_archive_sidebar  — right | left | none
 *  np_archive_show_desc, np_archive_show_count
 *
 * @package NewsPress
 */

get_header();

$layout      = newspress_archive_layout();
$grid_cls    = newspress_grid_class( $layout );
$show_desc   = get_theme_mod( 'np_archive_show_desc', true );
$show_count  = get_theme_mod( 'np_archive_show_count', true );
$show_thumb  = get_theme_mod( 'np_archive_show_thumb', true );
$show_excerpt= get_theme_mod( 'np_archive_show_excerpt', true );
?>
<div class="np-container">
    <?php newspress_breadcrumbs(); ?>

    <header class="np-archive-header">
        <div class="np-archive-title-wrap">
            <?php
            if ( is_category() ) {
                $cat_id  = get_queried_object_id();
                $cat_img = get_term_meta( $cat_id, 'np_cat_image', true );
                if ( $cat_img ) {
                    echo '<div class="np-archive-cover" style="background-image:url(' . esc_url( $cat_img ) . ')"></div>';
                }
            }
            the_archive_title( '<h1 class="np-archive-title">', '</h1>' );
            ?>
            <?php if ( $show_desc ) the_archive_description( '<div class="np-archive-description">', '</div>' ); ?>
            <?php if ( $show_count && $wp_query->found_posts ) : ?>
            <p class="np-archive-count">
                <?php
                /* translators: %d = number of posts */
                printf( esc_html( _n( '%d article', '%d articles', $wp_query->found_posts, 'newspress' ) ), $wp_query->found_posts );
                ?>
            </p>
            <?php endif; ?>
        </div>
    </header>

    <div class="<?php echo esc_attr( newspress_archive_content_class() ); ?>">
        <div class="np-main">

            <?php if ( $layout === 'list' ) : ?>
            <ul class="np-posts-list">
            <?php else : ?>
            <div class="<?php echo esc_attr( $grid_cls ); ?>">
            <?php endif; ?>

            <?php if ( have_posts() ) :
                while ( have_posts() ) :
                    the_post();
                    if ( ! get_the_title() ) continue;
                    get_template_part( 'template-parts/content/card', 'grid' );
                endwhile;
            else :
                get_template_part( 'template-parts/content/none' );
            endif; ?>

            <?php if ( $layout === 'list' ) : ?>
            </ul>
            <?php else : ?>
            </div>
            <?php endif; ?>

            <?php newspress_pagination(); ?>
        </div>

        <?php if ( newspress_archive_sidebar() !== 'none' ) : ?>
        <aside id="np-sidebar" class="np-sidebar" role="complementary" aria-label="<?php esc_attr_e( 'Sidebar', 'newspress' ); ?>">
            <?php
            if ( is_active_sidebar( 'sidebar-category' ) ) {
                dynamic_sidebar( 'sidebar-category' );
            } else {
                dynamic_sidebar( 'sidebar-1' );
            }
            ?>
        </aside>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
