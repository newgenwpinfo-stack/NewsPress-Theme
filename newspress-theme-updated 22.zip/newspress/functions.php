<?php
/**
 * NewsPress Theme Functions
 *
 * @package NewsPress
 * @version 1.0.2
 */

defined( 'ABSPATH' ) || exit;

define( 'NEWSPRESS_VERSION', '1.3.2' );
define( 'NEWSPRESS_DIR',     get_template_directory() );
define( 'NEWSPRESS_URI',     get_template_directory_uri() );

/* ============================================================
   BLOCK WIDGETS (Gutenberg) — WordPress 5.8+
   Block Widgets editor is the modern default. No filter needed.
   Legacy line removed: add_filter('use_widgets_block_editor','__return_false')
   Widget areas and sidebar registrations are fully preserved.
   ============================================================ */

/* ============================================================
   THEME SETUP
   ============================================================ */
function newspress_setup() {
    load_theme_textdomain( 'newspress', NEWSPRESS_DIR . '/languages' );

    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'widgets-block-editor' ); // Explicitly enable Block Widgets (WP 5.8+)
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'
    ) );
    add_theme_support( 'custom-logo', array(
        'height'      => 80,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'responsive-embeds' );

    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'align-wide' );

    // ── FIX 2: Proper named image sizes so WordPress serves correctly-sized images ──
    add_image_size( 'newspress-hero',  1280, 720, true );  // Hero / LCP image
    add_image_size( 'newspress-card',  420,  280, true );  // Card thumbnails
    add_image_size( 'newspress-thumb', 120,  90,  true );  // Sidebar / related
    add_image_size( 'newspress-wide',  1200, 600, true );  // Single post featured

    register_nav_menus( array(
        'primary'   => __( 'Primary Navigation', 'newspress' ),
        'secondary' => __( 'Secondary/Category Bar', 'newspress' ),
        'footer-1'  => __( 'Footer Menu 1', 'newspress' ),
        'footer-2'  => __( 'Footer Menu 2', 'newspress' ),
        'topbar'    => __( 'Top Bar Menu', 'newspress' ),
    ) );

    add_theme_support( 'post-formats', array( 'video', 'gallery', 'audio', 'quote', 'link' ) );
}
add_action( 'after_setup_theme', 'newspress_setup' );

/* ============================================================
   CONTENT WIDTH
   ============================================================ */
function newspress_content_width() {
    $GLOBALS['content_width'] = apply_filters( 'newspress_content_width', 860 );
}
add_action( 'after_setup_theme', 'newspress_content_width', 0 );

/* ============================================================
   REGISTER SIDEBARS
   ============================================================ */
function newspress_widgets_init() {
    $sidebars = array(
        // Core sidebars — sidebar-1 is the fallback when page-specific sidebars are empty
        array( 'id' => 'sidebar-1',        'name' => __( '📌 Main Sidebar (fallback)',       'newspress' ), 'description' => __( 'Default sidebar. Shown on any page that has no page-specific sidebar filled.',            'newspress' ) ),
        array( 'id' => 'sidebar-left',     'name' => __( '◀ Left Sidebar',                  'newspress' ), 'description' => __( 'Shown when sidebar position is set to Left (Customizer → Sidebar & Widgets).',           'newspress' ) ),
        array( 'id' => 'sidebar-single',   'name' => __( '📄 Single Post Sidebar',           'newspress' ), 'description' => __( 'Shown on individual post pages. Falls back to Main Sidebar if empty.',                    'newspress' ) ),
        array( 'id' => 'sidebar-category', 'name' => __( '🗂 Category & Archive Sidebar',    'newspress' ), 'description' => __( 'Shown on category, tag, date, and archive pages. Falls back to Main Sidebar if empty.',   'newspress' ) ),
        array( 'id' => 'sidebar-home',     'name' => __( '🏠 Homepage Sidebar',              'newspress' ), 'description' => __( 'Shown on the homepage. Falls back to Main Sidebar if empty.',                             'newspress' ) ),
        // Footer
        array( 'id' => 'footer-widget-1',  'name' => __( '🦶 Footer Column 1',              'newspress' ), 'description' => __( 'First column of the footer widget row (Customizer → Footer controls number of columns).', 'newspress' ) ),
        array( 'id' => 'footer-widget-2',  'name' => __( '🦶 Footer Column 2',              'newspress' ), 'description' => __( 'Second column of the footer widget row.',                                                  'newspress' ) ),
        array( 'id' => 'footer-widget-3',  'name' => __( '🦶 Footer Column 3',              'newspress' ), 'description' => __( 'Third column of the footer widget row.',                                                   'newspress' ) ),
        array( 'id' => 'footer-widget-4',  'name' => __( '🦶 Footer Column 4',              'newspress' ), 'description' => __( 'Fourth column of the footer widget row.',                                                  'newspress' ) ),
        // Ad / special zones
        array( 'id' => 'above-header',     'name' => __( '📢 Above Header (Ad)',             'newspress' ), 'description' => __( 'Full-width zone above the site header. Ideal for a 970×90 leaderboard ad.',              'newspress' ) ),
        array( 'id' => 'below-header',     'name' => __( '📢 Below Header',                 'newspress' ), 'description' => __( 'Full-width zone directly below the main navigation bar.',                                 'newspress' ) ),
        array( 'id' => 'before-content',   'name' => __( '📢 Before Content (Ad)',           'newspress' ), 'description' => __( 'Shown above the main content area on single posts and pages.',                            'newspress' ) ),
        array( 'id' => 'after-content',    'name' => __( '📢 After Content',                 'newspress' ), 'description' => __( 'Shown below the post/page content, before the share buttons.',                            'newspress' ) ),
        array( 'id' => 'in-article',       'name' => __( '📢 In-Article Ad Zone',            'newspress' ), 'description' => __( 'Inserted mid-article on single posts. 300×250 or 320×100 works well.',                   'newspress' ) ),
        array( 'id' => 'sidebar-sticky',   'name' => __( '📢 Sticky Sidebar Ad',             'newspress' ), 'description' => __( 'Sticks to the top of the sidebar as the reader scrolls. 300×250 or 300×600 recommended.', 'newspress' ) ),
    );
    foreach ( $sidebars as $s ) {
        register_sidebar( array(
            'id'            => $s['id'],
            'name'          => $s['name'],
            'description'   => $s['description'] ?? '',
            'before_widget' => '<div id="%1$s" class="np-widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="np-widget-title">',
            'after_title'   => '</h3>',
        ) );
    }
}
add_action( 'widgets_init', 'newspress_widgets_init' );

/* ============================================================
   SCRIPT & STYLE LOADING
   Stylesheet async loading + Google Fonts are handled in
   inc/performance.php (newspress_async_stylesheet, newspress_font_loading).
   This function registers the JS and enqueues the stylesheet.
   ============================================================ */
function newspress_enqueue() {

    // -- Core stylesheet --
    // Registered here; inc/performance.php converts it to async preload
    // via the style_loader_tag filter at priority 20.
    // Version = theme version + file mtime, so every edit to style.css busts the
    // browser/CDN cache (CSS is served with a 1-year Expires header).
    $np_css_file = get_stylesheet_directory() . '/style.css';
    $np_css_ver  = NEWSPRESS_VERSION . ( file_exists( $np_css_file ) ? '.' . filemtime( $np_css_file ) : '' );
    wp_enqueue_style( 'newspress-style', get_stylesheet_uri(), array(), $np_css_ver );

    // -- Navigation JS: loads on every page, in the footer. --
    // Whether it is deferred is controlled by "Defer Non-Critical JS"
    // (np_perf_defer_js) — NewsPress Settings → Performance — exactly like
    // newspress-main below. Registered directly with the WP 6.3+ 'strategy'
    // argument when the setting is ON so WordPress adds the defer attribute
    // itself; when the setting is OFF, no strategy is passed at all, so the
    // script tag never carries defer. (A later script_loader_tag filter
    // cannot remove a strategy WordPress has already applied, so the
    // ON/OFF choice has to be made here, at registration time.)
    $np_defer_js = (bool) get_option( 'np_perf_defer_js', true );
    wp_enqueue_script(
        'newspress-nav',
        NEWSPRESS_URI . '/js/nav.js',
        array(),          // no dependencies
        NEWSPRESS_VERSION,
        $np_defer_js
            ? array(
                'in_footer' => true,
                'strategy'  => 'defer', // WP 6.3+ strategy — defer fires after DOM parsed
              )
            : array( 'in_footer' => true ) // setting OFF: no strategy, so no defer
    );

    // -- Main JS: deferred, loads on all pages --
    // Navigation toggle, dark mode, sticky header, progress bar -- all pages.
    wp_enqueue_script( 'newspress-main', NEWSPRESS_URI . '/js/main.js', array(), NEWSPRESS_VERSION, true );
    wp_localize_script( 'newspress-main', 'npData', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'newspress_nonce' ),
        'homeUrl' => home_url(),
    ) );

    // -- Comment reply JS: only where needed --
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'newspress_enqueue' );

/* ============================================================
   ADD defer TO MAIN SCRIPT TAG
   ============================================================ */
function newspress_script_attributes( $tag, $handle ) {
    // Respects "Defer Non-Critical JS" (np_perf_defer_js) for newspress-main.
    // newspress-nav is intentionally never touched here — its defer state is
    // decided at registration time in newspress_enqueue(), via the WP 6.3+
    // 'strategy' argument, so this filter would have nothing to add for it.
    if ( 'newspress-main' === $handle
        && get_option( 'np_perf_defer_js', true )
        && false === strpos( $tag, ' defer' )
    ) {
        $tag = str_replace( '<script ', '<script defer ', $tag );
    }
    return $tag;
}
add_filter( 'script_loader_tag', 'newspress_script_attributes', 10, 2 );

/* ============================================================
   DISABLE EMOJI SCRIPTS (saves ~4KB JS + 1 DNS lookup)
   Only runs when "Remove Emoji Scripts" (np_perf_remove_emoji) is
   enabled in NewsPress Settings → Performance.
   ============================================================ */
function newspress_disable_emojis() {
    if ( ! get_option( 'np_perf_remove_emoji', true ) ) {
        return;
    }
    remove_action( 'wp_head',             'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles',     'print_emoji_styles' );
    remove_action( 'admin_print_styles',  'print_emoji_styles' );
    remove_filter( 'the_content_feed',    'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss',    'wp_staticize_emoji' );
    remove_filter( 'wp_mail',             'wp_staticize_emoji_for_email' );
    add_filter( 'tiny_mce_plugins',       'newspress_disable_emojis_tinymce' );
    add_filter( 'wp_resource_hints',      'newspress_remove_emoji_dns', 10, 2 );
}
add_action( 'init', 'newspress_disable_emojis' );

function newspress_disable_emojis_tinymce( $plugins ) {
    return is_array( $plugins ) ? array_diff( $plugins, array( 'wpemoji' ) ) : array();
}

function newspress_remove_emoji_dns( $urls, $relation_type ) {
    if ( 'dns-prefetch' === $relation_type ) {
        $urls = array_filter( $urls, function( $url ) {
            return isset( $url['href'] ) ? false !== strpos( $url['href'], 'emoji' ) ? false : true : true;
        } );
    }
    return $urls;
}

/* ============================================================
   REMOVE OTHER UNUSED WP HEAD BLOAT
   ============================================================ */
function newspress_clean_head() {
    remove_action( 'wp_head', 'wp_generator' );              // WP version tag
    remove_action( 'wp_head', 'wlwmanifest_link' );          // Windows Live Writer
    remove_action( 'wp_head', 'rsd_link' );                  // Really Simple Discovery
    remove_action( 'wp_head', 'wp_shortlink_wp_head' );      // Shortlink
    remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 ); // prev/next
}
add_action( 'init', 'newspress_clean_head' );

// Resource hints, LCP preloads, and hero transient are now in inc/performance.php.
// Save_post transient cleanup remains here as it also clears section caches.
add_action( 'save_post', function( $post_id ) {
    if ( wp_is_post_revision( $post_id ) ) return;
    delete_transient( 'np_hero_preload_url' ); // legacy key — keep for upgrade safety
    delete_transient( 'np_lcp_preload' );      // new key used by performance.php
    global $wpdb;
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_np_section_%' OR option_name LIKE '_transient_timeout_np_section_%'" );
} );

/* ============================================================
   INLINE CSS FROM CUSTOMIZER
   ============================================================ */
function newspress_customizer_css() {
    $opt = newspress_get_options();
    $css = ':root{';
    foreach ( $opt as $prop => $val ) {
        // Font-family values contain quotes — esc_attr would mangle them to &quot;
        // Use wp_strip_all_tags for font props, esc_attr for everything else
        if ( strpos( $prop, 'font' ) !== false ) {
            $css .= $prop . ':' . wp_strip_all_tags( $val ) . ';';
        } else {
            $css .= $prop . ':' . esc_attr( $val ) . ';';
        }
    }
    $css .= '}';

    // Pagination style variables
    $pag_gap        = absint( get_theme_mod( 'np_pag_gap',        6  ) );
    $pag_size       = absint( get_theme_mod( 'np_pag_size',       36 ) );
    $pag_font_size  = absint( get_theme_mod( 'np_pag_font_size',  13 ) );
    $pag_radius     = absint( get_theme_mod( 'np_pag_radius',     4  ) );
    $pag_margin     = absint( get_theme_mod( 'np_pag_margin_top', 20 ) );
    $pag_align      = get_theme_mod( 'np_pag_align', 'center' );
    $allowed_align  = array( 'flex-start', 'center', 'flex-end' );
    if ( ! in_array( $pag_align, $allowed_align, true ) ) { $pag_align = 'center'; }

    $css .= '.np-pagination,.navigation.pagination .nav-links{'
        . 'gap:'             . $pag_gap    . 'px;'
        . 'justify-content:' . $pag_align  . ';'
        . 'margin:'          . ( $pag_margin / 10 ) . 'rem 0;'
        . '}'
        . '.np-pagination a,.np-pagination span'
        . ',.navigation.pagination .page-numbers{'
        . 'min-width:'    . $pag_size      . 'px;'
        . 'height:'       . $pag_size      . 'px;'
        . 'font-size:'    . $pag_font_size . 'px;'
        . 'border-radius:' . $pag_radius   . 'px;'
        . '}';

    /* ── Float / Lift effect — 4 independent zones ── */
    $float_color   = get_theme_mod( 'np_float_shadow_color', '#000000' );
    $float_opacity = absint( get_theme_mod( 'np_float_shadow_opacity', 18 ) ) / 100;
    $float_bg      = get_theme_mod( 'np_float_card_bg', '' );
    $float_scale   = absint( get_theme_mod( 'np_float_scale', 105 ) );
    $float_lift    = absint( get_theme_mod( 'np_float_lift', 4 ) );

    // Build rgba shadow colour
    $hex = ltrim( $float_color, '#' );
    $r   = ( strlen( $hex ) === 6 ) ? hexdec( substr( $hex, 0, 2 ) ) : 0;
    $g   = ( strlen( $hex ) === 6 ) ? hexdec( substr( $hex, 2, 2 ) ) : 0;
    $b   = ( strlen( $hex ) === 6 ) ? hexdec( substr( $hex, 4, 2 ) ) : 0;
    $shadow_color = 'rgba(' . $r . ',' . $g . ',' . $b . ',' . $float_opacity . ')';

    // Shadow direction → concrete X / Y pixel values (no CSS vars — so they work everywhere)
    $shadow_blur   = absint( get_theme_mod( 'np_float_shadow_blur',   20 ) );
    $shadow_spread = absint( get_theme_mod( 'np_float_shadow_spread',  0 ) );
    $dir           = get_theme_mod( 'np_float_shadow_dir', 'bottom' );
    $custom_x      = intval( get_theme_mod( 'np_float_shadow_x', 0 ) );
    $custom_y      = intval( get_theme_mod( 'np_float_shadow_y', 8 ) );
    $li            = (int) $float_lift; // shorthand

    $dir_map = array(
        'bottom'       => array(    0,   $li ),
        'bottom-right' => array(  $li,   $li ),
        'bottom-left'  => array( -$li,   $li ),
        'top'          => array(    0,  -$li ),
        'top-right'    => array(  $li,  -$li ),
        'top-left'     => array( -$li,  -$li ),
        'right'        => array(  $li,     0 ),
        'left'         => array( -$li,     0 ),
        'center'       => array(    0,     0 ),
        'custom'       => array( $custom_x, $custom_y ),
    );
    list( $sx, $sy ) = isset( $dir_map[ $dir ] ) ? $dir_map[ $dir ] : array( 0, $li );

    // Full box-shadow value with concrete px — no CSS vars, works everywhere
    $lift_shadow = $sx . 'px ' . $sy . 'px ' . $shadow_blur . 'px ' . $shadow_spread . 'px ' . $shadow_color;
    $lift_tf     = 'translateY(' . ( -$li ) . 'px)';
    $dur_ms      = absint( get_theme_mod( 'np_float_duration', 220 ) );
    $trans_card  = 'box-shadow ' . $dur_ms . 'ms ease, transform ' . $dur_ms . 'ms ease';
    $trans_img   = 'transform ' . $dur_ms . 'ms ease';
    $scale_val   = $float_scale > 100 ? ( $float_scale / 100 ) : 0;

    // Helper closure — outputs CSS for one zone
    $np_float_zone = function( $mode, $card_sels, $img_sels, $img_parent_hovers )
        use ( &$css, $lift_shadow, $lift_tf, $trans_card, $trans_img, $scale_val ) {
        if ( $mode === 'off' ) return;

        $card_str = implode( ', ', array_filter( $card_sels ) );
        $img_str  = implode( ', ', array_filter( $img_sels ) );

        if ( $card_str ) {
            $css .= $card_str . ' { transition: ' . $trans_card . '; }';
            if ( $mode === 'always' ) {
                $css .= $card_str . ' { transform: ' . $lift_tf . '; box-shadow: ' . $lift_shadow . '; }';
            } else {
                $hover_str = implode( ':hover, ', $card_sels ) . ':hover';
                $css .= $hover_str . ' { transform: ' . $lift_tf . '; box-shadow: ' . $lift_shadow . '; }';
            }
        }
        if ( $img_str ) {
            $css .= $img_str . ' { transition: ' . $trans_img . '; }';
            if ( $scale_val > 1 ) {
                if ( $mode === 'always' ) {
                    $css .= $img_str . ' { transform: scale(' . $scale_val . '); }';
                } else {
                    foreach ( $img_parent_hovers as $ph ) {
                        $css .= $ph . ' { transform: scale(' . $scale_val . '); }';
                    }
                }
            }
        }
    };

    // ── Zone 1: Post Cards ──
    $np_float_zone(
        get_theme_mod( 'np_float_zone_cards', 'hover' ),
        array( '.np-card', '.np-section-card' ),
        array( '.np-card .np-card-thumb img' ),
        array( '.np-card:hover .np-card-thumb img' )
    );

    // ── Zone 2: Hero & section images ──
    $np_float_zone(
        get_theme_mod( 'np_float_zone_hero', 'hover' ),
        array( '.np-hero-main', '.np-hero-side', '.np-magazine-main', '.np-magazine-side' ),
        array( '.np-hero-main img', '.np-hero-side img', '.np-magazine-main img', '.np-magazine-side img' ),
        array( '.np-hero-main:hover img', '.np-hero-side:hover img', '.np-magazine-main:hover img', '.np-magazine-side:hover img' )
    );

    // ── Zone 3: Single post / page images ──
    // body.np-single = singular posts | body.np-page = pages
    // .np-featured-image figure | .entry-content inline images
    $np_float_zone(
        get_theme_mod( 'np_float_zone_single', 'always' ),
        array(),
        array(
            'body.np-single .np-featured-image img',
            'body.np-single .np-entry-content img',
            'body.np-page .np-featured-image img',
            'body.np-page .np-entry-content img',
        ),
        array(
            'body.np-single .np-featured-image img:hover',
            'body.np-single .np-entry-content img:hover',
            'body.np-page .np-featured-image img:hover',
            'body.np-page .np-entry-content img:hover',
        )
    );

    // ── Zone 4: Widget & sidebar cards ──
    $np_float_zone(
        get_theme_mod( 'np_float_zone_widget', 'hover' ),
        array( '.np-sidebar .np-card', '.widget .np-card', '.np-numbered-post-item' ),
        array( '.np-sidebar .np-card .np-card-thumb img' ),
        array( '.np-sidebar .np-card:hover .np-card-thumb img' )
    );

    // ── Related posts (follows cards zone) ──
    $np_float_zone(
        get_theme_mod( 'np_float_zone_cards', 'hover' ),
        array( '.np-related-item' ),
        array( '.np-related-item img' ),
        array( '.np-related-item:hover img' )
    );

    if ( $float_bg ) {
        $css .= '.np-card { background: ' . esc_attr( $float_bg ) . '; }';
    }

    // Dark-mode custom properties are defined ONCE in style.css (.np-dark-mode)
    // and duplicated only in the critical-CSS block (inc/performance.php) so the
    // very first paint already has the correct rule available. They are
    // intentionally NOT re-generated here — this used to be a second,
    // independent definition of the same variables and could drift out of
    // sync with style.css. See "Dark Mode CSS cleanup" in the audit report.

    // Strip whitespace from inline CSS (safe — preserves descendant selectors like ".a .b{}")
    $css = preg_replace( '/\s*{\s*/', '{', $css );   // space(s) around {
    $css = preg_replace( '/\s*}\s*/', '}', $css );   // space(s) around }
    $css = preg_replace( '/\s*;\s*/', ';', $css );   // space(s) around ;
    $css = preg_replace( '/:\s+/', ':', $css );       // space after : in property values
    $css = preg_replace( '/\n|\r/', '', $css );      // newlines
    echo '<style id="newspress-vars">' . $css . '</style>' . "\n";
}
add_action( 'wp_head', 'newspress_customizer_css', 8 );

/* ============================================================
   CSS CUSTOM PROPERTIES MAP
   ============================================================ */
function newspress_get_options() {
    return array(
        // Colors
        '--np-primary'       => get_theme_mod( 'np_color_primary',     '#d32f2f' ),
        '--np-secondary'     => get_theme_mod( 'np_color_secondary',   '#1565c0' ),
        '--np-accent'        => get_theme_mod( 'np_color_accent',      '#f57c00' ),
        '--np-text'          => get_theme_mod( 'np_color_text',        '#212121' ),
        '--np-text-muted'    => get_theme_mod( 'np_color_muted',       '#757575' ),
        '--np-bg'            => get_theme_mod( 'np_color_bg',          '#ffffff' ),
        '--np-bg-alt'        => get_theme_mod( 'np_color_bg_alt',      '#f5f5f5' ),
        '--np-header-bg'     => get_theme_mod( 'np_color_header_bg',   '#ffffff' ),
        '--np-topbar-bg'     => get_theme_mod( 'np_color_topbar_bg',   '#212121' ),
        '--np-topbar-text'   => get_theme_mod( 'np_color_topbar_text', '#ffffff' ),
        '--np-footer-bg'     => get_theme_mod( 'np_color_footer_bg',   '#1a1a1a' ),
        '--np-footer-text'   => get_theme_mod( 'np_color_footer_text', '#cccccc' ),
        '--np-nav-bg'        => get_theme_mod( 'np_color_nav_bg',      '#d32f2f' ),
        '--np-nav-text'      => get_theme_mod( 'np_color_nav_text',    '#ffffff' ),
        // Layout
        '--np-container'     => absint( get_theme_mod( 'np_container_width', 1200 ) ) . 'px',
        '--np-sidebar-width' => absint( get_theme_mod( 'np_sidebar_width',    300 ) ) . 'px',
        '--np-radius'        => absint( get_theme_mod( 'np_border_radius',      4 ) ) . 'px',
        // Header / menu / footer content width (0 = same as Max Container Width)
        '--np-header-width' => ( $w = absint( get_theme_mod( 'np_header_width', 0 ) ) ) ? $w . 'px' : 'var(--np-container)',
        '--np-nav-width'    => ( $w = absint( get_theme_mod( 'np_nav_width',    0 ) ) ) ? $w . 'px' : 'var(--np-container)',
        '--np-footer-width' => ( $w = absint( get_theme_mod( 'np_footer_width', 0 ) ) ) ? $w . 'px' : 'var(--np-container)',
        // Header dimensions
        '--np-logo-height'        => absint( get_theme_mod( 'np_logo_height',        60 ) ) . 'px',
        '--np-logo-height-mobile' => absint( get_theme_mod( 'np_logo_height_mobile', 60 ) ) . 'px',
        '--np-header-pad'         => absint( get_theme_mod( 'np_header_padding',     16 ) ) . 'px',
        '--np-site-title-size'    => absint( get_theme_mod( 'np_site_title_size',    28 ) ) . 'px',
        // Typography — fonts
        '--np-font-body'     => newspress_font_stack( get_theme_mod( 'np_font_body',    'sys:Georgia' ), true ),
        '--np-font-heading'  => newspress_font_stack( get_theme_mod( 'np_font_heading', 'sys:Arial' ), false ),
        // Typography — global sizes
        '--np-font-size'        => absint( get_theme_mod( 'np_font_size',        16 ) ) . 'px',
        '--np-font-size-widget' => absint( get_theme_mod( 'np_font_size_widget', 14 ) ) . 'px',
        '--np-font-size-meta'   => absint( get_theme_mod( 'np_font_size_meta',   12 ) ) . 'px',
        '--np-lh-body'          => ( absint( get_theme_mod( 'np_font_lh_body',   16 ) ) / 10 ),
        // Typography — headings
        '--np-h1-size'   => absint( get_theme_mod( 'np_h1_size', 32 ) ) . 'px',
        '--np-h2-size'   => absint( get_theme_mod( 'np_h2_size', 26 ) ) . 'px',
        '--np-h3-size'   => absint( get_theme_mod( 'np_h3_size', 22 ) ) . 'px',
        '--np-h4-size'   => absint( get_theme_mod( 'np_h4_size', 18 ) ) . 'px',
        // Typography — post/single
        '--np-font-size-post'       => absint( get_theme_mod( 'np_font_size_post',       17 ) ) . 'px',
        '--np-font-size-post-title' => absint( get_theme_mod( 'np_font_size_post_title', 32 ) ) . 'px',
        '--np-lh-post'              => ( absint( get_theme_mod( 'np_font_lh_post',        17 ) ) / 10 ),
        // Typography — cards
        '--np-font-size-card-title'   => absint( get_theme_mod( 'np_font_size_card_title',   16 ) ) . 'px',
        '--np-font-size-card-excerpt' => absint( get_theme_mod( 'np_font_size_card_excerpt', 13 ) ) . 'px',
        '--np-font-size-card-meta'    => absint( get_theme_mod( 'np_font_size_card_meta',    12 ) ) . 'px',
        // Float / lift effect
        // Float vars kept for JS preview compatibility only
        '--np-float-dur'   => absint( get_theme_mod( 'np_float_duration', 220 ) ) . 'ms',
        // Back-to-top
        '--np-btt-size'   => absint( get_theme_mod( 'np_btt_size',   40 ) ) . 'px',
        '--np-btt-icon'   => absint( get_theme_mod( 'np_btt_icon',   18 ) ) . 'px',
        '--np-btt-radius' => absint( get_theme_mod( 'np_btt_radius', 50 ) ) . 'px',
        '--np-btt-bottom' => absint( get_theme_mod( 'np_btt_bottom', 24 ) ) . 'px',
        '--np-btt-right'  => absint( get_theme_mod( 'np_btt_right',  24 ) ) . 'px',
        '--np-btt-bg'     => get_theme_mod( 'np_btt_bg',    '#d32f2f' ),
        '--np-btt-color'  => get_theme_mod( 'np_btt_color', '#ffffff' ),
        '--np-btt-cursor' => sanitize_key( get_theme_mod( 'np_btt_cursor', 'pointer' ) ),
    );
}

function newspress_font_stack( $font, $serif = false ) {
    $fallback = $serif ? 'Georgia,"Times New Roman",serif' : '"Helvetica Neue",Arial,sans-serif';
    if ( ! $font || 'default' === $font || 'sys:default' === $font ) {
        return $fallback;
    }
    // Strip sys: prefix for system fonts (no quotes needed for single-word system fonts)
    if ( strpos( $font, 'sys:' ) === 0 ) {
        $font = substr( $font, 4 );
        return '"' . $font . '",' . $fallback;
    }
    // Google Font — wrap in quotes, Google Fonts handles the actual load
    return '"' . $font . '",' . $fallback;
}

/* ============================================================
   MODULAR FEATURE SYSTEM
   Core files always load. Optional modules controlled by
   Customizer toggles — only loaded when enabled.
   ============================================================ */

// Core: always required on frontend
$np_core = array(
    '/inc/template-tags.php',
    '/inc/template-functions.php',
    '/inc/walker-nav.php',
    '/inc/performance.php',     // Core Web Vitals & loading optimizations
);
// Customizer: load in admin + always on frontend so Customizer preview iframe works.
// The file only registers hooks (customize_register, customize_preview_init) —
// these never fire on normal frontend requests so there is no runtime cost.
if ( is_admin() || ! wp_doing_ajax() ) {
    $np_core[] = '/inc/customizer.php';
}
foreach ( $np_core as $np_file ) {
    $np_path = NEWSPRESS_DIR . $np_file;
    if ( file_exists( $np_path ) ) {
        require_once $np_path;
    }
}

// Always-on optional files
require_once NEWSPRESS_DIR . '/inc/widgets.php';

// Optional modules: loaded based on Customizer settings
$np_modules = array(
    '/inc/script-loader.php'        => true,  // always on — defers scripts
    // Single authoritative source: NewsPress Settings → Performance (get_option()).
    '/inc/performance-monitor.php'  => get_option( 'np_perf_monitor', false ),
    '/inc/cookie-consent.php'       => get_option( 'np_cookie_enable', false ),  // managed in NewsPress Settings → Privacy
);
foreach ( $np_modules as $np_file => $np_enabled ) {
    if ( $np_enabled ) {
        $np_path = NEWSPRESS_DIR . $np_file;
        if ( file_exists( $np_path ) ) {
            require_once $np_path;
        }
    }
}

/* ============================================================
   FIX 5: OPTIMISED WP_Query DEFAULTS
   Apply globally so every theme query is lean.
   ============================================================ */
function newspress_optimise_queries( $query ) {
    // Only on front-end main queries — never admin, REST, AJAX, cron, or any
    // plugin/custom WP_Query. This must never reach WooCommerce or other
    // third-party queries, which do not call pre_get_posts through this path
    // unless they are themselves a front-end main query (excluded below).
    if ( is_admin() || ! $query->is_main_query() ) {
        return;
    }
    if ( wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
        return;
    }

    // ── Posts per page: admin-controlled via Customizer ──
    if ( $query->is_home() || $query->is_front_page() ) {
        $count = absint( get_theme_mod( 'np_home_posts_count', 9 ) );
        if ( $count > 0 ) {
            $query->set( 'posts_per_page', $count );
        }
    } elseif ( $query->is_category() || $query->is_tag() || $query->is_archive() ) {
        $count = absint( get_theme_mod( 'np_archive_posts_count', 12 ) );
        if ( $count > 0 ) {
            $query->set( 'posts_per_page', $count );
        }
    }

    // Don't skip found_rows on paginated archives (needed for pagination)
    if ( ! is_singular() && ! is_home() && ! is_front_page() ) {
        $query->set( 'update_post_meta_cache', false );
        $query->set( 'update_post_term_cache', false );
    }
    if ( is_singular() ) {
        $query->set( 'no_found_rows', true );
    }
}
add_action( 'pre_get_posts', 'newspress_optimise_queries' );

/* ============================================================
   AJAX: Load More Posts
   FIX 5: All manual WP_Query calls include cache flags
   ============================================================ */
function newspress_load_more() {
    check_ajax_referer( 'newspress_nonce', 'nonce' );

    $paged = isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1;
    $cat   = isset( $_POST['cat'] )  ? absint( $_POST['cat'] )  : 0;

    $query = new WP_Query( array(
        'post_type'              => 'post',
        'posts_per_page'         => 9,
        'paged'                  => $paged,
        'cat'                    => $cat,
        'no_found_rows'          => true,   // no pagination needed in AJAX
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
    ) );

    $html = '';
    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            ob_start();
            get_template_part( 'template-parts/content/card', 'grid' );
            $html .= ob_get_clean();
        }
        wp_reset_postdata();
    }

    wp_send_json_success( array(
        'html'     => $html,
        'has_more' => $query->max_num_pages > $paged,
    ) );
}
add_action( 'wp_ajax_newspress_load_more',        'newspress_load_more' );
add_action( 'wp_ajax_nopriv_newspress_load_more', 'newspress_load_more' );

/* ============================================================
   EXCERPT
   ============================================================ */
function newspress_excerpt_length( $length ) {
    return absint( get_theme_mod( 'np_excerpt_length', 20 ) );
}
add_filter( 'excerpt_length', 'newspress_excerpt_length', 999 );

function newspress_excerpt_more( $more ) {
    return '&hellip;';
}
add_filter( 'excerpt_more', 'newspress_excerpt_more' );

/* ============================================================
   FIX 3: BODY CLASSES — correct sidebar + dark mode context
   ============================================================ */

/* ============================================================
   SOCIAL ICONS — inline SVG, no font dependency
   ============================================================ */
function newspress_social_icon( $network ) {
    $icons = array(
        'fb'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>',
        'tw'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M4 4l16 16M4 20L20 4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M20 4l-7.5 9.5M4 20l7.5-9.5M20 4h-5l-3 3.5M4 20h5l3-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>',
        'ig'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>',
        'yt'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58 2.78 2.78 0 0 0 1.95 1.96C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.96-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="#fff"/></svg>',
        'rss' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="5" cy="19" r="1"/></svg>',
        'li'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>',
        'tk'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"/></svg>',
    );
    return isset( $icons[ $network ] ) ? $icons[ $network ] : esc_html( $network );
}

function newspress_body_class( $classes ) {
    $sidebar = get_theme_mod( 'np_sidebar_pos', 'right' );
    $classes[] = 'np-sidebar-' . sanitize_html_class( $sidebar );

    // Dark/Light mode is NEVER decided here. It is manual-only and lives in
    // localStorage ('np-dark'), applied by a tiny inline script right after
    // <body> opens (see header.php) so every new visitor with no saved
    // preference renders in Light mode — with no dependency on the visitor's
    // OS/browser color-scheme setting. See the Dark/Light Mode audit notes.
    if ( is_singular( 'post' ) ) {
        $classes[] = 'np-single';
    }
    if ( is_page() ) {
        $classes[] = 'np-page';
    }

    // Boxed (width-limited background) vs full-width bars → .np-header-boxed / .np-nav-boxed / .np-footer-boxed
    foreach ( array( 'header', 'nav', 'footer' ) as $np_bar ) {
        if ( 'boxed' === get_theme_mod( 'np_' . $np_bar . '_bg_mode', 'full' ) ) {
            $classes[] = 'np-' . $np_bar . '-boxed';
        }
    }

    // Widget style variant class → CSS targets .np-widget-style-{value} .np-widget
    $widget_style = get_theme_mod( 'np_widget_style', 'boxed' );
    if ( $widget_style && 'boxed' !== $widget_style ) {
        $classes[] = 'np-widget-style-' . sanitize_html_class( $widget_style );
    }

    // Widget title style class → CSS targets .np-widget-title-{value} .np-widget-title
    $title_style = get_theme_mod( 'np_widget_title_style', 'underline' );
    if ( $title_style && 'underline' !== $title_style ) {
        $classes[] = 'np-widget-title-' . sanitize_html_class( $title_style );
    }

    return $classes;
}
add_filter( 'body_class', 'newspress_body_class' );

/* ============================================================
   READING TIME
   ============================================================ */
function newspress_reading_time( $post_id = null ) {
    $post_id = $post_id ? (int) $post_id : get_the_ID();
    $content = get_post_field( 'post_content', $post_id );
    $count   = str_word_count( strip_tags( $content ) );
    $mins    = max( 1, (int) round( $count / 200 ) );
    return sprintf( _n( '%d min read', '%d min read', $mins, 'newspress' ), $mins );
}

/* ============================================================
   LAZY LOAD IFRAMES in post content
   Images handled by newspress_image_attributes() in performance.php.
   ============================================================ */
function newspress_lazy_iframes( $content ) {
    // Part of "Lazy Load Images" — NewsPress Settings → Performance.
    if ( ! get_option( 'np_perf_lazy_load', true ) ) return $content;
    // Add loading="lazy" to iframes that don't already have it
    return preg_replace( '/<iframe(?![^>]*\bloading=)/i', '<iframe loading="lazy"', $content );
}
add_filter( 'the_content', 'newspress_lazy_iframes' );
// newspress_lazy_images() removed — superseded by newspress_image_attributes() in performance.php


/* ============================================================
   WEBP / MODERN FORMAT SUPPORT
   WordPress 5.8+ generates WebP automatically when the host
   has libwebp. We add the mime type and picture tag support.

   Two independent things live in this section, on purpose:

   1. newspress_allow_webp() — lets .webp files be UPLOADED to the
      media library at all. This is a compatibility feature, not a
      performance optimization: without it, admins simply cannot
      upload a .webp file, regardless of any performance setting.
      It is therefore intentionally NOT gated by the "WebP Support"
      performance toggle (np_perf_webp) and stays on unconditionally
      so existing/previously-uploaded WebP media is never broken.

   2. newspress_picture_webp() — the performance optimization that
      wraps output in <picture> to SERVE a .webp alternative next to
      a JPEG/PNG. This IS gated by np_perf_webp: OFF means NewsPress
      adds no <picture>/WebP output at all (plain <img>, untouched);
      ON means a compatible .webp is offered via <picture> with the
      original JPEG/PNG kept as the safe <img> fallback.
   ============================================================ */
add_filter( 'upload_mimes', 'newspress_allow_webp' );
function newspress_allow_webp( $mimes ) {
    // Intentionally unconditional — see note above. Do not gate this on
    // np_perf_webp; that setting controls serving/output, not uploads.
    $mimes['webp'] = 'image/webp';
    return $mimes;
}


// Output <picture> with WebP source when a WebP version exists alongside JPEG/PNG
add_filter( 'post_thumbnail_html', 'newspress_picture_webp', 10, 5 );
function newspress_picture_webp( $html, $post_id, $thumbnail_id, $size, $attr ) {
    // Only wrap if WebP support is enabled and we have an <img>
    // NOTE: this setting is saved via update_option() on the NewsPress
    // Settings → Performance admin page — it must be READ the same way.
    // (Previously this read get_theme_mod(), a different storage mechanism
    // than the one the settings page actually saved to, so the checkbox had
    // no effect on the frontend at all. Fixed as part of the Performance
    // settings audit — see item 4/16 in the report.)
    if ( ! get_option( 'np_perf_webp', true ) ) return $html;
    if ( false === strpos( $html, '<img' ) ) return $html;

    $src = wp_get_attachment_image_src( $thumbnail_id, $size );
    if ( ! $src ) return $html;

    // Only jpeg/png are worth checking — skip gif, svg, webp already
    if ( ! preg_match( '/\.(jpe?g|png)$/i', $src[0] ) ) return $html;

    $webp_url = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $src[0] );
    if ( $webp_url === $src[0] ) return $html;

    // Use cached upload_dir — wp_upload_dir() hits the DB/filesystem every call
    static $upload_cache = null;
    if ( $upload_cache === null ) {
        $upload_cache = wp_upload_dir();
    }

    // Verify the WebP file actually exists on disk before adding <picture>
    $webp_path = str_replace( $upload_cache['baseurl'], $upload_cache['basedir'], $webp_url );
    if ( ! @file_exists( $webp_path ) ) return $html;

    $sizes_attr = wp_get_attachment_image_sizes( $thumbnail_id, $size );
    return '<picture>'
        . '<source type="image/webp" srcset="' . esc_url( $webp_url ) . '"'
        . ( $sizes_attr ? ' sizes="' . esc_attr( $sizes_attr ) . '"' : '' ) . '>'
        . $html
        . '</picture>';
}


/* ============================================================
   AD CODE OUTPUT — reads codes saved in NewsPress Settings → Ads
   Only outputs when ad display is enabled via Customizer.
   ============================================================ */
function newspress_output_ad( $slot ) {
    // Respect Customizer display toggles
    $show_home    = get_theme_mod( 'np_ads_show_home',     true );
    $show_single  = get_theme_mod( 'np_ads_show_single',   true );
    $show_archive = get_theme_mod( 'np_ads_show_archives', true );

    $show = ( is_singular( 'post' ) && $show_single )
         || ( ( is_home() || is_front_page() ) && $show_home )
         || ( ( is_category() || is_tag() || is_archive() || is_search() ) && $show_archive )
         || is_page(); // always show on pages

    if ( ! $show ) return;

    $code = get_option( 'np_ads_' . $slot, '' );
    if ( ! $code ) return;

    echo '<div class="np-ad-slot np-ad-' . esc_attr( $slot ) . '" aria-label="' . esc_attr__( 'Advertisement', 'newspress' ) . '">';
    // Ad codes are saved by admin with unfiltered_html — output raw but only in theme context
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo $code;
    echo '</div>';
}

// Hook: header ad (above nav, below nav handled in header.php widget area)
add_action( 'newspress_before_header', function() { newspress_output_ad( 'header' ); } );
// Hook: footer ad
add_action( 'newspress_before_footer', function() { newspress_output_ad( 'footer' ); } );
// Hook: in-feed ad (called from section-category template at post N)
add_action( 'newspress_infeed_ad',     function() { newspress_output_ad( 'infeed' ); } );
// Hook: mobile banner (bottom of screen, only on mobile)
// Priority 15 — runs before cookie banner (priority 20) so cookie always wins z-index
add_action( 'wp_footer', function() {
    if ( wp_is_mobile() ) {
        newspress_output_ad( 'mobile_banner' );
    }
}, 15 );

/* ============================================================
   ADMIN OPTIONS PAGE
   ============================================================ */
function newspress_admin_menu() {
    add_theme_page(
        __( 'NewsPress Settings', 'newspress' ),
        __( 'NewsPress Settings', 'newspress' ),
        'manage_options',
        'newspress-settings',
        'newspress_options_page'
    );
}
add_action( 'admin_menu', 'newspress_admin_menu' );

function newspress_options_page() {
    if ( file_exists( NEWSPRESS_DIR . '/inc/admin-options.php' ) ) {
        include NEWSPRESS_DIR . '/inc/admin-options.php';
    }
}





/* ============================================================
   STICKY SIDEBAR  (JS-based, CSS position:sticky as fallback)
   ============================================================ */
function newspress_sticky_sidebar_script() {
    if ( ! get_theme_mod( 'np_sticky_sidebar', false ) ) return;
    if ( ! is_active_sidebar( 'sidebar-1' ) ) return;
    ?>
    <script>
    (function(){
        'use strict';
        var sidebar = document.getElementById('np-sidebar');
        if (!sidebar) return;
        sidebar.style.position = 'sticky';
        sidebar.style.top = '80px';
        sidebar.style.alignSelf = 'flex-start';
        sidebar.style.maxHeight = 'calc(100vh - 100px)';
        sidebar.style.overflowY = 'auto';
        sidebar.style.scrollbarWidth = 'thin';
    })();
    </script>
    <?php
}
add_action( 'wp_footer', 'newspress_sticky_sidebar_script' );

/* ============================================================
   PROGRESS BAR — ensure it renders on single posts
   ============================================================ */
function newspress_reading_progress_bar() {
    if ( ! is_single() ) return;
    if ( ! get_theme_mod( 'np_show_progress_bar', true ) ) return;
    echo '<div id="np-read-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-label="' . esc_attr__( 'Reading progress', 'newspress' ) . '"></div>' . "\n";
}
add_action( 'wp_body_open', 'newspress_reading_progress_bar' );


/* ============================================================
   ARCHIVE LAYOUT — read archive-specific settings
   ============================================================ */
function newspress_archive_layout() {
    return get_theme_mod( 'np_archive_layout', 'grid-3' );
}
function newspress_archive_sidebar() {
    return get_theme_mod( 'np_archive_sidebar', 'right' );
}
function newspress_archive_content_class() {
    $sidebar = newspress_archive_sidebar();
    if ( $sidebar === 'none' ) return 'np-site-content np-no-sidebar';
    if ( $sidebar === 'left' )  return 'np-site-content np-left-sidebar';
    return 'np-site-content'; // right = default grid, no modifier needed
}

/* ============================================================
   SINGLE POST LAYOUT — reads np_single_sidebar, np_single_width
   ============================================================ */
function newspress_single_content_class() {
    $sidebar = get_theme_mod( 'np_single_sidebar', 'right' );
    $width   = get_theme_mod( 'np_single_width', 'normal' );
    $class   = 'np-site-content';
    if ( $sidebar === 'none' ) {
        $class .= ' np-no-sidebar';
        if ( $width === 'narrow' ) $class .= ' np-narrow';
    } elseif ( $sidebar === 'left' ) {
        $class .= ' np-left-sidebar';
    }
    // right = default, no extra class
    return $class;
}
function newspress_single_show_sidebar() {
    return get_theme_mod( 'np_single_sidebar', 'right' ) !== 'none';
}


/* ============================================================
   AUTHOR SOCIAL LINKS — user profile fields
   ============================================================ */
function newspress_author_social_fields( $user ) {
    $fields = array(
        'np_author_facebook'  => __( 'Facebook URL',  'newspress' ),
        'np_author_instagram' => __( 'Instagram URL', 'newspress' ),
        'np_author_twitter'   => __( 'X/Twitter URL', 'newspress' ),
        'np_author_youtube'   => __( 'YouTube URL',   'newspress' ),
    );
    echo '<h3>' . esc_html__( 'Social Links (NewsPress)', 'newspress' ) . '</h3>';
    echo '<table class="form-table">';
    foreach ( $fields as $key => $label ) {
        $val = esc_attr( get_the_author_meta( $key, $user->ID ) );
        echo '<tr><th><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th>';
        echo '<td><input type="url" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . $val . '" class="regular-text"></td></tr>';
    }
    echo '</table>';
}
add_action( 'show_user_profile', 'newspress_author_social_fields' );
add_action( 'edit_user_profile', 'newspress_author_social_fields' );

function newspress_save_author_social_fields( $user_id ) {
    if ( ! current_user_can( 'edit_user', $user_id ) ) return;
    foreach ( array( 'np_author_facebook', 'np_author_instagram', 'np_author_twitter', 'np_author_youtube' ) as $key ) {
        if ( isset( $_POST[ $key ] ) ) {
            update_user_meta( $user_id, $key, esc_url_raw( $_POST[ $key ] ) );
        }
    }
}
add_action( 'personal_options_update',  'newspress_save_author_social_fields' );
add_action( 'edit_user_profile_update', 'newspress_save_author_social_fields' );
