<?php
/**
 * NewsPress Performance Optimizations
 *
 * Handles all theme-side Core Web Vitals improvements:
 *  - Non-blocking stylesheet loading (preload + async swap)
 *  - Inline critical CSS per template (renders above the fold with zero blocking)
 *  - LCP image preload with imagesrcset / imagesizes hints
 *  - Single-post LCP featured image preload
 *  - WordPress head cleanup (oEmbed, REST API links, self-pingbacks)
 *  - Embed script removal (saves ~12 KB JS, zero-blocking)
 *  - Google Fonts async loading with preconnect
 *  - Image loading attributes (eager/lazy/fetchpriority) per context
 *  - Explicit width + height on attachment images for CLS = 0
 *  - Ad/widget placeholder dimensions (prevent layout shift)
 *  - Tap-target and font-display improvements
 *
 * What this file does NOT handle:
 *  Caching, CDN, compression, minification — those belong in a cache plugin.
 *
 * @package NewsPress
 */

defined( 'ABSPATH' ) || exit;


/* ============================================================
   1. NON-BLOCKING STYLESHEET LOADING
   Strategy: output a <link rel="preload"> that swaps to stylesheet
   via onload. A <noscript> fallback ensures bots and no-JS users
   still receive styling. This eliminates the render-blocking
   stylesheet entirely.
   ============================================================ */

/**
 * Convert the main theme stylesheet from blocking to async-preload.
 * Called on style_loader_tag filter at priority 20.
 */
function newspress_async_stylesheet( $tag, $handle ) {
    // Only touch our own stylesheet; leave everything else alone
    if ( 'newspress-style' !== $handle ) {
        return $tag;
    }

    // Extract the href so we can rebuild the tag precisely
    if ( ! preg_match( "/href='([^']+)'/", $tag, $m ) ) {
        return $tag; // can't parse — return unchanged to be safe
    }
    $href = esc_url( $m[1] );

    // Preload tag — browser fetches with high priority but does not block rendering
    // onload swaps media from "print" to "all" once the file is downloaded
    // The &#39; encoding prevents PHP string interpolation issues with quotes
    $async = sprintf(
        '<link rel="preload" href="%1$s" as="style" onload="this.onload=null;this.rel=\'stylesheet\'">' . "\n" .
        '<noscript><link rel="stylesheet" href="%1$s"></noscript>' . "\n",
        $href
    );

    return $async;
}
add_filter( 'style_loader_tag', 'newspress_async_stylesheet', 20, 2 );


/* ============================================================
   2. INLINE CRITICAL CSS
   Only the CSS needed to render above-the-fold content without
   flash of unstyled content (FOUC). This replaces the blocking
   stylesheet for first render.

   Kept intentionally minimal (~4 KB) — covers:
     • CSS custom properties (overridden by Customizer inline style)
     • Box-model reset + base typography
     • Layout skeleton (container, site-content grid)
     • Topbar + header + nav (always visible on load)
     • Hero section + card grid skeleton (homepage LCP area)
     • Aspect-ratio placeholders (prevents CLS while full CSS loads)
   ============================================================ */

function newspress_inline_critical_css() {
    // Skip in Customizer preview — full stylesheet is already loaded there
    if ( is_customize_preview() ) {
        return;
    }
    ?>
<style id="np-critical">
/* Critical CSS — above-the-fold rendering path */
/* style.css (.np-dark-mode, ~line 1250) is the single CANONICAL source for
   dark-mode variables — change colors there, not here.
   The 6 declarations below are a REQUIRED, intentional duplicate: this
   <style> block is the only CSS available before the main stylesheet
   (async-loaded, see newspress_async_stylesheet() above) has finished
   loading. header.php's no-flash bootstrap script adds .np-dark-mode to
   <body> for a returning dark-mode visitor before first paint; without
   this duplicate, that visitor would briefly see light-mode colors under
   a dark-mode body class (a flash of wrong colors) until style.css
   arrives. If the canonical values in style.css ever change, update this
   copy to match. */
.np-dark-mode{--np-text:#e0e0e0;--np-text-muted:#9e9e9e;--np-bg:#121212;--np-bg-alt:#1e1e1e;--np-border:#2c2c2c;--np-header-bg:#1a1a1a}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{overflow-x:hidden;font-size:var(--np-font-size,16px);-webkit-text-size-adjust:100%}
body{font-family:var(--np-font-body,Georgia,serif);color:var(--np-text,#212121);background:var(--np-bg,#fff);overflow-x:hidden}
img,picture,video,canvas,svg{display:block;max-width:100%;height:auto}
a{color:var(--np-primary,#d32f2f);text-decoration:none}
h1,h2,h3,h4,h5,h6{font-family:var(--np-font-heading,Arial,sans-serif);line-height:1.3;color:var(--np-text,#212121);font-weight:700}
/* Skip link */
.skip-link{position:absolute;top:-999px;left:1rem;z-index:9999;padding:.75em 1.5em;background:var(--np-primary,#d32f2f);color:#fff;font-weight:700}
.skip-link:focus{top:0}
.screen-reader-text{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
/* Container */
.np-container{max-width:var(--np-container,1200px);width:100%;margin:0 auto;padding:0 1rem}
/* Layout grid — prevents reflow when sidebar loads */
.np-site-content{display:grid;grid-template-columns:1fr var(--np-sidebar-width,300px);grid-template-areas:"main sidebar";gap:2rem;padding:2rem 0}
.np-site-content .np-main{grid-area:main;min-width:0}
.np-site-content .np-sidebar{grid-area:sidebar;min-width:0}
.np-site-content.np-no-sidebar{grid-template-columns:1fr;grid-template-areas:"main"}
.np-site-content.np-no-sidebar .np-sidebar{display:none}
.np-site-content.np-left-sidebar{grid-template-columns:var(--np-sidebar-width,300px) 1fr;grid-template-areas:"sidebar main"}
/* Topbar */
.np-topbar{background:var(--np-topbar-bg,#212121);color:var(--np-topbar-text,#fff);font-size:.75rem;line-height:1}
.np-topbar .np-container{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding-top:.5rem;padding-bottom:.5rem}
/* Footer width */
.np-footer .np-container{max-width:var(--np-footer-width,var(--np-container,1200px))}
.np-footer-boxed .np-footer{max-width:var(--np-footer-width,var(--np-container,1200px));margin-left:auto;margin-right:auto}
/* Header/menu width */
.np-site-header .np-container{max-width:var(--np-header-width,var(--np-container,1200px))}
.np-main-nav .np-container,.np-secondary-nav .np-container{max-width:var(--np-nav-width,var(--np-container,1200px))}
.np-header-boxed .np-site-header{max-width:var(--np-header-width,var(--np-container,1200px));margin-left:auto;margin-right:auto}
.np-nav-boxed .np-main-nav,.np-nav-boxed .np-secondary-nav{max-width:var(--np-nav-width,var(--np-container,1200px));margin-left:auto;margin-right:auto}
/* Header */
.np-site-header{background:var(--np-header-bg,#fff);border-bottom:1px solid var(--np-border,#e0e0e0);position:sticky;top:0;z-index:100}
.np-header-inner{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding-top:var(--np-header-pad,16px);padding-bottom:var(--np-header-pad,16px)}
.np-site-branding{display:flex;align-items:center;gap:.75rem;flex-shrink:0}
.np-site-logo{display:block;min-height:var(--np-logo-height,60px)}
.np-site-logo img{height:var(--np-logo-height,60px);width:auto;max-width:100%}
.np-site-title{font-family:var(--np-font-heading,Arial,sans-serif);font-size:var(--np-site-title-size,28px);font-weight:900;color:var(--np-text,#212121);line-height:1.1;text-transform:uppercase}
/* Nav */
.np-main-nav{background:var(--np-nav-bg,#d32f2f);position:relative;z-index:400}
.np-main-nav .np-container{position:relative;overflow:visible}
.np-nav-menu{display:flex;list-style:none;margin:0;padding:0;gap:0}
.np-nav-menu > li > a{display:flex;align-items:center;min-height:44px;padding:0 1.1em;color:var(--np-nav-text,#fff);font-size:.875rem;font-weight:700;white-space:nowrap;text-decoration:none}
.np-menu-toggle{display:none}
.np-sub-toggle{display:none}
/* Hero — explicit dimensions prevent CLS */
.np-hero-grid{display:grid;grid-template-columns:2fr 1fr;grid-template-rows:auto auto;gap:1rem}
.np-hero-main{grid-row:span 2;position:relative;overflow:hidden;border-radius:var(--np-radius,4px)}
.np-hero-main img{width:100%;height:400px;object-fit:cover;display:block}
.np-hero-side{border-radius:var(--np-radius,4px);overflow:hidden;position:relative}
.np-hero-side img{width:100%;height:188px;object-fit:cover;display:block}
/* Card grid skeleton — aspect-ratio holds space before images load */
.np-posts-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem}
.np-card{background:var(--np-bg,#fff);border-radius:var(--np-radius,4px);overflow:hidden;display:flex;flex-direction:column}
.np-card-thumb{overflow:hidden;aspect-ratio:16/9}
.np-card-thumb img{width:100%;height:100%;object-fit:cover;display:block}
/* Section heading */
.np-section-heading{display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;padding-bottom:.5rem;border-bottom:3px solid var(--np-primary,#d32f2f)}
/* Ad placeholders — reserve space to prevent layout shift */
.np-ad-slot{display:block;width:100%;background:var(--np-bg-alt,#f5f5f5)}
.np-ad-slot.np-ad-header{min-height:90px}
.np-ad-slot.np-ad-in-feed{min-height:250px}
.np-ad-slot.np-ad-sidebar-1,.np-ad-slot.np-ad-sidebar-2{min-height:250px}
/* Reading progress bar */
#np-read-progress{position:fixed;top:0;left:0;height:3px;background:var(--np-primary,#d32f2f);z-index:9999;width:0;transition:width .1s linear}
/* Mobile — match main responsive breakpoint */
@media(max-width:768px){
    .np-site-logo{min-height:var(--np-logo-height-mobile,60px)}
    .np-site-logo img{height:var(--np-logo-height-mobile,60px)}
    .np-site-content,.np-site-content.np-left-sidebar{grid-template-columns:1fr;grid-template-areas:"main" "sidebar"}
    .np-hero-grid{grid-template-columns:1fr}
    .np-hero-main{grid-row:span 1}
    .np-hero-main img{height:240px}
    .np-menu-toggle{display:flex;align-items:center;gap:.5rem;background:transparent;border:2px solid var(--np-nav-text,#fff);color:var(--np-nav-text,#fff);padding:.35em .75em;min-height:44px;min-width:44px;cursor:pointer;touch-action:manipulation;-webkit-tap-highlight-color:transparent;border-radius:4px;font-size:.875rem;font-weight:700}
    /* Off-canvas panel — fixed position escapes overflow:hidden containers */
    .np-nav-menu{display:flex!important;flex-direction:column;position:fixed;top:0;left:0;width:min(85vw,320px);height:100vh;overflow-y:auto;background:var(--np-nav-bg,#d32f2f);z-index:9000;padding-top:60px;transform:translateX(-100%);visibility:hidden;transition:transform .28s cubic-bezier(.4,0,.2,1),visibility 0s linear .28s}
    .np-nav-menu.np-open{transform:translateX(0);visibility:visible;transition:transform .28s cubic-bezier(.4,0,.2,1),visibility 0s linear 0s}
    .np-posts-grid{grid-template-columns:1fr 1fr}
}
@media(max-width:480px){
    .np-posts-grid{grid-template-columns:1fr}
    .np-hero-main img{height:200px}
}
</style>
    <?php
}
// Priority 5 — output before wp_head() adds anything else,
// but after newspress_customizer_css (priority 8) adds :root vars
// Actually run at priority 3 so it's first, relying on CSS cascade
// with the customizer vars at priority 8 overriding the fallback values
add_action( 'wp_head', 'newspress_inline_critical_css', 3 );


/* ============================================================
   3. LCP IMAGE PRELOAD — HOMEPAGE HERO
   Enhanced version: includes imagesrcset + imagesizes so the
   browser can select the correct responsive variant immediately,
   avoiding a 2-request waterfall (preload → srcset negotiation).
   ============================================================ */

/**
 * Replace the simple hero preload with a full imagesrcset preload.
 * Works on homepage and front page only.
 */
remove_action( 'wp_head', 'newspress_preload_hero', 2 );

function newspress_preload_lcp_hero() {
    if ( ! ( is_home() || is_front_page() ) ) return;

    // Use a transient to avoid a DB query on every page load
    $cached = get_transient( 'np_lcp_preload' );

    if ( false === $cached ) {
        $cached = array( 'src' => '', 'srcset' => '', 'sizes' => '' );

        // Find the lead post (sticky first, then most recent)
        $sticky = get_option( 'sticky_posts' );
        $pid    = ! empty( $sticky ) ? (int) $sticky[0] : null;
        if ( ! $pid ) {
            $recent = get_posts( array( 'numberposts' => 1, 'fields' => 'ids', 'no_found_rows' => true, 'update_post_meta_cache' => false ) );
            $pid    = ! empty( $recent ) ? (int) $recent[0] : null;
        }

        if ( $pid && has_post_thumbnail( $pid ) ) {
            $tid = get_post_thumbnail_id( $pid );

            // Primary source at hero size
            $img = wp_get_attachment_image_src( $tid, 'newspress-hero' );
            if ( $img ) {
                $cached['src'] = $img[0];
            }

            // Full srcset for responsive preload (imagesrcset attribute)
            $srcset = wp_get_attachment_image_srcset( $tid, 'newspress-hero' );
            if ( $srcset ) {
                $cached['srcset'] = $srcset;
            }

            // Matching sizes descriptor
            $sizes = wp_get_attachment_image_sizes( $tid, 'newspress-hero' );
            if ( $sizes ) {
                $cached['sizes'] = $sizes;
            }
        }

        set_transient( 'np_lcp_preload', $cached, HOUR_IN_SECONDS );
    }

    if ( empty( $cached['src'] ) ) return;

    // Build the preload link — imagesrcset lets the browser pick the right size
    $tag = '<link rel="preload" as="image" href="' . esc_url( $cached['src'] ) . '"';
    if ( ! empty( $cached['srcset'] ) ) {
        $tag .= ' imagesrcset="' . esc_attr( $cached['srcset'] ) . '"';
    }
    if ( ! empty( $cached['sizes'] ) ) {
        $tag .= ' imagesizes="' . esc_attr( $cached['sizes'] ) . '"';
    }
    $tag .= ' fetchpriority="high">' . "\n";

    echo $tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_head', 'newspress_preload_lcp_hero', 2 );

// Invalidate on post publish/update (already handled by save_post hook in functions.php)
add_action( 'save_post', function( $post_id ) {
    if ( ! wp_is_post_revision( $post_id ) ) {
        delete_transient( 'np_lcp_preload' );
    }
} );


/* ============================================================
   4. LCP IMAGE PRELOAD — SINGLE POST FEATURED IMAGE
   On single posts the featured image IS the LCP element.
   Preload it with the correct srcset before the DOM is parsed.
   ============================================================ */

function newspress_preload_single_lcp() {
    if ( ! is_singular( 'post' ) ) return;
    if ( ! has_post_thumbnail() ) return;

    // Only preload when the image is shown (not explicitly hidden)
    if ( ! get_theme_mod( 'np_single_show_featured', true ) ) return;

    $tid   = get_post_thumbnail_id();
    $size  = ( get_theme_mod( 'np_single_image_style', 'full' ) === 'banner' )
             ? 'newspress-wide'
             : 'newspress-wide';

    $img = wp_get_attachment_image_src( $tid, $size );
    if ( ! $img ) return;

    $srcset = wp_get_attachment_image_srcset( $tid, $size );
    $sizes  = wp_get_attachment_image_sizes( $tid, $size );

    $tag = '<link rel="preload" as="image" href="' . esc_url( $img[0] ) . '"';
    if ( $srcset ) $tag .= ' imagesrcset="' . esc_attr( $srcset ) . '"';
    if ( $sizes )  $tag .= ' imagesizes="'  . esc_attr( $sizes  ) . '"';
    $tag .= ' fetchpriority="high">' . "\n";

    echo $tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_head', 'newspress_preload_single_lcp', 2 );


/* ============================================================
   5. GOOGLE FONTS — ASYNC WITH PRECONNECT
   Moved here from newspress_enqueue() so the preconnect hints
   fire at the correct priority and the font URL is built once.
   The font stylesheet loads async via print/onload trick — this
   is the fastest non-blocking approach that doesn't require JS.
   ============================================================ */

function newspress_font_loading() {
    // Collect non-system font selections
    $selections = array_filter( array(
        get_theme_mod( 'np_font_body',    'sys:Georgia' ),
        get_theme_mod( 'np_font_heading', 'sys:Arial' ),
        get_theme_mod( 'np_google_font',  '' ),
    ) );

    $to_load = array();
    foreach ( $selections as $f ) {
        if ( strpos( $f, 'sys:' ) !== 0 && $f !== '' ) {
            $to_load[] = $f;
        }
    }
    $to_load = array_unique( $to_load );

    if ( empty( $to_load ) ) return;

    // Build a combined URL — one request for all fonts
    $family_params = array();
    foreach ( $to_load as $family ) {
        $family_params[] = 'family=' . urlencode( $family ) . ':ital,wght@0,400;0,600;0,700;1,400';
    }
    $font_url = 'https://fonts.googleapis.com/css2?' . implode( '&', $family_params ) . '&display=swap';
    $font_url = esc_url( $font_url );

    // Preconnect — tells the browser to establish the connection before
    // the font request fires, shaving ~100–200 ms off the waterfall
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";

    // Load the font CSS async — does not block rendering
    // onload swap fires once the stylesheet is downloaded
    printf(
        '<link rel="stylesheet" href="%s" media="print" onload="this.media=\'all\';this.onload=null">' . "\n" .
        '<noscript><link rel="stylesheet" href="%s"></noscript>' . "\n",
        $font_url,
        $font_url
    );
}
// Priority 4 — after critical CSS (3) but before customizer vars (8)
add_action( 'wp_head', 'newspress_font_loading', 4 );


/* ============================================================
   6. WORDPRESS HEAD CLEANUP
   Remove tags that add bytes and HTTP requests without providing
   any user-facing value. None of these affect SEO or functionality.
   ============================================================ */

function newspress_cleanup_head() {
    // Already removed in functions.php: wp_generator, wlwmanifest, rsd_link,
    // wp_shortlink_wp_head, adjacent_posts_rel_link_wp_head

    // REST API link — exposes endpoints, not needed in <head>
    remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );

    // oEmbed discovery links — only needed if your site is embedded elsewhere
    remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );

    // Feed links — already discoverable; saves 2 HTTP requests in <head>
    // Comment out the next line if you want RSS autodiscovery preserved
    remove_action( 'wp_head', 'feed_links',       2 );
    remove_action( 'wp_head', 'feed_links_extra', 3 );

    // Self-pingbacks — WordPress pings itself when you update posts, causing
    // spurious comment notifications. Disable without affecting external pingbacks.
    add_action( 'pre_ping', function( &$links ) {
        $home = home_url();
        foreach ( $links as $key => $link ) {
            if ( 0 === strpos( $link, $home ) ) {
                unset( $links[ $key ] );
            }
        }
    } );
}
add_action( 'init', 'newspress_cleanup_head' );


/* ============================================================
   7. DISABLE WORDPRESS EMBEDS (oEmbed JS)
   The wp-embed.js script (~3.5 KB) is loaded on every page to
   allow your posts to be embedded on other sites. If you don't
   need that feature, removing it eliminates a script request.
   oEmbed consumption (embedding YouTube/Twitter) still works.
   ============================================================ */

function newspress_disable_embeds() {
    // Remove the embed rewrite rules
    add_filter( 'rewrite_rules_array', function( $rules ) {
        foreach ( $rules as $rule => $rewrite ) {
            if ( false !== strpos( $rewrite, 'embed=true' ) ) {
                unset( $rules[ $rule ] );
            }
        }
        return $rules;
    } );

    // Remove the embed query var
    add_filter( 'query_vars', function( $vars ) {
        return array_diff( $vars, array( 'embed' ) );
    } );

    // Remove the embed template redirect
    remove_action( 'template_redirect', 'wp_oembed_template_redirect' );

    // Remove the wp-embed.js script from frontend
    add_action( 'wp_footer', function() {
        wp_dequeue_script( 'wp-embed' );
    } );

    // Remove oEmbed provider script injection (the JS that powers embedding)
    remove_action( 'wp_head', 'wp_oembed_add_host_js' );
}
add_action( 'init', 'newspress_disable_embeds' );


/* ============================================================
   8. IMAGE LOADING ATTRIBUTES — PER CONTEXT
   Extended version of the existing newspress_lazy_images() filter.
   Adds explicit width/height when missing (prevents CLS).
   Ensures fetchpriority="high" only on the actual LCP image.
   Uses decoding="async" on all lazy images for parallelism.
   ============================================================ */

/**
 * Override the existing lazy image filter with an improved version.
 * Remove the old one first to avoid double-filtering.
 */
remove_filter( 'wp_get_attachment_image_attributes', 'newspress_lazy_images', 10 );

function newspress_image_attributes( $attr, $attachment, $size ) {
    // Sizes that are always above the fold and are LCP candidates —
    // these are ALWAYS eager, regardless of the Lazy Load setting, so
    // featured images, hero images, and logos never break.
    static $lcp_sizes = array( 'newspress-hero', 'newspress-wide', 'full' );

    // "Lazy Load Images" — NewsPress Settings → Performance (np_perf_lazy_load).
    $lazy_enabled = (bool) get_option( 'np_perf_lazy_load', true );

    if ( in_array( $size, $lcp_sizes, true ) ) {
        // LCP / above-fold image — eager, high priority, synchronous decode
        $attr['loading']        = 'eager';
        $attr['fetchpriority']  = 'high';
        $attr['decoding']       = 'sync'; // sync decode avoids frame-delay on LCP
    } elseif ( $lazy_enabled ) {
        // Below-fold image — lazy, async decode, normal priority
        $attr['loading']   = 'lazy';
        $attr['decoding']  = 'async';
        // Explicitly remove fetchpriority if it was set elsewhere
        unset( $attr['fetchpriority'] );
    } else {
        // Lazy loading turned OFF by the admin — the optimization must not
        // run. Force eager so a template's hardcoded loading="lazy" (e.g.
        // card templates) doesn't silently keep lazy-loading anyway.
        $attr['loading'] = 'eager';
        unset( $attr['fetchpriority'], $attr['decoding'] );
    }

    // Ensure width and height are always present — prevents CLS
    // WordPress 5.5+ sets these automatically, but verify for safety
    if ( empty( $attr['width'] ) || empty( $attr['height'] ) ) {
        $meta = wp_get_attachment_metadata( $attachment->ID );
        if ( ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) {
            // Use the registered size dimensions if available
            $registered = wp_get_registered_image_subsizes();
            if ( isset( $registered[ $size ] ) ) {
                $attr['width']  = $registered[ $size ]['width'];
                $attr['height'] = $registered[ $size ]['height'];
            } else {
                $attr['width']  = $meta['width'];
                $attr['height'] = $meta['height'];
            }
        }
    }

    return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'newspress_image_attributes', 10, 3 );


/* ============================================================
   9. CARD GRID IMAGE — RESPONSIVE SIZES ATTRIBUTE
   WordPress generates srcset automatically but the default
   sizes attribute ("100vw") causes browsers to fetch larger
   images than needed in grid layouts. Override with accurate
   sizes based on the actual layout column widths.
   ============================================================ */

/**
 * Add accurate sizes attribute to card thumbnail images.
 * Called via filter on post_thumbnail_html.
 */
add_filter( 'post_thumbnail_html', 'newspress_card_image_sizes', 10, 5 );
function newspress_card_image_sizes( $html, $post_id, $thumbnail_id, $size, $attr ) {
    // Only touch card-size images in archive/grid contexts
    if ( 'newspress-card' !== $size ) return $html;
    if ( is_singular() ) return $html; // not in grid on single posts

    // Accurate sizes:
    // ≥ 1200px container → 3-col grid → each col ~360px
    // 768–1200px → 2-col grid → each col ~540px
    // < 768px → 2-col → ~45vw
    // < 480px → 1-col → ~95vw
    $sizes = '(max-width: 480px) 95vw, (max-width: 768px) 45vw, (max-width: 1200px) 30vw, 360px';

    // Replace the existing sizes attribute (WordPress default is "100vw")
    $html = preg_replace( '/sizes="[^"]*"/', 'sizes="' . esc_attr( $sizes ) . '"', $html );

    return $html;
}


/* ============================================================
   10. FONT-DISPLAY: SWAP IN CUSTOMIZER-LOADED FONTS
   When Google Fonts aren't used and a system/local font is
   selected, ensure the @font-face rules use display:swap
   so text renders immediately in the fallback font.
   ============================================================ */

add_filter( 'style_loader_tag', 'newspress_font_display_swap', 10, 2 );
function newspress_font_display_swap( $tag, $handle ) {
    // Only touch Google Fonts loaded by WordPress (e.g. via wp_enqueue_style)
    if ( false !== strpos( $handle, 'google-fonts' ) || false !== strpos( $handle, 'gfonts' ) ) {
        $tag = str_replace( "rel='stylesheet'", "rel='stylesheet' media='print' onload=\"this.media='all';this.onload=null\"", $tag );
    }
    return $tag;
}


/* ============================================================
   11. CONTENT IMAGE LAZY LOADING
   Ensure all images inserted via the block editor or classic
   editor get loading="lazy" and decoding="async" automatically.
   WordPress 5.5+ does this natively, but this filter provides
   an explicit override and also handles the_content filter path.
   ============================================================ */

// Iframes (YouTube, maps, etc.) in content — already handled in functions.php
// This adds explicit lazy load to any <img> in content that might have missed it
add_filter( 'the_content', 'newspress_content_lazy_images', 20 );
function newspress_content_lazy_images( $content ) {
    if ( empty( $content ) ) return $content;
    // "Lazy Load Images" — NewsPress Settings → Performance.
    if ( ! get_option( 'np_perf_lazy_load', true ) ) return $content;

    // Skip images that already have loading="eager" (above fold, set explicitly)
    // Add loading="lazy" to any <img> missing a loading attribute
    $content = preg_replace_callback(
        '/<img(?![^>]*\bloading=)[^>]+>/i',
        function( $matches ) {
            // Insert loading="lazy" decoding="async" before the closing >
            return str_replace( '>', ' loading="lazy" decoding="async">', $matches[0] );
        },
        $content
    );

    return $content;
}


/* ============================================================
   12. PRELOAD PRIMARY FONT FILE (optional, first-paint)
   If a Google Font is selected, we can preload one specific
   woff2 file for the most common script (latin) to eliminate
   the render-blocking flash of invisible text (FOIT).
   This is optional but helps when a custom headline font is set.
   ============================================================ */

function newspress_preload_primary_font() {
    $heading_font = get_theme_mod( 'np_font_heading', 'sys:Arial' );

    // Skip system fonts — they don't need preloading
    if ( empty( $heading_font ) || strpos( $heading_font, 'sys:' ) === 0 ) return;

    // We can't know the exact woff2 URL without calling Google Fonts API,
    // so instead we ensure the fonts.gstatic.com preconnect fires early
    // (already done in newspress_font_loading at priority 4)
    // This function is a hook point for future woff2 preload when URL is known.
}
add_action( 'wp_head', 'newspress_preload_primary_font', 3 );


/* ============================================================
   13. PREVENT DUPLICATE STYLE/SCRIPT REGISTRATION
   Some plugins register styles that duplicate what the theme
   already provides. Dequeue known conflicts here.
   ============================================================ */

add_action( 'wp_enqueue_scripts', 'newspress_dequeue_conflicts', 100 );
function newspress_dequeue_conflicts() {
    // Dequeue block library styles on pages that don't use Gutenberg blocks
    // This saves ~80 KB on archive/search pages that only show card excerpts
    if ( ! is_singular() && ! is_page() ) {
        wp_dequeue_style( 'wp-block-library' );
        wp_dequeue_style( 'wp-block-library-theme' );
        wp_dequeue_style( 'global-styles' ); // WP 5.9+ global styles
    }

    // Classic themes: disable the classic-themes.css that adds block gaps
    wp_dequeue_style( 'classic-theme-styles' );
}


/* ============================================================
   14. RESOURCE HINTS — UPDATED
   Replaces the existing newspress_resource_hints() function
   with an improved version that also fires preconnect for
   fonts unconditionally (they're always loaded if font is set).
   ============================================================ */

remove_filter( 'wp_resource_hints', 'newspress_resource_hints', 10 );

add_filter( 'wp_resource_hints', 'newspress_resource_hints_v2', 10, 2 );
function newspress_resource_hints_v2( $hints, $relation_type ) {
    // "Resource Hints" — NewsPress Settings → Performance (np_perf_resource_hints).
    if ( ! get_option( 'np_perf_resource_hints', true ) ) {
        return $hints;
    }
    $has_gfont = false;
    $selections = array(
        get_theme_mod( 'np_font_body',    'sys:Georgia' ),
        get_theme_mod( 'np_font_heading', 'sys:Arial' ),
        get_theme_mod( 'np_google_font',  '' ),
    );
    foreach ( $selections as $f ) {
        if ( $f && strpos( $f, 'sys:' ) !== 0 ) {
            $has_gfont = true;
            break;
        }
    }

    if ( 'preconnect' === $relation_type && $has_gfont ) {
        $hints[] = array( 'href' => 'https://fonts.googleapis.com' );
        $hints[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous' );
    }

    if ( 'dns-prefetch' === $relation_type && $has_gfont ) {
        $hints[] = array( 'href' => '//fonts.googleapis.com' );
        $hints[] = array( 'href' => '//fonts.gstatic.com' );
    }

    return $hints;
}


/* ============================================================
   15. CLEAN UP ENQUEUE FUNCTION
   Remove the duplicate Google Fonts loader and fetchpriority
   tag injection that now live in this file.
   ============================================================ */

// Remove the inline fetchpriority filter added inside newspress_enqueue()
// (it was added as an anonymous closure so we use a flag approach instead)
add_filter( 'style_loader_tag', function( $tag, $handle ) {
    if ( 'newspress-style' === $handle ) {
        // Remove the fetchpriority='high' that was added by newspress_enqueue()
        // since the async preload approach supersedes it
        $tag = str_replace( " fetchpriority='high'", '', $tag );
    }
    return $tag;
}, 30, 2 ); // priority 30 runs after newspress_async_stylesheet (20)
