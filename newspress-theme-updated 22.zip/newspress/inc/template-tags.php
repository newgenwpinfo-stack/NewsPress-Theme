<?php
/**
 * Template Tags
 *
 * @package NewsPress
 */

defined( 'ABSPATH' ) || exit;

/**
 * Post meta bar (date, author, category, reading time)
 */
function newspress_post_meta( $show_cat = false, $show_author = true, $show_time = true ) {
    $html = '<div class="np-card-meta">';

    if ( get_theme_mod( 'np_show_date', true ) ) {
        $format = get_theme_mod( 'np_date_format', 'M j, Y' );
        if ( $format === 'ago' ) {
            $date_str = human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) . ' ago';
        } else {
            $date_str = get_the_date( $format );
        }
        $html .= '<time class="np-date" datetime="' . esc_attr( get_the_date( 'c' ) ) . '">' . esc_html( $date_str ) . '</time>';
    }

    if ( $show_author && get_theme_mod( 'np_show_author', true ) ) {
        $html .= '<span class="np-author"><a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>';
    }

    if ( $show_time && get_theme_mod( 'np_show_reading_time', true ) ) {
        $html .= '<span class="np-read-time">' . esc_html( newspress_reading_time() ) . '</span>';
    }

    $html .= '</div>';
    echo $html;
}

/**
 * Category badge (first category only)
 */
function newspress_category_badge() {
    if ( ! get_theme_mod( 'np_show_cats', true ) ) return;
    if ( get_theme_mod( 'np_badge_position', 'above-title' ) === 'none' ) return;
    $cats = get_the_category();
    if ( $cats ) {
        echo '<a href="' . esc_url( get_category_link( $cats[0]->term_id ) ) . '" class="np-category-badge">' . esc_html( $cats[0]->name ) . '</a>';
    }
}

/**
 * Thumbnail with fallback
 */
function newspress_thumbnail( $size = 'newspress-card', $attrs = [] ) {
    if ( has_post_thumbnail() ) {
        the_post_thumbnail( $size, array_merge( [ 'loading' => 'lazy' ], $attrs ) );
    } else {
        echo '<div class="np-no-image" aria-hidden="true">📰</div>';
    }
}

/**
 * Share buttons
 */
function newspress_share_buttons() {
    if ( ! get_theme_mod( 'np_show_share', true ) ) return;

    $url   = urlencode( get_permalink() );
    $title = urlencode( get_the_title() );

    echo '<div class="np-share" role="group" aria-label="' . esc_attr__( 'Share this article', 'newspress' ) . '">';
    echo '<span class="np-share-label">' . esc_html__( 'Share:', 'newspress' ) . '</span>';
    echo '<a href="https://www.facebook.com/sharer/sharer.php?u=' . $url . '" class="np-share-btn np-fb" target="_blank" rel="noopener noreferrer">Facebook</a>';
    echo '<a href="https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title . '" class="np-share-btn np-tw" target="_blank" rel="noopener noreferrer">Twitter</a>';
    echo '<a href="https://wa.me/?text=' . $title . '%20' . $url . '" class="np-share-btn np-wa" target="_blank" rel="noopener noreferrer">WhatsApp</a>';
    echo '<a href="https://www.linkedin.com/shareArticle?mini=true&url=' . $url . '&title=' . $title . '" class="np-share-btn np-li" target="_blank" rel="noopener noreferrer">LinkedIn</a>';
    echo '<button class="np-share-btn np-copy" onclick="var t=this;navigator.clipboard.writeText(window.location.href).then(function(){t.textContent=\'Copied!\';setTimeout(function(){t.textContent=\'Copy Link\';},2000);})" aria-label="' . esc_attr__( 'Copy link', 'newspress' ) . '">Copy Link</button>';
    echo '</div>';
}

/**
 * Author box
 */
function newspress_author_box() {
    if ( ! get_theme_mod( 'np_show_author_box', true ) ) return;

    $author_id      = get_the_author_meta( 'ID' );
    $author_url     = get_author_posts_url( $author_id );
    $bio            = get_the_author_meta( 'description' );
    $avatar         = get_avatar( $author_id, 80, '', '', array( 'class' => 'np-author-avatar-img' ) );
    $author_website = get_the_author_meta( 'user_url' );

    $socials = array(
        'np_author_facebook'  => array( 'label' => 'Facebook',  'icon' => '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>' ),
        'np_author_instagram' => array( 'label' => 'Instagram', 'icon' => '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/></svg>' ),
        'np_author_twitter'   => array( 'label' => 'X/Twitter', 'icon' => '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>' ),
        'np_author_youtube'   => array( 'label' => 'YouTube',   'icon' => '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>' ),
    );

    echo '<div class="np-author-box">';
    echo '<div class="np-author-box-avatar">';
    if ( $avatar ) echo '<a href="' . esc_url( $author_url ) . '">' . $avatar . '</a>'; // phpcs:ignore
    echo '</div>';
    echo '<div class="np-author-info">';
    echo '<h4><a href="' . esc_url( $author_url ) . '">' . esc_html( get_the_author() ) . '</a></h4>';
    if ( $author_website ) echo '<span class="np-author-website">' . esc_html( $author_website ) . '</span>';
    if ( $bio ) echo '<p class="np-author-bio">' . esc_html( $bio ) . '</p>';

    $social_links = '';
    foreach ( $socials as $meta_key => $s ) {
        $url = get_the_author_meta( $meta_key );
        if ( $url ) {
            $social_links .= '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr( $s['label'] ) . '">' . $s['icon'] . '</a>'; // phpcs:ignore
        }
    }
    if ( ! $social_links && $author_website ) {
        $social_links = '<a href="' . esc_url( $author_website ) . '" target="_blank" rel="noopener noreferrer me" aria-label="Website">🌐</a>';
    }
    if ( $social_links ) echo '<div class="np-author-box-social">' . $social_links . '</div>'; // phpcs:ignore

    echo '</div></div>';
}

/**
 * Related posts
 */
function newspress_related_posts( $count = 3 ) {
    if ( ! get_theme_mod( 'np_show_related', true ) ) return;

    $cats    = wp_get_post_categories( get_the_ID(), array( 'fields' => 'ids' ) );
    $related = new WP_Query( array(
        'post_type'              => 'post',
        'posts_per_page'         => $count,
        'post__not_in'           => array( get_the_ID() ),
        'category__in'           => $cats,
        'no_found_rows'          => true,
        'ignore_sticky_posts'    => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
    ) );

    if ( ! $related->have_posts() ) return;

    echo '<section class="np-related" aria-labelledby="np-related-heading">';
    echo '<div class="np-section-heading"><h2 id="np-related-heading">' . esc_html__( 'Related Articles', 'newspress' ) . '</h2></div>';
    echo '<div class="np-related-grid np-posts-grid np-col-2">';
    while ( $related->have_posts() ) {
        $related->the_post();
        get_template_part( 'template-parts/content/card', 'grid' );
    }
    echo '</div></section>';
    wp_reset_postdata();
}

/**
 * Post tags
 */
function newspress_post_tags() {
    if ( ! get_theme_mod( 'np_show_tags', true ) ) return;
    $tags = get_the_tags();
    if ( ! $tags ) return;

    echo '<div class="np-post-tags"><span class="np-tag-label">' . esc_html__( 'Tags:', 'newspress' ) . '</span>';
    foreach ( $tags as $tag ) {
        echo '<a href="' . esc_url( get_tag_link( $tag->term_id ) ) . '" class="np-tag">' . esc_html( $tag->name ) . '</a>';
    }
    echo '</div>';
}

/**
 * Section heading
 */
function newspress_section_heading( $title, $link = '', $link_text = '', $tab_cats = array() ) {
    if ( ! empty( $tab_cats ) ) {
        // Tabs variant: title badge + category filter links
        echo '<div class="np-section-heading-tabs">';
        echo '<span class="np-section-title">' . esc_html( $title ) . '</span>';
        echo '<div class="np-tab-filters">';
        echo '<a href="#" class="active">' . esc_html__( 'All', 'newspress' ) . '</a>';
        foreach ( $tab_cats as $cat_id => $cat_name ) {
            echo '<a href="' . esc_url( get_category_link( $cat_id ) ) . '">' . esc_html( $cat_name ) . '</a>';
        }
        echo '</div>';
        if ( $link ) echo '<a href="' . esc_url( $link ) . '" class="np-view-all">' . esc_html( $link_text ?: __( 'View All', 'newspress' ) ) . '</a>';
        echo '</div>';
    } else {
        echo '<div class="np-section-heading"><h2>' . esc_html( $title ) . '</h2>';
        if ( $link ) echo '<a href="' . esc_url( $link ) . '">' . esc_html( $link_text ?: __( 'View All', 'newspress' ) ) . '</a>';
        echo '</div>';
    }
}

/**
 * Pagination
 */
/**
 * Render themed pagination.
 * Outputs .np-pagination so all Customizer style controls apply.
 *
 * @param WP_Query|null $query  Pass a custom WP_Query; falls back to global.
 */
function newspress_pagination( $query = null ) {
    global $wp_query;
    $q       = ( $query instanceof WP_Query ) ? $query : $wp_query;
    $paged   = max( 1, get_query_var( 'paged' ) );
    $total   = isset( $q->max_num_pages ) ? (int) $q->max_num_pages : 1;

    if ( $total < 2 ) {
        return;
    }

    $big   = 999999999;
    $pages = paginate_links( array(
        'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
        'format'    => '?paged=%#%',
        'current'   => $paged,
        'total'     => $total,
        'type'      => 'array',
        'mid_size'  => 2,
        'end_size'  => 1,
        'prev_text' => '&laquo;',
        'next_text' => '&raquo;',
    ) );

    if ( $pages ) {
        echo '<nav class="np-pagination" aria-label="' . esc_attr__( 'Pagination', 'newspress' ) . '">';
        foreach ( $pages as $page ) {
            echo $page;
        }
        echo '</nav>';
    }
}

/**
 * Breadcrumb navigation for visual navigation and accessibility.
 * This theme does not generate structured data.
 */
function newspress_breadcrumbs() {
    if ( is_front_page() ) return;

    $home = get_bloginfo('name');
    $html = '<nav class="np-breadcrumbs" aria-label="' . esc_attr__('Breadcrumb','newspress') . '">';
    // Inline styles on ol guarantee no theme/plugin can override list-style with numbers
    $html .= '<ol style="list-style:none!important;margin:0!important;padding:0!important;display:flex;flex-wrap:wrap;align-items:center;">';

    // Home
    $html .= '<li style="list-style:none!important;display:flex;align-items:center;">';
    $html .= '<a href="' . esc_url( home_url('/') ) . '">' . esc_html( $home ) . '</a>';
    $html .= '</li>';

    if ( is_category() ) {
        $cat = get_queried_object();
        $html .= newspress_bc_item( esc_html( $cat->name ), get_term_link( $cat ) );
    } elseif ( is_tag() ) {
        $html .= newspress_bc_item( esc_html( single_tag_title('', false) ), get_tag_link( get_queried_object_id() ) );
    } elseif ( is_singular('post') ) {
        $cats = get_the_category();
        if ( $cats ) {
            $html .= newspress_bc_item( esc_html( $cats[0]->name ), esc_url( get_category_link( $cats[0]->term_id ) ) );
        }
        $html .= newspress_bc_item( esc_html( get_the_title() ), '', true );
    } elseif ( is_page() ) {
        global $post;
        if ( $post->post_parent ) {
            $ancestors = array_reverse( get_post_ancestors( $post->ID ) );
            foreach ( $ancestors as $ancestor ) {
                $html .= newspress_bc_item( esc_html( get_the_title( $ancestor ) ), esc_url( get_permalink( $ancestor ) ) );
            }
        }
        $html .= newspress_bc_item( esc_html( get_the_title() ), '', true );
    } elseif ( is_search() ) {
        $html .= newspress_bc_item( esc_html__('Search Results','newspress') . ': &ldquo;' . esc_html( get_search_query() ) . '&rdquo;', '', true );
    } elseif ( is_404() ) {
        $html .= newspress_bc_item( esc_html__('404 – Not Found','newspress'), '', true );
    } elseif ( is_author() ) {
        $html .= newspress_bc_item( esc_html( get_the_author() ), '', true );
    }

    $html .= '</ol></nav>';
    echo $html;
}

function newspress_bc_item( $name, $url = '', $current = false ) {
    $html = '<li style="list-style:none!important;display:flex;align-items:center;">';
    $html .= '<span class="np-bc-sep" aria-hidden="true" style="margin:0 .4em;color:#bbb;">/</span>';
    if ( $url && ! $current ) {
        $html .= '<a href="' . $url . '">' . $name . '</a>';
    } else {
        $html .= '<span aria-current="page" style="font-weight:600;">' . $name . '</span>';
    }
    $html .= '</li>';
    return $html;
}
