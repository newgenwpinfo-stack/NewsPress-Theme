<?php
/**
 * Template Functions
 *
 * @package NewsPress
 */

defined( 'ABSPATH' ) || exit;

/**
 * Get sidebar CSS class
 */
function newspress_content_class() {
    $pos = get_theme_mod( 'np_sidebar_pos', 'right' );
    $class = 'np-site-content';

    if ( $pos === 'none' ) {
        $class .= ' np-no-sidebar';
    } elseif ( $pos === 'left' ) {
        $class .= ' np-left-sidebar';
    }
    // 'right' = default grid (1fr sidebar-width), no extra class needed
    return $class;
}

/**
 * Get grid class from layout setting
 */
function newspress_grid_class( $layout = null ) {
    $layout = $layout ?: get_theme_mod( 'np_home_posts_layout', 'grid-3' );
    $map = [
        'grid-2' => 'np-posts-grid np-col-2',
        'grid-3' => 'np-posts-grid',
        'grid-4' => 'np-posts-grid np-col-4',
        'list'   => 'np-posts-list',
    ];
    return $map[ $layout ] ?? 'np-posts-grid';
}

/**
 * Display ads slot if configured
 */
function newspress_ad_slot( $size = '728x90', $id = '' ) {
    if ( $id && is_active_sidebar( $id ) ) {
        dynamic_sidebar( $id );
        return;
    }
    $class = 'np-ad-' . $size;
    echo '<div class="np-ad-slot ' . esc_attr( $class ) . '" aria-hidden="true">Advertisement ' . esc_html( $size ) . '</div>';
}

/**
 * Breaking news posts for ticker
 */
function newspress_get_breaking_news( $count = 8 ) {
    $source  = get_theme_mod( 'np_breaking_source', 'latest' );
    $cat_id  = (int) get_theme_mod( 'np_breaking_cat', 0 );
    $transient = 'np_breaking_' . $source . '_' . $cat_id . '_' . $count;
    $posts = get_transient( $transient );

    if ( false === $posts ) {
        $args = array(
            'posts_per_page'         => $count,
            'no_found_rows'          => true,
            'ignore_sticky_posts'    => false,
            'fields'                 => 'ids',
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        );

        if ( $source === 'featured' ) {
            // Featured / Sticky posts
            $args['post__in']         = get_option( 'sticky_posts', array() ) ?: array( 0 );
            $args['ignore_sticky_posts'] = false;
        } elseif ( $source === 'cat' && $cat_id > 0 ) {
            // Specific category by ID
            $args['cat'] = $cat_id;
        }
        // 'latest' falls through with no extra args

        $query = new WP_Query( $args );

        // Fallback to latest if source returned nothing
        if ( ! $query->have_posts() ) {
            $query = new WP_Query( array(
                'posts_per_page'         => $count,
                'no_found_rows'          => true,
                'fields'                 => 'ids',
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ) );
        }
        $posts = $query->posts;
        set_transient( $transient, $posts, 5 * MINUTE_IN_SECONDS );
    }
    return $posts;
}

/**
 * Get the posts for homepage hero section
 */
function newspress_get_hero_posts( $count = 3 ) {
    $args = array(
        'posts_per_page'         => $count,
        'no_found_rows'          => true,
        'ignore_sticky_posts'    => false,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
    );

    $sticky = get_option( 'sticky_posts' );
    if ( $sticky ) {
        $args['post__in'] = array_slice( $sticky, 0, $count );
        $args['orderby']  = 'post__in';
    }

    $query = new WP_Query( $args );

    // If not enough sticky posts, just get latest
    if ( $query->post_count < $count ) {
        $query = new WP_Query( array(
            'posts_per_page'         => $count,
            'no_found_rows'          => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ) );
    }
    return $query;
}

/**
 * Render the hero section
 */
function newspress_render_hero() {
    if ( ! get_theme_mod( 'np_show_hero', true ) ) return;

    $style = get_theme_mod( 'np_home_hero_style', 'grid' );
    if ( 'none' === $style ) return;

    $query = newspress_get_hero_posts( 3 );
    if ( ! $query->have_posts() ) return;

    $posts = array();
    while ( $query->have_posts() ) {
        $query->the_post();
        $posts[] = get_post();
    }
    wp_reset_postdata();

    // Pass data via global (compatible with all WP versions)
    global $np_hero_posts;
    $np_hero_posts = $posts;

    // Fall back to grid if style template doesn't exist
    $template = 'template-parts/content/hero-' . sanitize_key( $style );
    if ( ! locate_template( $template . '.php' ) ) {
        $template = 'template-parts/content/hero-grid';
    }
    get_template_part( $template );
}

/**
 * Check if current page should show sidebar
 */
function newspress_show_sidebar() {
    $pos = get_theme_mod( 'np_sidebar_pos', 'right' );
    if ( $pos === 'none' ) return false;
    // Show sidebar column even if empty - user can add widgets
    return true;
}

/**
 * Sanitize image upload
 */
function newspress_sanitize_image( $image ) {
    $mimes = [ 'jpg|jpeg|jpe', 'gif', 'png', 'bmp', 'tiff|tif', 'ico', 'webp', 'svg' ];
    $file  = wp_check_filetype( $image, wp_get_mime_types() );
    return ( $file['ext'] ) ? $image : '';
}

/* ============================================================
   HOMEPAGE BUILDER
   Reads np_home_sections (JSON array of section configs)
   and renders each block in order.
   ============================================================ */

/**
 * Get the homepage section configuration.
 * Returns array of section objects.
 * Default: latest posts grid only.
 */
function newspress_get_home_sections() {
    $raw = get_theme_mod( 'np_home_sections', '' );
    if ( ! $raw ) {
        // Default layout: hero + latest 3-col grid
        return array(
            array(
                'type'      => 'latest',
                'cat_id'    => 0,
                'layout'    => 'grid-3',
                'count'     => 9,
                'show_more' => true,
                'title'     => '',
                'enabled'   => true,
            ),
        );
    }
    $sections = json_decode( $raw, true );
    return is_array( $sections ) ? $sections : array();
}

/**
 * Render a single homepage section.
 */
function newspress_render_home_section( $section ) {
    if ( empty( $section['enabled'] ) ) return;

    $type = isset( $section['type'] ) ? $section['type'] : 'category';

    switch ( $type ) {

        case 'ad':
            // Ad slot — pure display, widget area
            $slot = isset( $section['slot'] ) ? $section['slot'] : 'before-content';
            if ( is_active_sidebar( $slot ) ) {
                echo '<div class="np-home-ad-row">';
                dynamic_sidebar( $slot );
                echo '</div>';
            }
            break;

        case 'divider':
            echo '<hr class="np-section-divider">';
            break;

        case 'latest':
            // On homepage: inject the pre-built paginated main_query to avoid double query
            // and to get correct max_num_pages for pagination
            $section_args = $section;
            if ( isset( $GLOBALS['np_main_query'] ) && $GLOBALS['np_main_query'] instanceof WP_Query ) {
                $section_args['_query'] = $GLOBALS['np_main_query'];
            }
            get_template_part( 'template-parts/content/section', 'category', $section_args );
            break;

        case 'category':
        default:
            get_template_part( 'template-parts/content/section', 'category', $section );
            break;
    }
}

/**
 * Render all homepage sections in order.
 * Called from index.php instead of inline loop.
 */
function newspress_render_homepage_builder() {
    $sections = newspress_get_home_sections();
    if ( empty( $sections ) ) return;

    echo '<div class="np-homepage-builder">';
    foreach ( $sections as $section ) {
        newspress_render_home_section( $section );
    }
    echo '</div>';
}

/**
 * Render magazine-style layout for a given category.
 * Standalone helper for template use.
 */
function newspress_render_magazine_block( $cat_id, $count = 5, $title = '' ) {
    newspress_render_home_section( array(
        'type'      => 'category',
        'cat_id'    => $cat_id,
        'layout'    => 'magazine',
        'count'     => $count,
        'show_more' => true,
        'title'     => $title,
        'enabled'   => true,
    ) );
}
