<?php
/**
 * Built-in Performance Monitor
 * Shows query count, memory usage, and load time in the admin bar.
 * Only visible to administrators.
 *
 * @package NewsPress
 */

defined( 'ABSPATH' ) || exit;

// Single authoritative source: NewsPress Settings → Performance
// (np_perf_monitor, saved via update_option()). The duplicate Customizer
// control that used to live alongside this has been removed — see the
// Performance settings audit notes.
if ( ! get_option( 'np_perf_monitor', false ) ) {
    return;
}

/* ============================================================
   CAPTURE start time at theme load
   ============================================================ */
if ( ! defined( 'NEWSPRESS_START' ) ) {
    define( 'NEWSPRESS_START', microtime( true ) );
}

/* ============================================================
   ADD ADMIN BAR NODE
   ============================================================ */
add_action( 'admin_bar_menu', 'newspress_perf_admin_bar', 999 );
function newspress_perf_admin_bar( $wp_admin_bar ) {
    if ( ! current_user_can( 'manage_options' ) || is_admin() ) {
        return;
    }

    $load_time = round( ( microtime( true ) - NEWSPRESS_START ) * 1000 );
    $memory    = round( memory_get_peak_usage( true ) / 1024 / 1024, 1 );
    $queries   = get_num_queries();

    // Traffic light colour based on load time
    if ( $load_time < 300 ) {
        $colour = '#4caf50'; // green
    } elseif ( $load_time < 700 ) {
        $colour = '#ff9800'; // orange
    } else {
        $colour = '#f44336'; // red
    }

    $label = sprintf(
        '⚡ %dms &nbsp;|&nbsp; %s MB &nbsp;|&nbsp; %d Q',
        $load_time,
        $memory,
        $queries
    );

    $wp_admin_bar->add_node( array(
        'id'    => 'newspress-perf',
        'title' => '<span style="color:' . $colour . ';font-weight:700;">' . $label . '</span>',
        'href'  => '#',
        'meta'  => array( 'title' => 'NewsPress Performance Monitor' ),
    ) );

    // Sub-nodes with detail
    $wp_admin_bar->add_node( array(
        'parent' => 'newspress-perf',
        'id'     => 'newspress-perf-time',
        'title'  => '🕐 Load time: ' . $load_time . 'ms (target < 400ms)',
    ) );
    $wp_admin_bar->add_node( array(
        'parent' => 'newspress-perf',
        'id'     => 'newspress-perf-mem',
        'title'  => '💾 Peak memory: ' . $memory . 'MB',
    ) );
    $wp_admin_bar->add_node( array(
        'parent' => 'newspress-perf',
        'id'     => 'newspress-perf-queries',
        'title'  => '🗄 DB queries: ' . $queries . ' (target < 25)',
    ) );
    $wp_admin_bar->add_node( array(
        'parent' => 'newspress-perf',
        'id'     => 'newspress-perf-php',
        'title'  => '🐘 PHP: ' . PHP_VERSION . ' | WP: ' . get_bloginfo( 'version' ),
    ) );
}

/* ============================================================
   LOG slow pages to debug.log when WP_DEBUG is on
   ============================================================ */
add_action( 'shutdown', 'newspress_perf_log' );
function newspress_perf_log() {
    if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG || is_admin() ) {
        return;
    }
    $load_time = round( ( microtime( true ) - NEWSPRESS_START ) * 1000 );
    $memory    = round( memory_get_peak_usage( true ) / 1024 / 1024, 1 );
    $queries   = get_num_queries();

    if ( $load_time > 500 || $queries > 30 ) {
        $url = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( $_SERVER['REQUEST_URI'] ) : '?';
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions
        error_log( sprintf(
            '[NewsPress Perf] SLOW PAGE: %s | %dms | %sMB | %d queries',
            $url, $load_time, $memory, $queries
        ) );
    }
}
