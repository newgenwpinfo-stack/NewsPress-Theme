<?php
/**
 * NP_Section_Builder_Control
 * Visual homepage section builder for the Customizer.
 * Replaces the raw JSON textarea with a friendly UI.
 *
 * @package NewsPress
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_Customize_Control' ) ) return;

class NP_Section_Builder_Control extends WP_Customize_Control {

    public $type = 'np_section_builder';

    /** Enqueue the builder JS + CSS */
    public function enqueue() {
        wp_enqueue_script(
            'np-section-builder',
            NEWSPRESS_URI . '/js/section-builder.js',
            array( 'jquery', 'customize-controls' ),
            NEWSPRESS_VERSION,
            true
        );
        // Pass categories to JS
        wp_localize_script( 'np-section-builder', 'npSectionBuilderData', array(
            'categories' => self::get_categories_for_js(),
            'layouts'    => array(
                'grid-3'        => __( 'Grid — 3 columns',    'newspress' ),
                'grid-2'        => __( 'Grid — 2 columns',    'newspress' ),
                'grid-4'        => __( 'Grid — 4 columns',    'newspress' ),
                'list'          => __( 'List view',           'newspress' ),
                'magazine'      => __( 'Magazine (big + small)', 'newspress' ),
                'featured-list' => __( 'Featured + list',    'newspress' ),
            ),
        ) );
    }

    /** Fetch all categories as id → name pairs */
    private static function get_categories_for_js() {
        $cats  = array( array( 'id' => 0, 'name' => __( '— Latest Posts —', 'newspress' ) ) );
        $terms = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false, 'number' => 100 ) );
        if ( ! is_wp_error( $terms ) ) {
            foreach ( $terms as $t ) {
                $cats[] = array( 'id' => (int) $t->term_id, 'name' => esc_html( $t->name ) );
            }
        }
        return $cats;
    }

    /** Render the control HTML skeleton — JS fills it in */
    public function render_content() {
        $value = $this->value();
        ?>
        <label>
            <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php if ( $this->description ) : ?>
                <span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
            <?php endif; ?>
        </label>

        <!-- Hidden field holds the JSON value that WP saves -->
        <input
            type="hidden"
            id="np-sections-json"
            <?php $this->link(); ?>
            value="<?php echo esc_attr( $value ); ?>"
        />

        <!-- Builder UI injected by JS -->
        <div id="np-section-builder" style="margin-top:8px;">
            <div id="np-section-list">
                <!-- rows rendered by section-builder.js -->
            </div>
            <button type="button" id="np-add-section" class="button" style="margin-top:8px;width:100%;">
                + <?php esc_html_e( 'Add Section', 'newspress' ); ?>
            </button>
            <p class="description" style="margin-top:6px;font-size:11px;color:#888;">
                <?php esc_html_e( 'Drag rows to reorder. Changes apply after Publish.', 'newspress' ); ?>
            </p>
        </div>
        <?php
    }
}
