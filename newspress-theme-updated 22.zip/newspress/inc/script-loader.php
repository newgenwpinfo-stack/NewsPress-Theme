<?php
/**
 * Smart Script Loader
 * Adds defer to non-critical scripts.
 * Theme responsibility: loading order only.
 * Minification, combining, and delay strategies are handled by cache plugins.
 *
 * @package NewsPress
 */

defined( 'ABSPATH' ) || exit;

/**
 * Add defer attribute to non-critical scripts (any other theme/plugin
 * script not already handled elsewhere).
 * Keeps jquery and comment-reply synchronous as required by WordPress.
 *
 * newspress-nav and newspress-main both respect "Defer Non-Critical JS"
 * (np_perf_defer_js) themselves — nav via the WP 6.3+ 'strategy' argument
 * at registration (see newspress_enqueue() in functions.php), main via its
 * own script_loader_tag filter (newspress_script_attributes()) — so this
 * filter skips both to avoid double-adding defer.
 */
add_filter( 'script_loader_tag', 'newspress_defer_scripts', 10, 2 );
function newspress_defer_scripts( $tag, $handle ) {
    if ( is_admin() ) {
        return $tag;
    }

    // "Defer Non-Critical/Theme JavaScript" — NewsPress Settings → Performance.
    if ( ! get_option( 'np_perf_defer_js', true ) ) {
        return $tag;
    }

    // Must stay synchronous
    $sync = array( 'jquery', 'jquery-core', 'jquery-migrate', 'comment-reply' );
    if ( in_array( $handle, $sync, true ) ) {
        return $tag;
    }

    // These handles already have defer set via WP 6.3 strategy — skip
    $already_handled = array( 'newspress-nav', 'newspress-main' );
    if ( in_array( $handle, $already_handled, true ) ) {
        return $tag;
    }

    // Add defer if not already present
    if ( false === strpos( $tag, ' defer' ) && false === strpos( $tag, ' async' ) ) {
        $tag = str_replace( '<script ', '<script defer ', $tag );
    }

    return $tag;
}
