<?php
/**
 * Admin Options Page — Appearance → NewsPress Settings
 * Handles: Ads, Privacy/Cookie, Performance flags
 * Design options (colors, typography, layout) stay in the Customizer.
 *
 * @package NewsPress
 */

defined( 'ABSPATH' ) || exit;

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'You do not have permission to access this page.', 'newspress' ) );
}

/* ── Tab routing ── */
$active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'ads';

/* ── Save handlers ── */
if ( isset( $_POST['np_save_options'] ) && check_admin_referer( 'np_options_save' ) ) {

    if ( 'ads' === $active_tab ) {
        // Ad codes contain <script> tags (AdSense, etc.) — only administrators
        // with unfiltered_html capability may save raw HTML. Others get wp_kses_post.
        $sanitize_ad = current_user_can( 'unfiltered_html' )
            ? function( $v ) { return wp_unslash( $v ); }
            : 'wp_kses_post';
        update_option( 'np_ads_header',        $sanitize_ad( $_POST['np_ads_header']       ?? '' ) );
        update_option( 'np_ads_sidebar',       $sanitize_ad( $_POST['np_ads_sidebar']      ?? '' ) );
        update_option( 'np_ads_infeed',        $sanitize_ad( $_POST['np_ads_infeed']       ?? '' ) );
        update_option( 'np_ads_footer',        $sanitize_ad( $_POST['np_ads_footer']       ?? '' ) );
        update_option( 'np_ads_mobile_banner', $sanitize_ad( $_POST['np_ads_mobile_banner']?? '' ) );
    }

    if ( 'privacy' === $active_tab ) {
        update_option( 'np_cookie_enable',         wp_validate_boolean( $_POST['np_cookie_enable']         ?? false ) );
        update_option( 'np_cookie_text',           sanitize_textarea_field( $_POST['np_cookie_text']       ?? '' ) );
        update_option( 'np_cookie_privacy_url',    esc_url_raw( $_POST['np_cookie_privacy_url']            ?? '' ) );
        update_option( 'np_cookie_policy_url',     esc_url_raw( $_POST['np_cookie_policy_url']             ?? '' ) );
        update_option( 'np_cookie_accept_label',   sanitize_text_field( $_POST['np_cookie_accept_label']   ?? '' ) );
        update_option( 'np_cookie_decline_label',  sanitize_text_field( $_POST['np_cookie_decline_label']  ?? '' ) );
        update_option( 'np_cookie_settings_label', sanitize_text_field( $_POST['np_cookie_settings_label'] ?? '' ) );
        update_option( 'np_cookie_save_label',     sanitize_text_field( $_POST['np_cookie_save_label']     ?? '' ) );
        update_option( 'np_adsense_id',            sanitize_text_field( $_POST['np_adsense_id']            ?? '' ) );
        update_option( 'np_cookie_eu_strict',      wp_validate_boolean( $_POST['np_cookie_eu_strict']      ?? false ) );
        update_option( 'np_cookie_analytics',      wp_validate_boolean( $_POST['np_cookie_analytics']      ?? false ) );
        update_option( 'np_cookie_ads_consent',    wp_validate_boolean( $_POST['np_cookie_ads_consent']    ?? false ) );
        update_option( 'np_cookie_key',            sanitize_text_field( $_POST['np_cookie_key']            ?? '' ) );
    }

    if ( 'performance' === $active_tab ) {
        update_option( 'np_perf_lazy_load',      isset( $_POST['np_perf_lazy_load'] ) );
        update_option( 'np_perf_defer_js',       isset( $_POST['np_perf_defer_js'] ) );
        update_option( 'np_perf_remove_emoji',   isset( $_POST['np_perf_remove_emoji'] ) );
        update_option( 'np_perf_webp',           isset( $_POST['np_perf_webp'] ) );
        update_option( 'np_perf_monitor',        isset( $_POST['np_perf_monitor'] ) );
        update_option( 'np_perf_resource_hints', isset( $_POST['np_perf_resource_hints'] ) );
    }

    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'newspress' ) . '</p></div>';
}

/* ── Helper: checked state ── */
$checked = function( $key, $default = false ) {
    return get_option( $key, $default ) ? 'checked="checked"' : '';
};
?>
<div class="wrap">
    <h1><?php esc_html_e( 'NewsPress Settings', 'newspress' ); ?></h1>
    <p style="color:#666;"><?php esc_html_e( 'Design controls (colors, typography, layout) are in the Customizer. These settings handle ads, privacy, and performance. SEO is handled by your SEO plugin.', 'newspress' ); ?></p>

    <!-- Tabs -->
    <nav class="nav-tab-wrapper" style="margin-bottom:20px;">
        <?php
        $tabs = array(
            'ads'         => __( '📢 Advertisements', 'newspress' ),
            'privacy'     => __( '🔒 Privacy & Cookie', 'newspress' ),
            'performance' => __( '⚡ Performance', 'newspress' ),
        );
        foreach ( $tabs as $slug => $label ) {
            $class = ( $active_tab === $slug ) ? 'nav-tab nav-tab-active' : 'nav-tab';
            $url   = admin_url( 'themes.php?page=newspress-settings&tab=' . $slug );
            echo '<a href="' . esc_url( $url ) . '" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</a>';
        }
        ?>
    </nav>

    <form method="post">
        <?php wp_nonce_field( 'np_options_save' ); ?>

        <?php if ( 'ads' === $active_tab ) : ?>
        <!-- ═══════════════════════════════════════════════════════
             ADVERTISEMENTS
        ═══════════════════════════════════════════════════════ -->
        <p><?php esc_html_e( 'Paste AdSense <ins> tags or any ad HTML. Leave blank to disable a slot. Banner style/colors are in the Customizer → Advertisements.', 'newspress' ); ?></p>
        <table class="form-table">
            <tr>
                <th><?php esc_html_e( 'Header Banner (728×90)', 'newspress' ); ?></th>
                <td>
                    <textarea name="np_ads_header" rows="4" class="large-text code"><?php echo esc_textarea( get_option( 'np_ads_header', '' ) ); ?></textarea>
                    <p class="description"><?php esc_html_e( 'Appears between logo and navigation.', 'newspress' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Sidebar Ad (300×250)', 'newspress' ); ?></th>
                <td><textarea name="np_ads_sidebar" rows="4" class="large-text code"><?php echo esc_textarea( get_option( 'np_ads_sidebar', '' ) ); ?></textarea></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'In-Article Ad', 'newspress' ); ?></th>
                <td>
                    <textarea name="np_ads_infeed" rows="4" class="large-text code"><?php echo esc_textarea( get_option( 'np_ads_infeed', '' ) ); ?></textarea>
                    <p class="description"><?php esc_html_e( 'Injected after the 3rd paragraph of post content.', 'newspress' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Footer Ad (728×90)', 'newspress' ); ?></th>
                <td><textarea name="np_ads_footer" rows="4" class="large-text code"><?php echo esc_textarea( get_option( 'np_ads_footer', '' ) ); ?></textarea></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Mobile Banner (320×50)', 'newspress' ); ?></th>
                <td>
                    <textarea name="np_ads_mobile_banner" rows="4" class="large-text code"><?php echo esc_textarea( get_option( 'np_ads_mobile_banner', '' ) ); ?></textarea>
                    <p class="description"><?php esc_html_e( 'Shown only on screens ≤ 480px.', 'newspress' ); ?></p>
                </td>
            </tr>
        </table>

        <?php elseif ( 'privacy' === $active_tab ) : ?>
        <!-- ═══════════════════════════════════════════════════════
             PRIVACY & COOKIE CONSENT
        ═══════════════════════════════════════════════════════ -->

        <?php
        /* ── Live status indicator ── */
        $cc_on      = get_option( 'np_cookie_enable' );
        $cc_strict  = get_option( 'np_cookie_eu_strict' );
        $cc_status  = ( $cc_on && $cc_on !== '0' );
        ?>
        <div style="background:<?php echo $cc_status ? '#edfaed' : '#fff8e1'; ?>;border-left:4px solid <?php echo $cc_status ? '#2e7d32' : '#f59e0b'; ?>;padding:12px 16px;margin-bottom:20px;border-radius:0 4px 4px 0;">
            <?php if ( $cc_status ) : ?>
                <strong style="color:#2e7d32">✅ Cookie banner is ENABLED.</strong>
                <?php if ( ! $cc_strict ) : ?>
                    &nbsp;<span style="color:#b45309">⚠️ <strong>Show Banner to All Visitors</strong> is OFF — visitors outside the EU are auto-consented silently (no banner shown). If your site is NOT in the EU, check that box below to always show the banner.</span>
                <?php else : ?>
                    &nbsp;<span style="color:#2e7d32">Banner shows to ALL visitors. ✓</span>
                <?php endif; ?>
            <?php else : ?>
                <strong style="color:#b45309">⚠️ Cookie banner is DISABLED.</strong> Check the box below and save to activate it.
            <?php endif; ?>
        </div>

        <table class="form-table">
            <tr style="background:#fffbea;">
                <th><?php esc_html_e( 'Enable Cookie Banner', 'newspress' ); ?></th>
                <td>
                    <label style="font-size:14px;font-weight:600;">
                        <input type="checkbox" name="np_cookie_enable" value="1" <?php echo $checked( 'np_cookie_enable', false ); ?>>
                        &nbsp;<?php esc_html_e( 'Activate the cookie consent banner', 'newspress' ); ?>
                    </label>
                    <p class="description" style="color:#b45309;font-weight:500;"><?php esc_html_e( '⬅ Must be checked for the banner to appear.', 'newspress' ); ?></p>
                </td>
            </tr>
            <tr style="background:#fffbea;">
                <th><?php esc_html_e( '⭐ Show Banner to ALL Visitors', 'newspress' ); ?></th>
                <td>
                    <label style="font-size:14px;font-weight:600;">
                        <input type="checkbox" name="np_cookie_eu_strict" value="1" <?php echo $checked( 'np_cookie_eu_strict', false ); ?>>
                        &nbsp;<?php esc_html_e( 'Show to everyone (not just EU visitors)', 'newspress' ); ?>
                    </label>
                    <p class="description" style="color:#b45309;font-weight:500;"><?php esc_html_e( '⬅ If your audience is outside the EU (e.g. Nigeria, US, Asia), you MUST check this. Without it, non-EU visitors are auto-consented silently and the banner never appears.', 'newspress' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Banner Message', 'newspress' ); ?></th>
                <td>
                    <textarea name="np_cookie_text" rows="3" class="large-text"><?php echo esc_textarea( get_option( 'np_cookie_text', 'We use cookies to improve your experience and serve personalised ads. By continuing you agree to our cookie policy.' ) ); ?></textarea>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Privacy Policy URL', 'newspress' ); ?></th>
                <td>
                    <input type="url" name="np_cookie_privacy_url" value="<?php echo esc_attr( get_option( 'np_cookie_privacy_url', '' ) ); ?>" class="regular-text" placeholder="https://yoursite.com/privacy-policy/">
                    <p class="description"><?php esc_html_e( 'Full URL to your Privacy Policy page. Used in the cookie consent banner.', 'newspress' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Cookie Policy URL', 'newspress' ); ?></th>
                <td>
                    <input type="url" name="np_cookie_policy_url" value="<?php echo esc_attr( get_option( 'np_cookie_policy_url', '' ) ); ?>" class="regular-text" placeholder="https://yoursite.com/cookie-policy/">
                    <p class="description"><?php esc_html_e( 'Full URL to your Cookie Policy page. Leave blank to hide cookie policy link.', 'newspress' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Accept Button Label', 'newspress' ); ?></th>
                <td><input type="text" name="np_cookie_accept_label" value="<?php echo esc_attr( get_option( 'np_cookie_accept_label', 'Accept All' ) ); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Decline Button Label', 'newspress' ); ?></th>
                <td><input type="text" name="np_cookie_decline_label" value="<?php echo esc_attr( get_option( 'np_cookie_decline_label', 'Reject Non-Essential' ) ); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Manage Preferences Label', 'newspress' ); ?></th>
                <td>
                    <input type="text" name="np_cookie_settings_label" value="<?php echo esc_attr( get_option( 'np_cookie_settings_label', 'Manage Preferences' ) ); ?>" class="regular-text">
                    <p class="description"><?php esc_html_e( 'Button that opens the preferences panel.', 'newspress' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Save Preferences Label', 'newspress' ); ?></th>
                <td>
                    <input type="text" name="np_cookie_save_label" value="<?php echo esc_attr( get_option( 'np_cookie_save_label', 'Save Preferences' ) ); ?>" class="regular-text">
                    <p class="description"><?php esc_html_e( 'Button inside the preferences panel that saves choices.', 'newspress' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'AdSense Publisher ID', 'newspress' ); ?></th>
                <td>
                    <input type="text" name="np_adsense_id" value="<?php echo esc_attr( get_option( 'np_adsense_id', '' ) ); ?>" class="regular-text" placeholder="ca-pub-XXXXXXXXXX">
                    <p class="description"><?php esc_html_e( 'Used to block/enable AdSense based on consent.', 'newspress' ); ?></p>
                </td>
            </tr>
<!-- eu_strict moved to top of form -->
            <tr>
                <th><?php esc_html_e( 'Consent Categories', 'newspress' ); ?></th>
                <td>
                    <label style="display:block;margin-bottom:6px;"><input type="checkbox" name="np_cookie_analytics" value="1" <?php echo $checked( 'np_cookie_analytics', true ); ?>> <?php esc_html_e( 'Show "Analytics cookies" checkbox', 'newspress' ); ?></label>
                    <label style="display:block;"><input type="checkbox" name="np_cookie_ads_consent" value="1" <?php echo $checked( 'np_cookie_ads_consent', true ); ?>> <?php esc_html_e( 'Show "Advertising cookies" checkbox', 'newspress' ); ?></label>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Consent Key', 'newspress' ); ?></th>
                <td>
                    <input type="text" name="np_cookie_key" value="<?php echo esc_attr( get_option( 'np_cookie_key', 'np_cookie_consent' ) ); ?>" class="regular-text">
                    <p class="description"><?php esc_html_e( 'Change this key to reset all visitor consents site-wide.', 'newspress' ); ?></p>
                </td>
            </tr>
        </table>

        <?php elseif ( 'performance' === $active_tab ) : ?>
        <!-- ═══════════════════════════════════════════════════════
             PERFORMANCE
        ═══════════════════════════════════════════════════════ -->
        <p><?php esc_html_e( 'Theme-level performance optimisations. For full caching and minification use WP Rocket, LiteSpeed Cache, or similar.', 'newspress' ); ?></p>
        <table class="form-table">
            <tr>
                <th><?php esc_html_e( 'Lazy Load Images', 'newspress' ); ?></th>
                <td><label><input type="checkbox" name="np_perf_lazy_load" value="1" <?php echo $checked( 'np_perf_lazy_load', true ); ?>> <?php esc_html_e( 'Add loading="lazy" to images (improves LCP)', 'newspress' ); ?></label></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Defer Non-Critical JS', 'newspress' ); ?></th>
                <td><label><input type="checkbox" name="np_perf_defer_js" value="1" <?php echo $checked( 'np_perf_defer_js', true ); ?>> <?php esc_html_e( 'Add defer attribute to theme scripts', 'newspress' ); ?></label></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Remove Emoji Scripts', 'newspress' ); ?></th>
                <td><label><input type="checkbox" name="np_perf_remove_emoji" value="1" <?php echo $checked( 'np_perf_remove_emoji', true ); ?>> <?php esc_html_e( 'Remove wp-emoji-release.min.js (saves ~15KB)', 'newspress' ); ?></label></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'WebP Support', 'newspress' ); ?></th>
                <td><label><input type="checkbox" name="np_perf_webp" value="1" <?php echo $checked( 'np_perf_webp', true ); ?>> <?php esc_html_e( 'Serve existing .webp files via <picture> element', 'newspress' ); ?></label></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Resource Hints', 'newspress' ); ?></th>
                <td><label><input type="checkbox" name="np_perf_resource_hints" value="1" <?php echo $checked( 'np_perf_resource_hints', true ); ?>> <?php esc_html_e( 'Preconnect to Google Fonts and CDNs', 'newspress' ); ?></label></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Performance Monitor', 'newspress' ); ?></th>
                <td><label><input type="checkbox" name="np_perf_monitor" value="1" <?php echo $checked( 'np_perf_monitor', false ); ?>> <?php esc_html_e( 'Show page load time / memory in admin bar (admins only)', 'newspress' ); ?></label></td>
            </tr>
        </table>

        <?php endif; ?>

        <p style="margin-top:20px;">
            <?php submit_button( __( 'Save Settings', 'newspress' ), 'primary', 'np_save_options', false ); ?>
            &nbsp;&nbsp;
            <a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="button"><?php esc_html_e( 'Open Customizer →', 'newspress' ); ?></a>
            <a href="<?php echo esc_url( admin_url( 'widgets.php' ) ); ?>" class="button"><?php esc_html_e( 'Manage Widgets', 'newspress' ); ?></a>
            <a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>" class="button"><?php esc_html_e( 'Manage Menus', 'newspress' ); ?></a>
        </p>
    </form>

    <hr>
    <details style="margin-top:20px;">
        <summary style="cursor:pointer;font-weight:600;font-size:14px;"><?php esc_html_e( '📋 Performance Tips for Core Web Vitals', 'newspress' ); ?></summary>
        <ul style="margin-top:10px;">
            <li>✅ <?php esc_html_e( 'Use WebP images for all thumbnails', 'newspress' ); ?></li>
            <li>✅ <?php esc_html_e( 'Enable a caching plugin (WP Rocket, LiteSpeed Cache)', 'newspress' ); ?></li>
            <li>✅ <?php esc_html_e( 'Use a CDN for static assets', 'newspress' ); ?></li>
            <li>✅ <?php esc_html_e( 'Enable GZIP / Brotli compression on your server', 'newspress' ); ?></li>
            <li>✅ <?php esc_html_e( 'Set correct image dimensions to prevent layout shift (CLS)', 'newspress' ); ?></li>
            <li>✅ <?php esc_html_e( 'Preload the LCP (hero) image in your header', 'newspress' ); ?></li>
            <li>✅ <?php esc_html_e( 'Minimise third-party scripts and ads', 'newspress' ); ?></li>
        </ul>
    </details>
</div>
