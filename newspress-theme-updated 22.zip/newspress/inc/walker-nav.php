<?php
/**
 * NewsPress Nav Walker – accessible dropdown navigation
 *
 * @package NewsPress
 */

defined( 'ABSPATH' ) || exit;

class NewsPress_Nav_Walker extends Walker_Nav_Menu {

    public function start_lvl( &$output, $depth = 0, $args = null ) {
        $indent  = str_repeat( "\t", $depth );
        $output .= "\n{$indent}<ul class=\"sub-menu\" role=\"menu\">\n";
    }

    public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        $indent = $depth ? str_repeat( "\t", $depth ) : '';

        $classes   = empty( $item->classes ) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;

        $has_children = in_array( 'menu-item-has-children', $classes );

        $class_names = implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
        $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

        $item_id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth );
        $item_id = $item_id ? ' id="' . esc_attr( $item_id ) . '"' : '';

        $output .= $indent . '<li' . $item_id . $class_names . '>';

        $atts                 = array();
        $atts['title']        = ! empty( $item->attr_title ) ? $item->attr_title : '';
        $atts['target']       = ! empty( $item->target ) ? $item->target : '';
        $atts['rel']          = ( '_blank' === $item->target && empty( $item->xfn ) ) ? 'noopener noreferrer' : $item->xfn;
        $atts['href']         = ! empty( $item->url ) ? $item->url : '';
        $atts['aria-current'] = $item->current ? 'page' : '';

        if ( $has_children ) {
            $atts['aria-haspopup'] = 'true';
            $atts['aria-expanded'] = 'false';
        }

        $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

        $attributes = '';
        foreach ( $atts as $attr => $value ) {
            if ( is_scalar( $value ) && '' !== $value ) {
                $value       = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        $title = apply_filters( 'the_title', $item->title, $item->ID );
        $title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

        // Safely read $args properties — $args can be null or a plain object
        $before      = ( is_object( $args ) && isset( $args->before ) )      ? $args->before      : '';
        $after       = ( is_object( $args ) && isset( $args->after ) )       ? $args->after       : '';
        $link_before = ( is_object( $args ) && isset( $args->link_before ) ) ? $args->link_before : '';
        $link_after  = ( is_object( $args ) && isset( $args->link_after ) )  ? $args->link_after  : '';

        $item_output  = $before;
        $item_output .= '<a' . $attributes . '>';
        $item_output .= $link_before . $title . $link_after;
        $item_output .= '</a>';
        if ( $has_children ) {
            // Separate toggle button — not inside <a> — so mobile tap opens dropdown
            // without navigating the link
            $item_output .= '<button class="np-sub-toggle" aria-expanded="false" aria-label="' . esc_attr__( 'Toggle submenu', 'newspress' ) . '"><span aria-hidden="true">&#9662;</span></button>';
        }
        $item_output .= $after;

        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }
}
