<?php
/**
 * NewsPress Cookie Consent — Zero-CLS Edition v3
 * @package NewsPress
 */
defined( 'ABSPATH' ) || exit;

$np_cc_enabled = get_option( 'np_cookie_enable' );
if ( ! $np_cc_enabled || $np_cc_enabled === '0' || $np_cc_enabled === 0 ) return;

/* ── Config ── */
function np_cc_cfg() {
    static $c = null;
    if ( $c ) return $c;
    $c = array(
        'strict' => (bool) get_option( 'np_cookie_eu_strict', false ),
        'pos'    => get_theme_mod( 'np_cookie_position', 'bottom' ),
        'txt'    => get_option( 'np_cookie_text', 'We use cookies to improve your experience and serve personalised ads. By continuing you agree to our cookie policy.' ),
        'url'    => get_option( 'np_cookie_policy_url', '' ),
        'la'     => get_option( 'np_cookie_accept_label',   'Accept All' ),
        'lr'     => get_option( 'np_cookie_decline_label',  'Reject non-essential' ),
        'lm'     => get_option( 'np_cookie_settings_label', 'Manage Preferences' ),
        'ads_id' => get_option( 'np_adsense_id', '' ),
        // "Show 'Analytics/Advertising cookies' checkbox" — NewsPress Settings
        // → Privacy & Cookie. Controls whether that row appears in the
        // "Manage Preferences" modal below; previously saved but never read.
        'show_ana' => (bool) get_option( 'np_cookie_analytics', true ),
        'show_ads' => (bool) get_option( 'np_cookie_ads_consent', true ),
        'bg'     => get_theme_mod( 'np_cookie_banner_bg',  '#ffffff' ),
        'tc'     => get_theme_mod( 'np_cookie_text_color', '#333333' ),
        'btn'    => get_theme_mod( 'np_cookie_btn_bg',     '#2563eb' ),
        'btt'    => get_theme_mod( 'np_cookie_btn_text',   '#ffffff' ),
        'lc'     => get_theme_mod( 'np_cookie_link_color', '#2563eb' ),
    );
    return $c;
}

/* ── 1. CSS ── */
add_action( 'wp_head', 'np_cc_css', 1 );
function np_cc_css() {
    if ( is_customize_preview() ) return;
    $c   = np_cc_cfg();
    $top = ( $c['pos'] === 'top' );
    $btn = esc_attr( $c['btn'] );
    $bg  = esc_attr( $c['bg'] );
    $tc  = esc_attr( $c['tc'] );
    $btt = esc_attr( $c['btt'] );
    $lc  = esc_attr( $c['lc'] );
    ?>
<style id="zero-cls-consent-css">
/* ── Banner ── */
#consent-banner{
  position:fixed!important;left:0!important;right:0!important;
  <?php echo $top ? 'top:0!important;bottom:auto!important;' : 'bottom:0!important;top:auto!important;'; ?>
  z-index:999999!important;background:<?php echo $bg; ?>;color:<?php echo $tc; ?>;
  <?php echo $top ? "box-shadow:0 4px 20px rgba(0,0,0,.14);border-bottom:3px solid {$btn};" : "box-shadow:0 -4px 20px rgba(0,0,0,.14);border-top:3px solid {$btn};"; ?>
  padding:14px 16px;font-size:15px;line-height:1.5;display:none;
  contain:layout style paint;pointer-events:auto!important;touch-action:auto!important;box-sizing:border-box;
}
#consent-inner{max-width:1100px;margin:0 auto;display:flex;gap:12px;align-items:center;flex-wrap:wrap}
#consent-text{flex:1 1 380px;color:<?php echo $tc; ?>}
#consent-text a{color:<?php echo $lc; ?>;text-decoration:underline}
#consent-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.consent-btn{
  border:0!important;padding:12px 18px!important;border-radius:6px!important;
  font-size:14px!important;font-weight:700!important;cursor:pointer!important;
  white-space:nowrap;touch-action:manipulation!important;-webkit-appearance:none!important;
  appearance:none!important;line-height:1.2;display:inline-block;
}
.consent-accept{background:<?php echo $btn; ?>!important;color:<?php echo $btt; ?>!important}
.consent-accept:active,.consent-accept:hover{opacity:.88}
.consent-reject{background:#eeeeee!important;color:#111111!important}
.consent-reject:active,.consent-reject:hover{background:#dddddd!important}
.consent-manage{background:none!important;color:<?php echo $lc; ?>!important;text-decoration:underline;padding:12px 6px!important;font-size:14px!important;font-weight:600!important}
@media(max-width:640px){
  #consent-inner{flex-direction:column;align-items:flex-start;gap:10px}
  #consent-actions{width:100%;flex-direction:column}
  .consent-btn{width:100%!important;text-align:center!important;padding:14px!important}
}

/* ── Preferences Modal ── */
#np-pref-overlay{
  display:none;position:fixed!important;inset:0;
  z-index:1000000!important;
  background:rgba(0,0,0,.55);
  align-items:center;justify-content:center;
  padding:16px;box-sizing:border-box;
  touch-action:auto!important;
}
#np-pref-overlay.np-pref-open{display:flex!important}
#np-pref-box{
  background:#fff;color:#1a1a2e;
  border-radius:16px;
  padding:32px 28px 28px;
  max-width:600px;width:100%;
  max-height:90vh;overflow-y:auto;
  position:relative;
  box-shadow:0 12px 48px rgba(0,0,0,.22);
  box-sizing:border-box;
}
#np-pref-close{
  position:absolute;top:16px;right:16px;
  width:40px;height:40px;
  background:#f0f0f5;border:2px solid #ddd;
  border-radius:10px;font-size:20px;font-weight:700;
  cursor:pointer;display:flex;align-items:center;justify-content:center;
  line-height:1;color:#333;touch-action:manipulation;
}
#np-pref-close:hover{background:#e0e0ea}
#np-pref-box h2{font-size:22px;font-weight:700;margin:0 48px 10px 0;line-height:1.3;color:#1a1a2e}
#np-pref-box .np-pref-intro{font-size:14px;line-height:1.65;color:#555;margin-bottom:22px}
.np-pref-row{
  border-top:1px solid #eee;padding:18px 0;
  display:flex;align-items:flex-start;gap:16px;
}
.np-pref-row:last-of-type{border-bottom:1px solid #eee}
.np-pref-info{flex:1;min-width:0}
.np-pref-name{font-weight:700;font-size:15px;margin-bottom:5px;color:#1a1a2e}
.np-pref-desc{font-size:13px;line-height:1.6;color:#666}
/* Toggle switch */
.np-tog-wrap{flex-shrink:0;display:flex;flex-direction:column;align-items:center;gap:4px;min-width:64px}
.np-tog{position:relative;display:inline-block;width:60px;height:30px}
.np-tog input{opacity:0;width:0;height:0;position:absolute}
.np-tog-sl{
  position:absolute;inset:0;
  background:#ccc;border-radius:30px;
  cursor:pointer;transition:.25s;
}
.np-tog-sl::before{
  content:"";position:absolute;
  width:22px;height:22px;left:4px;top:4px;
  background:#fff;border-radius:50%;
  transition:.25s;box-shadow:0 1px 4px rgba(0,0,0,.2);
}
.np-tog input:checked + .np-tog-sl{background:<?php echo $btn; ?>}
.np-tog input:checked + .np-tog-sl::before{transform:translateX(30px)}
.np-tog input:disabled + .np-tog-sl{opacity:.6;cursor:not-allowed}
.np-tog-lbl{
  font-size:10px;font-weight:800;letter-spacing:.07em;
  text-transform:uppercase;color:#888;margin-top:2px;
}
.np-tog input:checked ~ .np-tog-lbl-text{display:none}
/* Footer buttons inside modal */
.np-pref-foot{
  display:flex;gap:12px;flex-wrap:wrap;margin-top:24px;padding-top:20px;
  border-top:1px solid #eee;
}
.np-pref-foot button{
  flex:1;min-width:140px;padding:13px 20px;border:0;border-radius:8px;
  font-size:15px;font-weight:700;cursor:pointer;
  touch-action:manipulation;-webkit-appearance:none;appearance:none;
}
.np-pref-accept-all{background:<?php echo $btn; ?>;color:<?php echo $btt; ?>}
.np-pref-accept-all:hover{opacity:.88}
.np-pref-reject-all{background:<?php echo $btn; ?>;color:<?php echo $btt; ?>}
.np-pref-reject-all:hover{opacity:.88}
.np-pref-save{background:#ffffff;color:<?php echo $btn; ?>;border:2px solid <?php echo $btn; ?>!important;box-sizing:border-box}
.np-pref-save:hover{background:<?php echo $btn; ?>;color:<?php echo $btt; ?>}
@media(max-width:500px){
  #np-pref-box{padding:24px 16px 20px;border-radius:12px}
  #np-pref-box h2{font-size:19px}
  .np-pref-foot{flex-direction:column}
  .np-pref-foot button{min-width:0}
}
</style>
<?php
}

/* ── 2. HTML + JS ── */
add_action( 'wp_footer', 'np_cc_output', 99 );
function np_cc_output() {
    if ( is_customize_preview() ) return;
    $c = np_cc_cfg();
    $show_all = $c['strict'];
    $eu_tz = '["Europe/Vienna","Europe/Brussels","Europe/Sofia","Europe/Zagreb","Europe/Nicosia","Europe/Prague","Europe/Copenhagen","Europe/Tallinn","Europe/Helsinki","Europe/Paris","Europe/Berlin","Europe/Athens","Europe/Budapest","Europe/Dublin","Europe/Rome","Europe/Riga","Europe/Vilnius","Europe/Luxembourg","Europe/Valletta","Europe/Amsterdam","Europe/Warsaw","Europe/Lisbon","Europe/Bucharest","Europe/Bratislava","Europe/Ljubljana","Europe/Madrid","Europe/Stockholm","Europe/London"]';
    ?>

<!-- ═══ Cookie Banner ═══ -->
<div id="consent-banner" role="dialog" aria-label="<?php esc_attr_e('Cookie consent','newspress'); ?>">
  <div id="consent-inner">
    <div id="consent-text">
      <?php echo wp_kses_post( $c['txt'] ); ?>
      <?php if ( $c['url'] ) : ?>
        <a href="<?php echo esc_url( $c['url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Cookie Policy', 'newspress' ); ?></a>
      <?php endif; ?>
    </div>
    <div id="consent-actions">
      <button class="consent-btn consent-accept" id="consent-accept" type="button"><?php echo esc_html( $c['la'] ); ?></button>
      <button class="consent-btn consent-reject" id="consent-reject" type="button"><?php echo esc_html( $c['lr'] ); ?></button>
      <button class="consent-btn consent-manage" id="consent-manage" type="button"><?php echo esc_html( $c['lm'] ); ?></button>
    </div>
  </div>
</div>

<!-- ═══ Preferences Modal ═══ -->
<div id="np-pref-overlay" role="dialog" aria-modal="true" aria-labelledby="np-pref-title">
  <div id="np-pref-box">
    <button id="np-pref-close" type="button" aria-label="<?php esc_attr_e('Close','newspress'); ?>">&#10005;</button>

    <h2 id="np-pref-title"><?php esc_html_e('Customize your privacy settings','newspress'); ?></h2>
    <p class="np-pref-intro"><?php esc_html_e('We value your privacy. You can decide which types of cookies you allow. Your choices will apply across this website and can be changed at any time.','newspress'); ?></p>

    <!-- Essential -->
    <div class="np-pref-row">
      <div class="np-pref-info">
        <div class="np-pref-name"><?php esc_html_e('Essential','newspress'); ?></div>
        <div class="np-pref-desc"><?php esc_html_e('These cookies are required for the site to operate correctly and cannot be disabled. They enable core features such as security, network management, and saving your preferences.','newspress'); ?></div>
      </div>
      <div class="np-tog-wrap">
        <label class="np-tog">
          <input type="checkbox" checked disabled>
          <span class="np-tog-sl"></span>
        </label>
        <span class="np-tog-lbl">ON</span>
      </div>
    </div>

    <!-- Analytics -->
    <?php if ( $c['show_ana'] ) : ?>
    <div class="np-pref-row">
      <div class="np-pref-info">
        <div class="np-pref-name"><?php esc_html_e('Analytics','newspress'); ?></div>
        <div class="np-pref-desc"><?php esc_html_e('These cookies help us understand how visitors use our website so we can improve performance, content, and user experience. The information collected is aggregated and does not directly identify you.','newspress'); ?></div>
      </div>
      <div class="np-tog-wrap">
        <label class="np-tog">
          <input type="checkbox" id="np-tog-ana">
          <span class="np-tog-sl"></span>
        </label>
        <span class="np-tog-lbl" id="np-lbl-ana">OFF</span>
      </div>
    </div>
    <?php endif; ?>

    <!-- Advertising -->
    <?php if ( $c['show_ads'] ) : ?>
    <div class="np-pref-row">
      <div class="np-pref-info">
        <div class="np-pref-name"><?php esc_html_e('Advertising','newspress'); ?></div>
        <div class="np-pref-desc"><?php esc_html_e('These cookies allow us and our partners to deliver relevant ads and features tailored to your interests. They may also limit how often you see the same advertisement.','newspress'); ?></div>
      </div>
      <div class="np-tog-wrap">
        <label class="np-tog">
          <input type="checkbox" id="np-tog-ads">
          <span class="np-tog-sl"></span>
        </label>
        <span class="np-tog-lbl" id="np-lbl-ads">OFF</span>
      </div>
    </div>
    <?php endif; ?>

    <div class="np-pref-foot">
      <button type="button" class="np-pref-accept-all" id="np-pref-accept"><?php echo esc_html( $c['la'] ); ?></button>
      <button type="button" class="np-pref-reject-all" id="np-pref-reject"><?php echo esc_html( $c['lr'] ); ?></button>
      <button type="button" class="np-pref-save" id="np-pref-save"><?php esc_html_e( 'Save Preferences', 'newspress' ); ?></button>
    </div>

  </div>
</div>

<script>
(function(){
  var KEY      = "np_consent_v1";
  var SHOW_ALL = <?php echo $show_all ? 'true' : 'false'; ?>;
  var ADS_ID   = "<?php echo esc_js( $c['ads_id'] ); ?>";
  var EU       = <?php echo $eu_tz; ?>;
  var banner   = document.getElementById("consent-banner");
  var overlay  = document.getElementById("np-pref-overlay");
  var togAna   = document.getElementById("np-tog-ana");
  var togAds   = document.getElementById("np-tog-ads");
  var lblAna   = document.getElementById("np-lbl-ana");
  var lblAds   = document.getElementById("np-lbl-ads");

  /* Google Consent Mode v2 defaults */
  window.dataLayer = window.dataLayer || [];
  function gtag(){ window.dataLayer.push(arguments); }
  gtag("consent","default",{
    ad_storage:"denied",analytics_storage:"denied",
    ad_user_data:"denied",ad_personalization:"denied",
    wait_for_update:500
  });

  /* Storage */
  function load(){
    try{ var v=localStorage.getItem(KEY); if(v) return JSON.parse(v); }catch(e){}
    return null;
  }
  function save(obj){
    obj.ts = Date.now();
    try{ localStorage.setItem(KEY, JSON.stringify(obj)); }catch(e){}
    var exp = new Date(Date.now()+365*86400000).toUTCString();
    document.cookie = KEY+"="+encodeURIComponent(JSON.stringify(obj))+"; expires="+exp+"; path=/; SameSite=Lax";
  }

  /* AdSense loader */
  function loadAds(){
    if(!ADS_ID || document.getElementById("np-adsense")) return;
    var s=document.createElement("script");
    s.id="np-adsense"; s.async=true;
    s.src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js";
    s.setAttribute("data-ad-client",ADS_ID);
    document.head.appendChild(s);
  }

  /* Grant / deny Consent Mode */
  function grantAll(){
    gtag("consent","update",{ad_storage:"granted",analytics_storage:"granted",ad_user_data:"granted",ad_personalization:"granted"});
    loadAds();
  }
  function denyAll(){
    gtag("consent","update",{ad_storage:"denied",analytics_storage:"denied",ad_user_data:"denied",ad_personalization:"denied"});
  }
  function grantCustom(ana, ads){
    gtag("consent","update",{
      analytics_storage: ana ? "granted" : "denied",
      ad_storage:        ads ? "granted" : "denied",
      ad_user_data:      ads ? "granted" : "denied",
      ad_personalization:ads ? "granted" : "denied"
    });
    if(ads) loadAds();
  }

  /* Modal helpers */
  function openModal(){
    var saved = load();
    if(togAna){ togAna.checked = saved ? !!saved.analytics : false; setLbl(lblAna, togAna.checked); }
    if(togAds){ togAds.checked = saved ? !!saved.ads       : false; setLbl(lblAds, togAds.checked); }
    overlay.className = "np-pref-open";
    document.body.style.overflow = "hidden";
  }
  function closeModal(){
    overlay.className = "";
    document.body.style.overflow = "";
  }
  function setLbl(lbl, val){ if(lbl) lbl.textContent = val ? "ON" : "OFF"; }

  /* Toggle live labels */
  if(togAna) togAna.onchange = function(){ setLbl(lblAna, togAna.checked); };
  if(togAds) togAds.onchange = function(){ setLbl(lblAds, togAds.checked); };

  /* Banner buttons */
  document.getElementById("consent-accept").onclick = function(){
    save({v:"accepted",analytics:true,ads:true});
    grantAll(); banner.remove();
  };
  document.getElementById("consent-reject").onclick = function(){
    save({v:"rejected",analytics:false,ads:false});
    denyAll(); banner.remove();
  };
  document.getElementById("consent-manage").onclick = openModal;

  /* Modal buttons */
  document.getElementById("np-pref-close").onclick  = closeModal;
  document.getElementById("np-pref-accept").onclick = function(){
    save({v:"accepted",analytics:true,ads:true});
    grantAll(); closeModal(); banner.remove();
  };
  document.getElementById("np-pref-reject").onclick = function(){
    var ana = togAna ? togAna.checked : false;
    var ads = togAds ? togAds.checked : false;
    save({v: (ana||ads) ? "custom" : "rejected", analytics:ana, ads:ads});
    grantCustom(ana, ads); closeModal(); banner.remove();
  };
  document.getElementById("np-pref-save").onclick = function(){
    var ana = togAna ? togAna.checked : false;
    var ads = togAds ? togAds.checked : false;
    save({v: (ana||ads) ? "custom" : "rejected", analytics:ana, ads:ads});
    grantCustom(ana, ads); closeModal(); banner.remove();
  };

  /* Close modal on backdrop click */
  overlay.onclick = function(e){ if(e.target===overlay) closeModal(); };

  /* INIT */
  var saved = load();
  if(saved){
    if(saved.v==="accepted"){ grantAll(); }
    else if(saved.v==="custom"){ grantCustom(!!saved.analytics, !!saved.ads); }
  } else {
    var isEU = SHOW_ALL;
    if(!SHOW_ALL){
      try{ isEU = EU.indexOf(Intl.DateTimeFormat().resolvedOptions().timeZone) !== -1; }catch(e){}
    }
    if(isEU || SHOW_ALL){
      banner.style.display = "block";
    } else {
      save({v:"accepted",analytics:true,ads:true}); grantAll();
    }
  }
})();
</script>
<?php
}
