<?php
/**
 * NewsPress Customizer Settings
 *
 * @package NewsPress
 * @version 1.0.1
 */

defined( 'ABSPATH' ) || exit;

require_once NEWSPRESS_DIR . '/inc/section-builder-control.php';

// Only load customizer code when the Customizer classes are available
if ( ! class_exists( 'WP_Customize_Control' ) ) {
    return;
}

/* ============================================================
   Custom Range Slider Control
   Shows a live value badge next to the slider.
   ============================================================ */
class NewsPress_Range_Control extends WP_Customize_Control {

    public $type = 'np-range';
    public $unit = 'px';
    public $min  = 0;
    public $max  = 100;
    public $step = 1;

    public function to_json() {
        parent::to_json();
        $this->json['unit'] = $this->unit;
        $this->json['min']  = $this->min;
        $this->json['max']  = $this->max;
        $this->json['step'] = $this->step;
    }

    public function render_content() {
        $value   = (int) $this->value();
        $default = (int) $this->setting->default;
        $unit    = esc_attr( $this->unit );
        $input_id = 'np-range-' . esc_attr( $this->id );
        ?>
        <label>
            <?php if ( ! empty( $this->label ) ) : ?>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php endif; ?>
            <?php if ( ! empty( $this->description ) ) : ?>
                <span class="description customize-control-description"><?php echo wp_kses( $this->description, array( 'span' => array( 'style' => array() ), 'br' => array(), 'a' => array( 'href' => array(), 'target' => array() ) ) ); ?></span>
            <?php endif; ?>
            <div style="display:flex;align-items:center;gap:8px;margin-top:6px;">
                <input
                    id="<?php echo esc_attr( $input_id ); ?>"
                    type="range"
                    min="<?php echo esc_attr( $this->min ); ?>"
                    max="<?php echo esc_attr( $this->max ); ?>"
                    step="<?php echo esc_attr( $this->step ); ?>"
                    value="<?php echo esc_attr( $value ); ?>"
                    style="flex:1;cursor:pointer;"
                    <?php $this->link(); ?>
                    oninput="this.nextElementSibling.textContent=this.value+'<?php echo $unit; ?>'"
                >
                <span style="display:inline-flex;align-items:center;justify-content:center;min-width:52px;padding:2px 6px;background:#1d2327;color:#fff;font-size:11px;font-weight:700;border-radius:3px;font-family:monospace;flex-shrink:0;"><?php echo esc_html( $value . $unit ); ?></span>
                <button
                    type="button"
                    title="<?php esc_attr_e( 'Reset to default', 'newspress' ); ?>"
                    style="flex-shrink:0;background:#2271b1;color:#fff;border:none;border-radius:3px;padding:3px 7px;font-size:10px;cursor:pointer;line-height:1.4;"
                    onclick="(function(btn){
                        var inp = document.getElementById('<?php echo esc_js( $input_id ); ?>');
                        if(!inp) return;
                        inp.value = <?php echo (int) $default; ?>;
                        inp.dispatchEvent(new Event('input',{bubbles:true}));
                        inp.dispatchEvent(new Event('change',{bubbles:true}));
                        inp.nextElementSibling.textContent = <?php echo (int) $default; ?> + '<?php echo esc_js( $unit ); ?>';
                    })(this)"
                >↺</button>
            </div>
        </label>
        <?php
    }
}

/* ============================================================
   CUSTOM CONTROL: Category Dropdown
   Renders a <select> populated with all real categories.
   Saves the category ID (integer).
   ============================================================ */
class NewsPress_Category_Select_Control extends WP_Customize_Control {

    public $type = 'np-category-select';

    public function render_content() {
        $categories = get_categories( array(
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ) );

        $current = (int) $this->value();
        ?>
        <label>
            <?php if ( ! empty( $this->label ) ) : ?>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php endif; ?>
            <?php if ( ! empty( $this->description ) ) : ?>
                <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
            <?php endif; ?>
            <select <?php $this->link(); ?> style="width:100%;margin-top:4px;">
                <option value="0"><?php esc_html_e( '— Select a category —', 'newspress' ); ?></option>
                <?php foreach ( $categories as $cat ) : ?>
                    <option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php selected( $current, $cat->term_id ); ?>>
                        <?php echo esc_html( $cat->name ); ?> (<?php echo esc_html( $cat->count ); ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php
    }
}

/* ============================================================
   REGISTER CUSTOMIZER SETTINGS & CONTROLS
   ============================================================ */
function newspress_customize_register( WP_Customize_Manager $wp_customize ) {

    // Helper: sanitize a select value against allowed choices
    $sanitize_select = function( $input, $setting ) {
        $choices = $setting->manager->get_control( $setting->id ) ? $setting->manager->get_control( $setting->id )->choices : array();
        return array_key_exists( $input, $choices ) ? $input : $setting->default;
    };

    // Helper: add a color setting + control (always postMessage)
    $add_color = function( $id, $label, $default, $section ) use ( $wp_customize ) {
        $wp_customize->add_setting( $id, array(
            'default'           => $default,
            'sanitize_callback' => 'sanitize_hex_color',
            'transport'         => 'postMessage',
        ) );
        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, array(
            'label'       => $label,
            'section'     => $section,
            'description' => sprintf( __( 'Default: %s', 'newspress' ), $default ),
            'input_attrs' => array( 'data-default' => $default ),
        ) ) );
    };

    // Helper: add a generic setting + control
    $add_ctrl = function( $id, $label, $default, $section, $type = 'text', $choices = array(), $desc = '', $transport = 'refresh' ) use ( $wp_customize, $sanitize_select ) {
        if ( 'checkbox' === $type )       { $sanitize = 'wp_validate_boolean'; }
        elseif ( 'select' === $type )     { $sanitize = $sanitize_select; }
        elseif ( 'number' === $type )     { $sanitize = 'absint'; }
        elseif ( 'textarea' === $type )   { $sanitize = 'wp_kses_post'; }
        elseif ( 'url' === $type )        { $sanitize = 'esc_url_raw'; }
        elseif ( 'color' === $type )      { $sanitize = 'sanitize_hex_color'; }
        else                              { $sanitize = 'sanitize_text_field'; }

        $hint = '';
        if ( '' !== $default && ! in_array( $type, array( 'checkbox', 'textarea' ), true ) ) {
            $hint = sprintf( __( 'Default: %s', 'newspress' ), $default );
        }
        $full_desc = $desc ? ( $hint ? $desc . ' — ' . $hint : $desc ) : $hint;

        $wp_customize->add_setting( $id, array(
            'default'           => $default,
            'sanitize_callback' => $sanitize,
            'transport'         => $transport,
        ) );

        if ( 'color' === $type ) {
            $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, array(
                'label'       => $label,
                'section'     => $section,
                'description' => $full_desc,
            ) ) );
            return;
        }

        $ctrl_args = array( 'label' => $label, 'section' => $section, 'type' => $type, 'description' => $full_desc );
        if ( ! empty( $choices ) ) { $ctrl_args['choices'] = $choices; }
        $wp_customize->add_control( $id, $ctrl_args );
    };

    // Helper: range slider (always postMessage)
    $add_range = function( $id, $label, $default, $section, $min, $max, $step, $unit = 'px' ) use ( $wp_customize ) {
        $wp_customize->add_setting( $id, array(
            'default'           => $default,
            'sanitize_callback' => 'absint',
            'transport'         => 'postMessage',
        ) );
        $wp_customize->add_control( new NewsPress_Range_Control( $wp_customize, $id, array(
            'label'       => $label,
            'description' => sprintf( __( 'Default: %1$s%2$s', 'newspress' ), $default, $unit ),
            'section'     => $section,
            'unit'        => $unit,
            'min'         => $min,
            'max'         => $max,
            'step'        => $step,
        ) ) );
    };

    /* ================================================================
       1. SITE IDENTITY  (WordPress built-in — priority 20)
       ================================================================ */
    // WP handles blogname, blogdescription, site_icon, custom_logo natively

    /* ================================================================
       2. COLORS  (priority 30)
       ================================================================ */
    $wp_customize->add_panel( 'np_colors_panel', array( 'title' => __( 'Colors', 'newspress' ), 'priority' => 30 ) );

    $wp_customize->add_section( 'np_colors_brand',  array( 'title' => __( 'Brand',        'newspress' ), 'panel' => 'np_colors_panel' ) );
    $add_color( 'np_color_primary',   __( 'Primary',   'newspress' ), '#d32f2f', 'np_colors_brand' );
    $add_color( 'np_color_secondary', __( 'Secondary', 'newspress' ), '#1565c0', 'np_colors_brand' );
    $add_color( 'np_color_accent',    __( 'Accent',    'newspress' ), '#f57c00', 'np_colors_brand' );

    $wp_customize->add_section( 'np_colors_text', array( 'title' => __( 'Text', 'newspress' ), 'panel' => 'np_colors_panel' ) );
    $add_color( 'np_color_text',  __( 'Body Text',  'newspress' ), '#212121', 'np_colors_text' );
    $add_color( 'np_color_muted', __( 'Muted Text', 'newspress' ), '#757575', 'np_colors_text' );

    $wp_customize->add_section( 'np_colors_bg', array( 'title' => __( 'Backgrounds', 'newspress' ), 'panel' => 'np_colors_panel' ) );
    $add_color( 'np_color_bg',     __( 'Site Background', 'newspress' ), '#ffffff', 'np_colors_bg' );
    $add_color( 'np_color_bg_alt', __( 'Alt Background',  'newspress' ), '#f5f5f5', 'np_colors_bg' );

    $wp_customize->add_section( 'np_colors_header', array( 'title' => __( 'Header & Top Bar', 'newspress' ), 'panel' => 'np_colors_panel' ) );
    $add_color( 'np_color_header_bg',   __( 'Header Background',  'newspress' ), '#ffffff', 'np_colors_header' );
    $add_color( 'np_color_topbar_bg',   __( 'Top Bar Background', 'newspress' ), '#212121', 'np_colors_header' );
    $add_color( 'np_color_topbar_text', __( 'Top Bar Text',       'newspress' ), '#ffffff', 'np_colors_header' );

    $wp_customize->add_section( 'np_colors_nav', array( 'title' => __( 'Navigation', 'newspress' ), 'panel' => 'np_colors_panel' ) );
    $add_color( 'np_color_nav_bg',   __( 'Nav Background', 'newspress' ), '#d32f2f', 'np_colors_nav' );
    $add_color( 'np_color_nav_text', __( 'Nav Text',       'newspress' ), '#ffffff', 'np_colors_nav' );

    $wp_customize->add_section( 'np_colors_footer', array( 'title' => __( 'Footer', 'newspress' ), 'panel' => 'np_colors_panel' ) );
    $add_color( 'np_color_footer_bg',   __( 'Footer Background', 'newspress' ), '#1a1a1a', 'np_colors_footer' );
    $add_color( 'np_color_footer_text', __( 'Footer Text',       'newspress' ), '#cccccc', 'np_colors_footer' );

    /* ================================================================
       3. TYPOGRAPHY  (priority 35)
       ================================================================ */
    $wp_customize->add_panel( 'np_typography_panel', array( 'title' => __( 'Typography', 'newspress' ), 'priority' => 35 ) );

    /* ── Google Fonts list ─────────────────────────────────────
       Organised A–Z. System fonts (no Google load) prefixed sys:
    ───────────────────────────────────────────────────────── */
    $font_choices = array(
        /* ── System / Safe (no network load) ── */
        'sys:default' => '— System Default —',
        'sys:Georgia' => 'Georgia  (System Serif)',
        'sys:Arial' => 'Arial  (System Sans-serif)',
        'sys:Verdana' => 'Verdana  (System Sans-serif)',
        'sys:Trebuchet MS' => 'Trebuchet MS  (System)',
        /* ── Google Fonts A–Z ── */
        'Abril Fatface' => 'Abril Fatface  (Display)',
        'Alegreya' => 'Alegreya',
        'Alfa Slab One' => 'Alfa Slab One  (Slab)',
        'Anton' => 'Anton  (Display)',
        'Arvo' => 'Arvo  (Slab)',
        'Barlow' => 'Barlow',
        'Barlow Condensed' => 'Barlow Condensed',
        'Bebas Neue' => 'Bebas Neue  (Display)',
        'Bitter' => 'Bitter',
        'Black Han Sans' => 'Black Han Sans  (Display)',
        'Cabin' => 'Cabin',
        'Cormorant Garamond' => 'Cormorant Garamond',
        'Crimson Pro' => 'Crimson Pro',
        'DM Sans' => 'DM Sans',
        'DM Serif Display' => 'DM Serif Display',
        'Domine' => 'Domine',
        'EB Garamond' => 'EB Garamond',
        'Exo 2' => 'Exo 2',
        'Figtree' => 'Figtree',
        'Fira Code' => 'Fira Code  (Mono)',
        'Fira Sans' => 'Fira Sans',
        'Frank Ruhl Libre' => 'Frank Ruhl Libre',
        'Gelasio' => 'Gelasio',
        'IBM Plex Mono' => 'IBM Plex Mono  (Mono)',
        'IBM Plex Sans' => 'IBM Plex Sans',
        'IBM Plex Serif' => 'IBM Plex Serif',
        'Inter' => 'Inter',
        'JetBrains Mono' => 'JetBrains Mono  (Mono)',
        'Jost' => 'Jost',
        'Karla' => 'Karla',
        'Lato' => 'Lato',
        'Lexend' => 'Lexend',
        'Libre Baskerville' => 'Libre Baskerville',
        'Lobster' => 'Lobster  (Display)',
        'Lora' => 'Lora',
        'Manrope' => 'Manrope',
        'Merriweather' => 'Merriweather',
        'Montserrat' => 'Montserrat',
        'Mulish' => 'Mulish',
        'Noto Sans' => 'Noto Sans',
        'Noto Sans JP' => 'Noto Sans JP',
        'Noto Sans KR' => 'Noto Sans KR',
        'Noto Serif' => 'Noto Serif',
        'Nunito' => 'Nunito',
        'Nunito Sans' => 'Nunito Sans',
        'Open Sans' => 'Open Sans',
        'Oswald' => 'Oswald',
        'Outfit' => 'Outfit',
        'Pacifico' => 'Pacifico  (Display)',
        'Playfair Display' => 'Playfair Display',
        'Plus Jakarta Sans' => 'Plus Jakarta Sans',
        'Poppins' => 'Poppins',
        'PT Serif' => 'PT Serif',
        'Questrial' => 'Questrial',
        'Raleway' => 'Raleway',
        'Righteous' => 'Righteous  (Display)',
        'Roboto' => 'Roboto',
        'Roboto Condensed' => 'Roboto Condensed  (Condensed)',
        'Roboto Mono' => 'Roboto Mono  (Mono)',
        'Roboto Slab' => 'Roboto Slab  (Slab)',
        'Rubik' => 'Rubik',
        'Source Code Pro' => 'Source Code Pro  (Mono)',
        'Source Sans 3' => 'Source Sans 3',
        'Source Serif 4' => 'Source Serif 4',
        'Space Mono' => 'Space Mono  (Mono)',
        'Spectral' => 'Spectral',
        'Teko' => 'Teko  (Condensed)',
        'Titillium Web' => 'Titillium Web',
        'Ubuntu' => 'Ubuntu',
        'Urbanist' => 'Urbanist',
        'Vollkorn' => 'Vollkorn',
        'Work Sans' => 'Work Sans',
        'Yanone Kaffeesatz' => 'Yanone Kaffeesatz  (Condensed)',
        'Zilla Slab' => 'Zilla Slab',
    );

    $wp_customize->add_section( 'np_typo_fonts', array( 'title' => __( 'Fonts', 'newspress' ), 'panel' => 'np_typography_panel', 'priority' => 10 ) );
    $add_ctrl( 'np_font_body',    __( 'Body Font',    'newspress' ), 'sys:Georgia', 'np_typo_fonts', 'select', $font_choices, __( 'Default: Georgia', 'newspress' ), 'postMessage' );
    $add_ctrl( 'np_font_heading', __( 'Heading Font', 'newspress' ), 'sys:Arial',   'np_typo_fonts', 'select', $font_choices, __( 'Default: Arial', 'newspress' ),   'postMessage' );
    /* np_google_font kept for backward-compat but hidden — value now derived from dropdowns */
    $wp_customize->add_setting( 'np_google_font', array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'refresh' ) );

    $wp_customize->add_section( 'np_typo_sizes', array( 'title' => __( 'Global Font Sizes', 'newspress' ), 'panel' => 'np_typography_panel', 'priority' => 20 ) );
    $add_range( 'np_font_size',         __( 'Base body size (px)',        'newspress' ), 16, 'np_typo_sizes', 12, 24, 1, 'px' );
    $add_range( 'np_font_size_widget',  __( 'Widget text size (px)',      'newspress' ), 14, 'np_typo_sizes', 10, 22, 1, 'px' );
    $add_range( 'np_font_size_meta',    __( 'Meta / label size (px)',     'newspress' ), 12, 'np_typo_sizes', 10, 18, 1, 'px' );
    $add_range( 'np_font_lh_body',      __( 'Body line-height (×10)',     'newspress' ), 16, 'np_typo_sizes',  8, 24, 1, '' );

    $wp_customize->add_section( 'np_typo_headings', array( 'title' => __( 'Heading Sizes', 'newspress' ), 'panel' => 'np_typography_panel', 'priority' => 30 ) );
    $add_range( 'np_h1_size', __( 'H1 (px)', 'newspress' ), 32, 'np_typo_headings', 18, 72, 1, 'px' );
    $add_range( 'np_h2_size', __( 'H2 (px)', 'newspress' ), 26, 'np_typo_headings', 16, 60, 1, 'px' );
    $add_range( 'np_h3_size', __( 'H3 (px)', 'newspress' ), 22, 'np_typo_headings', 14, 48, 1, 'px' );
    $add_range( 'np_h4_size', __( 'H4 (px)', 'newspress' ), 18, 'np_typo_headings', 12, 40, 1, 'px' );

    $wp_customize->add_section( 'np_typo_post', array( 'title' => __( 'Post / Article', 'newspress' ), 'panel' => 'np_typography_panel', 'priority' => 40 ) );
    $add_range( 'np_font_size_post',       __( 'Post body text (px)', 'newspress' ), 17, 'np_typo_post', 12, 26, 1, 'px' );
    $add_range( 'np_font_size_post_title', __( 'Post title (px)',     'newspress' ), 32, 'np_typo_post', 18, 72, 1, 'px' );
    $add_range( 'np_font_lh_post',         __( 'Post line-height (×10)', 'newspress' ), 17, 'np_typo_post',  8, 24, 1, '' );

    $wp_customize->add_section( 'np_typo_cards', array( 'title' => __( 'Cards (Homepage / Blog)', 'newspress' ), 'panel' => 'np_typography_panel', 'priority' => 50 ) );
    $add_range( 'np_font_size_card_title',   __( 'Card title (px)',   'newspress' ), 16, 'np_typo_cards', 12, 32, 1, 'px' );
    $add_range( 'np_font_size_card_excerpt', __( 'Card excerpt (px)', 'newspress' ), 13, 'np_typo_cards', 10, 20, 1, 'px' );
    $add_range( 'np_font_size_card_meta',    __( 'Card meta (px)',    'newspress' ), 12, 'np_typo_cards', 10, 18, 1, 'px' );

    /* ================================================================
       4. HEADER & TOP BAR  (priority 40)
       ================================================================ */
    $wp_customize->add_panel( 'np_header_panel', array( 'title' => __( 'Header & Top Bar', 'newspress' ), 'priority' => 40 ) );

    $wp_customize->add_section( 'np_layout_header', array( 'title' => __( 'Header Layout', 'newspress' ), 'panel' => 'np_header_panel' ) );
    $add_ctrl( 'np_show_site_title', __( 'Show Site Title',     'newspress' ), true, 'np_layout_header', 'checkbox', array(), '', 'postMessage' );
    $add_ctrl( 'np_show_tagline',    __( 'Show Tagline',        'newspress' ), true, 'np_layout_header', 'checkbox', array(), '', 'postMessage' );
    $add_ctrl( 'np_show_topbar',    __( 'Show Top Bar',        'newspress' ), true, 'np_layout_header', 'checkbox', array(), '', 'postMessage' );
    $add_ctrl( 'np_topbar_date',     __( 'Show Date in Top Bar','newspress' ), true, 'np_layout_header', 'checkbox' );
    $add_ctrl( 'np_show_search',     __( 'Show Header Search',  'newspress' ), true, 'np_layout_header', 'checkbox', array(), '', 'postMessage' );
    $add_ctrl( 'np_search_placeholder', __( 'Search Box Placeholder Text', 'newspress' ), __( 'Search news…', 'newspress' ), 'np_layout_header', 'text', array(), __( 'Text shown inside the header search box.', 'newspress' ), 'postMessage' );
    $add_ctrl( 'np_sticky_header',   __( 'Sticky Header',       'newspress' ), false,'np_layout_header', 'checkbox' );
    $add_ctrl( 'np_show_secondary_nav', __( 'Show Category Bar', 'newspress' ), true, 'np_layout_header', 'checkbox', array(), '', 'postMessage' );

    // Header dimensions — logo size, header height (vertical padding), site-title size
    $wp_customize->add_section( 'np_header_size', array(
        'title'       => __( 'Header Size', 'newspress' ),
        'description' => __( 'Resize the logo, header height and site title. The logo controls apply when a logo is set under Site Identity.', 'newspress' ),
        'panel'       => 'np_header_panel',
    ) );
    $add_range( 'np_logo_height',        __( 'Logo Height — Desktop (px)', 'newspress' ), 60, 'np_header_size', 20, 200, 1, 'px' );
    $add_range( 'np_logo_height_mobile', __( 'Logo Height — Mobile (px)',  'newspress' ), 60, 'np_header_size', 20, 120, 1, 'px' );
    $add_range( 'np_header_padding',     __( 'Header Height — Top/Bottom Padding (px)', 'newspress' ), 16, 'np_header_size', 0, 80, 1, 'px' );
    $add_range( 'np_site_title_size',    __( 'Site Title Size (px)', 'newspress' ), 28, 'np_header_size', 14, 72, 1, 'px' );

    $wp_customize->add_section( 'np_topbar_settings', array( 'title' => __( 'Top Bar Content', 'newspress' ), 'panel' => 'np_header_panel' ) );
    $add_ctrl( 'np_topbar_phone',     __( 'Phone / Contact',     'newspress' ), '',              'np_topbar_settings', 'text' );
    $add_ctrl( 'np_social_facebook',  __( 'Facebook URL',        'newspress' ), '',              'np_topbar_settings', 'url' );
    $add_ctrl( 'np_social_twitter',   __( 'Twitter / X URL',     'newspress' ), '',              'np_topbar_settings', 'url' );
    $add_ctrl( 'np_social_instagram', __( 'Instagram URL',       'newspress' ), '',              'np_topbar_settings', 'url' );
    $add_ctrl( 'np_social_youtube',   __( 'YouTube URL',         'newspress' ), '',              'np_topbar_settings', 'url' );
    $add_ctrl( 'np_social_linkedin',  __( 'LinkedIn URL',        'newspress' ), '',              'np_topbar_settings', 'url' );
    $add_ctrl( 'np_social_tiktok',    __( 'TikTok URL',          'newspress' ), '',              'np_topbar_settings', 'url' );
    $add_ctrl( 'np_social_rss',       __( 'RSS Feed URL',        'newspress' ), '',              'np_topbar_settings', 'url' );

    $wp_customize->add_section( 'np_header_ad_section', array(
        'title'       => __( 'Header Ad Zone', 'newspress' ),
        'description' => __( 'Controls the ad banner between your logo and the navigation bar.', 'newspress' ),
        'panel'       => 'np_header_panel',
    ) );
    $add_ctrl( 'np_header_ad_enable', __( 'Enable Header Ad Zone', 'newspress' ), false, 'np_header_ad_section', 'checkbox' );
    $add_ctrl( 'np_header_ad_code',   __( 'Ad Code (HTML)',        'newspress' ), '',    'np_header_ad_section', 'textarea', array(), __( 'Paste your AdSense <ins> tag or any ad HTML. Leave blank to use the "Above Header" widget area.', 'newspress' ) );
    $add_range( 'np_header_ad_width',  __( 'Ad Width (px)',  'newspress' ), 728, 'np_header_ad_section', 100, 970, 10, 'px' );
    $add_range( 'np_header_ad_height', __( 'Ad Height (px)', 'newspress' ),  90, 'np_header_ad_section',  50, 280, 10, 'px' );
    $add_ctrl( 'np_header_ad_align', __( 'Ad Alignment', 'newspress' ), 'center', 'np_header_ad_section', 'select', array(
        'left'   => __( 'Left',   'newspress' ),
        'center' => __( 'Center', 'newspress' ),
        'right'  => __( 'Right',  'newspress' ),
    ) );

    /* ================================================================
       5. HOMEPAGE  (priority 45)
       ================================================================ */
    $wp_customize->add_panel( 'np_home_panel', array( 'title' => __( 'Homepage', 'newspress' ), 'priority' => 45 ) );

    // Hero / Featured
    $wp_customize->add_section( 'np_home_hero', array( 'title' => __( 'Hero Section', 'newspress' ), 'panel' => 'np_home_panel' ) );
    $add_ctrl( 'np_show_hero',       __( 'Show Hero',         'newspress' ), true,   'np_home_hero', 'checkbox' );
    $add_ctrl( 'np_home_hero_style', __( 'Hero Style',        'newspress' ), 'grid', 'np_home_hero', 'select', array(
        'grid'    => __( 'Grid — 1 large + 2 small', 'newspress' ),
        'overlay' => __( 'Full-width overlay',        'newspress' ),
        'none'    => __( 'No Hero (latest posts only)','newspress' ),
    ) );
    // Breaking news ticker settings → managed in "Breaking News / Ticker" section below

    // Posts Grid
    $wp_customize->add_section( 'np_home_grid', array( 'title' => __( 'Posts Grid', 'newspress' ), 'panel' => 'np_home_panel' ) );
    $add_ctrl( 'np_home_posts_layout', __( 'Posts Layout', 'newspress' ), 'grid-3', 'np_home_grid', 'select', array(
        'grid-2' => __( '2 Column Grid',        'newspress' ),
        'grid-3' => __( '3 Column Grid',        'newspress' ),
        'grid-4' => __( '4 Column Grid',        'newspress' ),
        'list'   => __( 'List with Thumbnails', 'newspress' ),
    ) );
    $add_ctrl( 'np_card_image_ratio', __( 'Card Image Ratio', 'newspress' ), '16-9', 'np_home_grid', 'select', array(
        '16-9' => '16:9 — Widescreen',
        '3-2'  => '3:2  — Classic photo',
        '4-3'  => '4:3  — Standard',
        '1-1'  => '1:1  — Square',
    ) );
    $add_range( 'np_home_posts_count', __( 'Posts per page', 'newspress' ), 9, 'np_home_grid', 1, 48, 1, '' );

    // Navigation
    $wp_customize->add_section( 'np_home_nav', array( 'title' => __( 'Pagination / Load More', 'newspress' ), 'panel' => 'np_home_panel' ) );
    $add_ctrl( 'np_nav_style', __( 'Navigation Style', 'newspress' ), 'pagination', 'np_home_nav', 'select', array(
        'pagination' => __( 'Pagination', 'newspress' ),
        'loadmore'   => __( 'Load More button (AJAX)',       'newspress' ),
    ) );
    $add_ctrl( 'np_pag_align', __( 'Pagination Alignment', 'newspress' ), 'center', 'np_home_nav', 'select', array(
        'flex-start' => __( 'Left',   'newspress' ),
        'center'     => __( 'Center', 'newspress' ),
        'flex-end'   => __( 'Right',  'newspress' ),
    ), '', 'postMessage' );
    $add_range( 'np_pag_gap',        __( 'Gap between numbers (px)', 'newspress' ),  6, 'np_home_nav',  0, 32, 1, 'px' );
    $add_range( 'np_pag_size',       __( 'Number button size (px)',  'newspress' ), 36, 'np_home_nav', 24, 64, 1, 'px' );
    $add_range( 'np_pag_font_size',  __( 'Number font size (px)',    'newspress' ), 13, 'np_home_nav', 10, 22, 1, 'px' );
    $add_range( 'np_pag_radius',     __( 'Button border radius (px)','newspress' ),  4, 'np_home_nav',  0, 50, 1, 'px' );
    $add_range( 'np_pag_margin_top', __( 'Top/bottom margin (×0.1rem)', 'newspress' ), 20, 'np_home_nav', 0, 80, 1, '' );


    // Homepage builder — sections JSON
    // Each section: {type, cat_id, layout, count, show_more, title, enabled}
    $wp_customize->add_section( 'np_home_sections_sec', array(
        'title'       => __( 'Section Blocks', 'newspress' ),
        'description' => __( 'Build your homepage by adding sections below. Each section pulls posts from a category (or latest posts) and displays them in your chosen layout.', 'newspress' ),
        'panel'       => 'np_home_panel',
    ) );
    $wp_customize->add_setting( 'np_home_sections', array(
        'default'           => '',
        'sanitize_callback' => function( $val ) {
            if ( ! $val ) return '';
            $decoded = json_decode( $val, true );
            return ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded ) ) ? $val : '';
        },
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control(
        new NP_Section_Builder_Control( $wp_customize, 'np_home_sections', array(
            'label'   => __( 'Homepage Sections', 'newspress' ),
            'section' => 'np_home_sections_sec',
        ) )
    );

    /* ================================================================
       6. CATEGORY & ARCHIVE  (priority 50)
       ================================================================ */
    $wp_customize->add_panel( 'np_archive_panel', array( 'title' => __( 'Category & Archive', 'newspress' ), 'priority' => 50 ) );

    $wp_customize->add_section( 'np_archive_layout', array( 'title' => __( 'Layout', 'newspress' ), 'panel' => 'np_archive_panel' ) );
    $add_ctrl( 'np_archive_layout', __( 'Archive Layout', 'newspress' ), 'grid-3', 'np_archive_layout', 'select', array(
        'grid-2' => __( '2 Column Grid',        'newspress' ),
        'grid-3' => __( '3 Column Grid',        'newspress' ),
        'grid-4' => __( '4 Column Grid',        'newspress' ),
        'list'   => __( 'List with Thumbnails', 'newspress' ),
    ) );
    $add_ctrl( 'np_archive_sidebar', __( 'Sidebar Position', 'newspress' ), 'right', 'np_archive_layout', 'select', array(
        'right' => __( 'Right',   'newspress' ),
        'left'  => __( 'Left',    'newspress' ),
        'none'  => __( 'No Sidebar', 'newspress' ),
    ), '', 'postMessage' );
    $add_range( 'np_archive_posts_count', __( 'Posts per page', 'newspress' ), 12, 'np_archive_layout', 1, 48, 1, '' );
    $add_ctrl( 'np_archive_show_desc',   __( 'Show Category Description', 'newspress' ), true,  'np_archive_layout', 'checkbox' );
    $add_ctrl( 'np_archive_show_count',  __( 'Show Post Count in Header', 'newspress' ), true,  'np_archive_layout', 'checkbox' );
    $add_ctrl( 'np_archive_show_thumb',  __( 'Show Thumbnails',           'newspress' ), true,  'np_archive_layout', 'checkbox' );
    $add_ctrl( 'np_archive_show_excerpt','Show Excerpts',                               true,  'np_archive_layout', 'checkbox' );

    $wp_customize->add_section( 'np_search_layout', array( 'title' => __( 'Search Results', 'newspress' ), 'panel' => 'np_archive_panel' ) );
    $add_ctrl( 'np_search_layout', __( 'Search Results Layout', 'newspress' ), 'list', 'np_search_layout', 'select', array(
        'grid-2' => __( '2 Column Grid',        'newspress' ),
        'grid-3' => __( '3 Column Grid',        'newspress' ),
        'list'   => __( 'List with Thumbnails', 'newspress' ),
    ) );

    /* ================================================================
       7. SINGLE POST  (priority 55)
       ================================================================ */
    $wp_customize->add_panel( 'np_single_panel', array( 'title' => __( 'Single Post', 'newspress' ), 'priority' => 55 ) );

    // Layout
    $wp_customize->add_section( 'np_single_layout', array( 'title' => __( 'Layout', 'newspress' ), 'panel' => 'np_single_panel' ) );
    $add_ctrl( 'np_single_sidebar', __( 'Sidebar Position', 'newspress' ), 'right', 'np_single_layout', 'select', array(
        'right' => __( 'Right',      'newspress' ),
        'left'  => __( 'Left',       'newspress' ),
        'none'  => __( 'No Sidebar', 'newspress' ),
    ), '', 'postMessage' );
    $add_ctrl( 'np_single_width', __( 'Content Width', 'newspress' ), 'normal', 'np_single_layout', 'select', array(
        'narrow' => __( 'Narrow (reading-optimised)', 'newspress' ),
        'normal' => __( 'Normal',                     'newspress' ),
        'wide'   => __( 'Wide (full container)',       'newspress' ),
    ) );

    // Featured Image
    $wp_customize->add_section( 'np_single_image', array( 'title' => __( 'Featured Image', 'newspress' ), 'panel' => 'np_single_panel' ) );
    $add_ctrl( 'np_single_show_featured', __( 'Show Featured Image', 'newspress' ), true, 'np_single_image', 'checkbox', array(), '', 'refresh' );
    $add_ctrl( 'np_single_image_style', __( 'Image Style', 'newspress' ), 'full', 'np_single_image', 'select', array(
        'full'   => __( 'Full width',          'newspress' ),
        'inset'  => __( 'Inset (with margin)', 'newspress' ),
        'banner' => __( 'Banner / Hero strip', 'newspress' ),
    ) );
    $add_ctrl( 'np_single_show_caption', __( 'Show Image Caption', 'newspress' ), true, 'np_single_image', 'checkbox' );

    // Meta & Author
    $wp_customize->add_section( 'np_single_meta', array( 'title' => __( 'Author & Meta', 'newspress' ), 'panel' => 'np_single_panel' ) );
    $add_ctrl( 'np_show_author',       __( 'Show Author Name',       'newspress' ), true,  'np_single_meta', 'checkbox' );
    $add_ctrl( 'np_show_date',         __( 'Show Publish Date',      'newspress' ), true,  'np_single_meta', 'checkbox' );
    $add_ctrl( 'np_show_updated_date', __( 'Show Last Updated Date', 'newspress' ), false, 'np_single_meta', 'checkbox' );
    $add_ctrl( 'np_show_reading_time', __( 'Show Reading Time',      'newspress' ), true,  'np_single_meta', 'checkbox' );
    $add_ctrl( 'np_show_cats',         __( 'Show Category Badges',   'newspress' ), true,  'np_single_meta', 'checkbox' );
    $add_ctrl( 'np_show_tags',         __( 'Show Post Tags',         'newspress' ), true,  'np_single_meta', 'checkbox' );
    $add_ctrl( 'np_date_format', __( 'Date Format', 'newspress' ), 'M j, Y', 'np_single_meta', 'select', array(
        'M j, Y' => 'Jan 1, 2025',
        'F j, Y' => 'January 1, 2025',
        'd/m/Y'  => '01/01/2025',
        'd M Y'  => '01 Jan 2025',
        'Y-m-d'  => '2025-01-01',
        'ago'    => 'Time ago (e.g. 2 hours ago)',
    ) );
    $add_ctrl( 'np_show_author_box',  __( 'Show Author Bio Box',    'newspress' ), true, 'np_single_meta', 'checkbox' );

    // Content Enhancements
    $wp_customize->add_section( 'np_single_content', array( 'title' => __( 'Content Features', 'newspress' ), 'panel' => 'np_single_panel' ) );
    $add_ctrl( 'np_show_progress_bar',  __( 'Reading Progress Bar',      'newspress' ), true,  'np_single_content', 'checkbox' );
    $add_ctrl( 'np_show_share',        __( 'Show Share Buttons',         'newspress' ), true,  'np_single_content', 'checkbox' );
    $add_ctrl( 'np_share_position',    __( 'Share Buttons Position',     'newspress' ), 'bottom', 'np_single_content', 'select', array(
        'top'    => __( 'Above content', 'newspress' ),
        'bottom' => __( 'Below content', 'newspress' ),
        'both'   => __( 'Above and below', 'newspress' ),
        'sticky' => __( 'Sticky sidebar', 'newspress' ),
    ) );
    $add_ctrl( 'np_show_related',      __( 'Show Related Posts',         'newspress' ), true,  'np_single_content', 'checkbox' );
    $add_ctrl( 'np_related_count',     __( 'Related Posts Count',        'newspress' ), '3',   'np_single_content', 'select', array( '2'=>'2', '3'=>'3', '4'=>'4', '6'=>'6' ) );

    /* ================================================================
       8. SIDEBAR & WIDGETS  (priority 60)
       ================================================================ */
    $wp_customize->add_panel( 'np_sidebar_panel', array( 'title' => __( 'Sidebar & Widgets', 'newspress' ), 'priority' => 60 ) );

    $wp_customize->add_section( 'np_sidebar_settings', array( 'title' => __( 'Sidebar', 'newspress' ), 'panel' => 'np_sidebar_panel' ) );
    $add_ctrl( 'np_sidebar_pos',    __( 'Default Sidebar Position', 'newspress' ), 'right', 'np_sidebar_settings', 'select', array(
        'right' => __( 'Right',      'newspress' ),
        'left'  => __( 'Left',       'newspress' ),
        'none'  => __( 'No Sidebar', 'newspress' ),
    ), '', 'postMessage' );
    $add_ctrl( 'np_sticky_sidebar', __( 'Sticky Sidebar', 'newspress' ), false, 'np_sidebar_settings', 'checkbox', array(), __( 'Keeps sidebar visible while scrolling.', 'newspress' ) );
    $add_range( 'np_sidebar_width', __( 'Sidebar Width (px)', 'newspress' ), 300, 'np_sidebar_settings', 200, 420, 10, 'px' );

    $wp_customize->add_section( 'np_widget_style', array( 'title' => __( 'Widget Style', 'newspress' ), 'panel' => 'np_sidebar_panel' ) );
    $add_ctrl( 'np_widget_style', __( 'Widget Style', 'newspress' ), 'boxed', 'np_widget_style', 'select', array(
        'boxed'    => __( 'Boxed (border)',       'newspress' ),
        'flat'     => __( 'Flat (no border)',     'newspress' ),
        'shadowed' => __( 'Card with shadow',     'newspress' ),
        'minimal'  => __( 'Minimal (title only)', 'newspress' ),
    ), '', 'postMessage' );
    $add_ctrl( 'np_widget_title_style', __( 'Widget Title Style', 'newspress' ), 'underline', 'np_widget_style', 'select', array(
        'underline'   => __( 'Underline (colored)', 'newspress' ),
        'background'  => __( 'Filled background',   'newspress' ),
        'plain'       => __( 'Plain text',           'newspress' ),
        'left-border' => __( 'Left border accent',   'newspress' ),
    ), '', 'postMessage' );
    $add_range( 'np_widget_font_size', __( 'Widget Font Size (px)', 'newspress' ), 14, 'np_widget_style', 10, 22, 1, 'px' );

    /* ================================================================
       9. ADVERTISEMENTS  (priority 65)
       ================================================================ */
    $wp_customize->add_panel( 'np_ads_panel', array( 'title' => __( 'Advertisements', 'newspress' ), 'priority' => 65 ) );

    $wp_customize->add_section( 'np_ads_settings', array(
        'title'       => __( 'Ad Slots', 'newspress' ),
        'description' => __( 'Ad slot code is managed under Appearance → NewsPress Settings → Advertisements. Here you control which pages show ads.', 'newspress' ),
        'panel'       => 'np_ads_panel',
    ) );

    $wp_customize->add_section( 'np_ads_display', array( 'title' => __( 'Display Settings', 'newspress' ), 'panel' => 'np_ads_panel' ) );
    $add_ctrl( 'np_ads_show_on_home',   __( 'Show Ads on Homepage',    'newspress' ), true,  'np_ads_display', 'checkbox' );
    $add_ctrl( 'np_ads_show_on_single', __( 'Show Ads on Single Posts','newspress' ), true,  'np_ads_display', 'checkbox' );
    $add_ctrl( 'np_ads_show_on_arch',   __( 'Show Ads on Archives',    'newspress' ), false, 'np_ads_display', 'checkbox' );
    $add_ctrl( 'np_ads_label',          __( 'Ad Label Text',           'newspress' ), 'Advertisement', 'np_ads_display', 'text', array(), __( 'Label shown above ad slots. Leave blank to hide.', 'newspress' ) );

    /* ================================================================
       10. BREAKING NEWS  (priority 70)
       ================================================================ */
    $wp_customize->add_section( 'np_breaking_section', array(
        'title'    => __( 'Breaking News / Ticker', 'newspress' ),
        'panel'    => 'np_header_panel',
        'priority' => 50,
    ) );
    $add_ctrl( 'np_show_breaking',      __( 'Enable Ticker',        'newspress' ), true,      'np_breaking_section', 'checkbox', array(), '', 'postMessage' );
    $add_ctrl( 'np_breaking_label',     __( 'Label Text',           'newspress' ), 'Latest',  'np_breaking_section', 'text' );
    $add_ctrl( 'np_breaking_source',    __( 'Posts Source',         'newspress' ), 'latest',  'np_breaking_section', 'select', array(
        'latest'   => __( 'Latest Posts',             'newspress' ),
        'featured' => __( 'Featured / Sticky Posts',  'newspress' ),
        'cat'      => __( 'Specific Category',        'newspress' ),
    ) );
    // Category dropdown — only visible when source = 'cat'
    $wp_customize->add_setting( 'np_breaking_cat', array(
        'default'           => 0,
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh',
    ) );
    $wp_customize->add_control( new NewsPress_Category_Select_Control( $wp_customize, 'np_breaking_cat', array(
        'label'           => __( 'Category', 'newspress' ),
        'description'     => __( 'Shown only when Posts Source is set to "Specific Category".', 'newspress' ),
        'section'         => 'np_breaking_section',
        'active_callback' => function() {
            return get_theme_mod( 'np_breaking_source', 'latest' ) === 'cat';
        },
    ) ) );
    $add_range( 'np_breaking_count',    __( 'Number of headlines', 'newspress' ), 10, 'np_breaking_section', 3, 30, 1, '' );
    $add_ctrl( 'np_breaking_speed',     __( 'Scroll Speed', 'newspress' ), 'normal', 'np_breaking_section', 'select', array(
        'slow'   => __( 'Slow',   'newspress' ),
        'normal' => __( 'Normal', 'newspress' ),
        'fast'   => __( 'Fast',   'newspress' ),
    ) );
    $add_color( 'np_breaking_bg',    __( 'Label Background', 'newspress' ), '#d32f2f', 'np_breaking_section' );
    $add_color( 'np_breaking_color', __( 'Label Text Color', 'newspress' ), '#ffffff', 'np_breaking_section' );

    /* ================================================================
       11. FOOTER  (priority 75)
       ================================================================ */
    $wp_customize->add_panel( 'np_footer_panel', array( 'title' => __( 'Footer', 'newspress' ), 'priority' => 70 ) );

    $wp_customize->add_section( 'np_footer_settings', array( 'title' => __( 'Footer Settings', 'newspress' ), 'panel' => 'np_footer_panel' ) );
    $add_ctrl( 'np_footer_cols',          __( 'Footer Columns',         'newspress' ), '4',  'np_footer_settings', 'select', array( '1'=>'1', '2'=>'2', '3'=>'3', '4'=>'4' ) );
    $add_ctrl( 'np_footer_copyright',     __( 'Copyright Text',         'newspress' ), '&copy; ' . date( 'Y' ) . ' ' . get_bloginfo( 'name' ) . '. All Rights Reserved.', 'np_footer_settings', 'textarea' );
    $add_ctrl( 'np_footer_show_back_top', __( 'Show Back to Top Button','newspress' ), true, 'np_footer_settings', 'checkbox' );
    $add_ctrl( 'np_footer_show_info',     __( 'Show Footer Info Row (Logo + About + Follow)', 'newspress' ), true, 'np_footer_settings', 'checkbox' );
    $add_ctrl( 'np_footer_about_text',    __( 'About Us Text',          'newspress' ), '', 'np_footer_settings', 'textarea' );
    $add_ctrl( 'np_footer_contact_email', __( 'Contact Email',          'newspress' ), '', 'np_footer_settings', 'text' );
    $add_ctrl( 'np_footer_contact_label', __( 'Contact Label',          'newspress' ), __( 'Contact us:', 'newspress' ), 'np_footer_settings', 'text' );
    $add_ctrl( 'np_footer_show_follow',   __( 'Show Follow Us Icons',   'newspress' ), true, 'np_footer_settings', 'checkbox' );

    /* ================================================================
       12. GENERAL LAYOUT  (priority 80)
       ================================================================ */
    /* ── Design & Layout panel — absorbs loose sections ── */
    $wp_customize->add_panel( 'np_design_panel', array(
        'title'    => __( 'Design & Layout', 'newspress' ),
        'priority' => 75,
    ) );
    $wp_customize->add_section( 'np_layout_general', array( 'title' => __( 'General Layout', 'newspress' ), 'panel' => 'np_design_panel', 'priority' => 10 ) );
    $add_range( 'np_container_width', __( 'Max Container Width (px)', 'newspress' ), 1200, 'np_layout_general', 900, 1600, 10, 'px' );
    $wp_customize->add_section( 'np_layout_widths', array(
        'title'       => __( 'Header, Menu & Footer Width', 'newspress' ),
        'description' => __( 'Set the width of the header, navigation menu and footer independently. Width 0 = same as Max Container Width. "Boxed" also limits the bar background so it no longer spans the full screen.', 'newspress' ),
        'panel'       => 'np_design_panel',
        'priority'    => 11,
    ) );
    $bar_modes = array(
        'full'  => __( 'Full screen width (content centred)', 'newspress' ),
        'boxed' => __( 'Boxed (background limited to width)', 'newspress' ),
    );
    $add_range( 'np_header_width', __( 'Header Width (px, 0 = default)', 'newspress' ), 0, 'np_layout_widths', 0, 1920, 10, 'px' );
    $add_ctrl(  'np_header_bg_mode', __( 'Header Background', 'newspress' ), 'full', 'np_layout_widths', 'select', $bar_modes );
    $add_range( 'np_nav_width',    __( 'Navigation Menu Width (px, 0 = default)', 'newspress' ), 0, 'np_layout_widths', 0, 1920, 10, 'px' );
    $add_ctrl(  'np_nav_bg_mode',  __( 'Navigation Background', 'newspress' ), 'full', 'np_layout_widths', 'select', $bar_modes );
    $add_range( 'np_footer_width', __( 'Footer Width (px, 0 = default)', 'newspress' ), 0, 'np_layout_widths', 0, 1920, 10, 'px' );
    $add_ctrl(  'np_footer_bg_mode', __( 'Footer Background', 'newspress' ), 'full', 'np_layout_widths', 'select', $bar_modes );
    $add_range( 'np_border_radius',   __( 'Global Border Radius (px)', 'newspress' ),    4, 'np_layout_general',   0,   20,  1, 'px' );
    // Sidebar position → in Sidebar & Widgets panel

    /* ================================================================
       13. BACK-TO-TOP BUTTON  (priority 85)
       ================================================================ */
    $wp_customize->add_section( 'np_back_top', array( 'title' => __( 'Back-to-Top Button', 'newspress' ), 'panel' => 'np_design_panel', 'priority' => 20 ) );
    $add_range( 'np_btt_size',   __( 'Button size (px)',           'newspress' ), 40, 'np_back_top', 28, 80, 1, 'px' );
    $add_range( 'np_btt_icon',   __( 'Icon size (px)',             'newspress' ), 18, 'np_back_top', 10, 40, 1, 'px' );
    $add_range( 'np_btt_radius', __( 'Border radius (px, 50=circle)', 'newspress' ), 50, 'np_back_top', 0, 50, 1, 'px' );
    $add_range( 'np_btt_bottom', __( 'Distance from bottom (px)', 'newspress' ), 24, 'np_back_top',  8, 120, 1, 'px' );
    $add_range( 'np_btt_right',  __( 'Distance from right (px)',  'newspress' ), 24, 'np_back_top',  8, 120, 1, 'px' );
    $add_ctrl(  'np_btt_bg',     __( 'Background color',          'newspress' ), '#d32f2f', 'np_back_top', 'color', array(), '', 'postMessage' );
    $add_ctrl(  'np_btt_color',  __( 'Icon color',                'newspress' ), '#ffffff', 'np_back_top', 'color', array(), '', 'postMessage' );
    $add_ctrl(  'np_btt_cursor', __( 'Cursor style',              'newspress' ), 'pointer', 'np_back_top', 'select', array(
        'pointer'   => __( 'Pointer (hand)',  'newspress' ),
        'default'   => __( 'Default (arrow)', 'newspress' ),
        'crosshair' => __( 'Crosshair',       'newspress' ),
        'grab'      => __( 'Grab',            'newspress' ),
        'zoom-in'   => __( 'Zoom in',         'newspress' ),
        'none'      => __( 'None',            'newspress' ),
    ), '', 'postMessage' );

    /* ================================================================
       14. EXCERPTS & CONTENT  (priority 90)
       ================================================================ */
    $wp_customize->add_section( 'np_excerpt_section', array( 'title' => __( 'Excerpts & Content', 'newspress' ), 'panel' => 'np_design_panel', 'priority' => 30 ) );
    $wp_customize->add_setting( 'np_excerpt_length', array( 'default' => 20, 'sanitize_callback' => 'absint', 'transport' => 'refresh' ) );
    $wp_customize->add_control( new NewsPress_Range_Control( $wp_customize, 'np_excerpt_length', array(
        'label'       => __( 'Excerpt Length', 'newspress' ),
        'description' => __( 'Default: 20 words', 'newspress' ),
        'section'     => 'np_excerpt_section',
        'unit'        => ' words',
        'min'         => 10,
        'max'         => 60,
        'step'        => 5,
    ) ) );
    $add_ctrl( 'np_show_excerpt',   __( 'Show Excerpts on Cards', 'newspress' ), true,         'np_excerpt_section', 'checkbox' );
    $add_ctrl( 'np_badge_position', __( 'Badge Position on Cards','newspress' ), 'above-title','np_excerpt_section', 'select', array(
        'above-title' => __( 'Above Title (default)',        'newspress' ),
        'below-title' => __( 'Below Title',                  'newspress' ),
        'over-image'  => __( 'Over Thumbnail Image',         'newspress' ),
        'above-meta'  => __( 'Above Meta (date/author row)', 'newspress' ),
        'none'        => __( 'Hide Badge on Cards',          'newspress' ),
    ) );

    /* ================================================================
       CARD & IMAGE FLOAT EFFECT  (priority 35)
       ================================================================ */
    $np_float_mode_choices = array(
        'off'   => __( 'Off',               'newspress' ),
        'hover' => __( 'On hover only',     'newspress' ),
        'always'=> __( 'Always (no hover)', 'newspress' ),
    );

    $wp_customize->add_section( 'np_float_section', array(
        'title'       => __( '✦ Card & Image Float Effect', 'newspress' ),
        'panel'       => 'np_design_panel',
        'priority'    => 35,
        'description' => __( 'Control float/shadow effects independently per area. "Always" = permanent shadow with no interaction needed. "On hover" = lifts when cursor touches. "Off" = disabled for that zone.', 'newspress' ),
    ) );

    /* ── Zone controls ── */
    $add_ctrl( 'np_float_zone_cards',  __( '① Post Cards (homepage / archive / category)',   'newspress' ), 'hover',  'np_float_section', 'select', $np_float_mode_choices, '', 'postMessage' );
    $add_ctrl( 'np_float_zone_hero',   __( '② Hero & Section Images (big featured images)',  'newspress' ), 'hover',  'np_float_section', 'select', $np_float_mode_choices, '', 'postMessage' );
    $add_ctrl( 'np_float_zone_single', __( '③ Single Post / Page Images (in article body)', 'newspress' ), 'always', 'np_float_section', 'select', $np_float_mode_choices, '', 'postMessage' );
    $add_ctrl( 'np_float_zone_widget', __( '④ Widget & Sidebar Cards',                      'newspress' ), 'hover',  'np_float_section', 'select', $np_float_mode_choices, '', 'postMessage' );

    /* ── Shared appearance ── */
    /* ── Lift & speed ── */
    $add_range( 'np_float_lift',           __( 'Lift height (px)',              'newspress' ),  4, 'np_float_section',  0, 24,  1, 'px' );
    $add_range( 'np_float_duration',       __( 'Transition speed (ms)',         'newspress' ), 220, 'np_float_section', 80, 600, 10, 'ms' );

    /* ── Shadow direction preset ── */
    $add_ctrl( 'np_float_shadow_dir', __( 'Shadow direction', 'newspress' ), 'bottom', 'np_float_section', 'select', array(
        'bottom'       => __( '⬇ Bottom (default)',  'newspress' ),
        'bottom-right' => __( '↘ Bottom-right',      'newspress' ),
        'bottom-left'  => __( '↙ Bottom-left',       'newspress' ),
        'top'          => __( '⬆ Top',               'newspress' ),
        'top-right'    => __( '↗ Top-right',         'newspress' ),
        'top-left'     => __( '↖ Top-left',          'newspress' ),
        'right'        => __( '➡ Right',             'newspress' ),
        'left'         => __( '⬅ Left',              'newspress' ),
        'center'       => __( '⊙ All sides (glow)',  'newspress' ),
        'custom'       => __( '✏ Custom X / Y',      'newspress' ),
    ), __( 'Direction the shadow falls. Choose "Custom X / Y" for full control.', 'newspress' ), 'postMessage' );

    /* ── Custom X / Y (shown only when direction = custom) ── */
    $add_range( 'np_float_shadow_x', __( 'Shadow X offset (px, negative = left)', 'newspress' ),  0, 'np_float_section', -40, 40, 1, 'px' );
    $add_range( 'np_float_shadow_y', __( 'Shadow Y offset (px, negative = top)',  'newspress' ),  8, 'np_float_section', -40, 40, 1, 'px' );

    /* ── Shadow appearance ── */
    $add_ctrl(  'np_float_shadow_color',   __( 'Shadow color',                  'newspress' ), '#000000', 'np_float_section', 'color', array(), '', 'postMessage' );
    $add_range( 'np_float_shadow_opacity', __( 'Shadow opacity (0–100)',        'newspress' ), 18, 'np_float_section', 0, 80, 1, '' );
    $add_range( 'np_float_shadow_blur',    __( 'Shadow blur (px)',              'newspress' ), 20, 'np_float_section', 4, 80, 2, 'px' );
    $add_range( 'np_float_shadow_spread',  __( 'Shadow spread (px)',            'newspress' ),  0, 'np_float_section', 0, 30, 1, 'px' );

    /* ── Image zoom & card bg ── */
    $add_range( 'np_float_scale',          __( 'Image zoom on hover (×100)',   'newspress' ), 105, 'np_float_section', 100, 115, 1, '' );
    $add_ctrl(  'np_float_card_bg',        __( 'Card background color',         'newspress' ), '', 'np_float_section', 'color', array(), __( 'Leave blank = theme default', 'newspress' ), 'postMessage' );

    /* ================================================================
       15. DARK MODE  (priority 95)
       ================================================================ */
    $wp_customize->add_section( 'np_darkmode_section', array(
        'title'       => __( 'Dark Mode', 'newspress' ),
        'panel'       => 'np_design_panel',
        'priority'    => 40,
        'description' => __( 'Visitors switch between Light and Night themselves with the header toggle — their choice is remembered on their own device. New visitors always start in Light mode; this theme never follows the visitor\'s device/browser dark-mode setting.', 'newspress' ),
    ) );
    $add_ctrl( 'np_dark_mode_toggle', __( 'Show Dark Mode Toggle Button', 'newspress' ), true,  'np_darkmode_section', 'checkbox', array(), __( 'Hides or shows the Day/Night button in the top bar.', 'newspress' ) );

    /* ================================================================
       16. PERFORMANCE  (priority 100)
       Performance flags now live only on Appearance → NewsPress Settings →
       Performance (a single get_option()-backed source of truth) — see the
       Performance settings audit notes. Nothing is registered here anymore
       to avoid the same setting being editable — and out of sync — in two
       different places.
       ================================================================ */
    /* ── Advanced panel — technical/infrequent settings ── */
    $wp_customize->add_panel( 'np_advanced_panel', array(
        'title'    => __( 'Advanced', 'newspress' ),
        'priority' => 80,
    ) );

    /* ================================================================
       17. COOKIE CONSENT — style/position only  (priority 105)
       ================================================================ */
    $wp_customize->add_section( 'np_cookie_style', array(
        'title'       => __( 'Cookie Banner', 'newspress' ),
        'panel'       => 'np_advanced_panel',
        'priority'    => 20,
        'description' => sprintf(
            /* translators: %s = URL to admin settings */
            __( 'Colors and position are set here. To enable the banner, set privacy page URLs, and edit banner text → <a href="%s" target="_blank"><strong>NewsPress Settings → Privacy</strong></a>', 'newspress' ),
            esc_url( admin_url( 'themes.php?page=newspress-settings&tab=privacy' ) )
        ),
    ) );
    // Allow setting URLs directly in Customizer as alternative to admin settings
    $add_ctrl( 'np_cookie_privacy_url',  __( 'Privacy Policy URL',  'newspress' ), '/privacy-policy/', 'np_cookie_style', 'url', array(), __( 'Also editable in NewsPress Settings → Privacy.', 'newspress' ) );
    $add_ctrl( 'np_cookie_policy_url',   __( 'Cookie Policy URL',   'newspress' ), '/cookie-policy/',  'np_cookie_style', 'url', array(), __( 'Also editable in NewsPress Settings → Privacy.', 'newspress' ) );
    $add_ctrl( 'np_cookie_banner_text',  __( 'Banner Message',      'newspress' ), 'We use cookies to improve your experience. By continuing you agree to our cookie policy.', 'np_cookie_style', 'textarea', array(), __( 'Also editable in NewsPress Settings → Privacy.', 'newspress' ) );
        $add_ctrl( 'np_cookie_position', __( 'Banner Position',              'newspress' ), 'bottom',  'np_cookie_style', 'select', array(
        'bottom' => __( 'Bottom', 'newspress' ),
        'top'    => __( 'Top',    'newspress' ),
    ) );
    $add_ctrl( 'np_cookie_wall', __( 'Consent Wall Mode', 'newspress' ), 'scroll', 'np_cookie_style', 'select', array(
        'none'   => __( 'None — banner only, page is fully readable', 'newspress' ),
        'scroll' => __( 'Scroll lock — page locked until consent',    'newspress' ),
        'blur'   => __( 'Blur — page blurred until consent',          'newspress' ),
    ), __( 'EU visitors only. Non-EU visitors are silently auto-consented.', 'newspress' ) );
    $add_range( 'np_cookie_expiry', __( 'Cookie Expiry (days)', 'newspress' ), 365, 'np_cookie_style', 30, 730, 1, ' days', __( 'How long consent is remembered. Minimum 30 days.', 'newspress' ) );
    $add_color( 'np_cookie_banner_bg', __( 'Banner / Modal Background', 'newspress' ), '#ffffff', 'np_cookie_style' );
    $add_color( 'np_cookie_prefs_bg',  __( 'Preferences Panel BG',      'newspress' ), '#ffffff', 'np_cookie_style' );
    $add_color( 'np_cookie_text_color',__( 'Text Color',                 'newspress' ), '#1a1a2e', 'np_cookie_style' );
    $add_color( 'np_cookie_btn_bg',    __( 'Button Color',               'newspress' ), '#5046e4', 'np_cookie_style' );
    $add_color( 'np_cookie_btn_text',  __( 'Button Text Color',          'newspress' ), '#ffffff', 'np_cookie_style' );
    $add_color( 'np_cookie_link_color',__( 'Link / Accent Color',        'newspress' ), '#5046e4', 'np_cookie_style' );

    /* ================================================================
       Selective Refresh
       ================================================================ */
    $wp_customize->selective_refresh->add_partial( 'blogname', array(
        'selector'        => '.np-site-title',
        'render_callback' => function() { bloginfo( 'name' ); },
    ) );
    $wp_customize->selective_refresh->add_partial( 'blogdescription', array(
        'selector'        => '.np-site-tagline',
        'render_callback' => function() { bloginfo( 'description' ); },
    ) );
    /* ── Ensure WP core Widgets panel appears after our Sidebar & Widgets ── */
    $widgets_panel = $wp_customize->get_panel( 'widgets' );
    if ( $widgets_panel ) {
        $widgets_panel->priority = 62;
    }
}
add_action( 'customize_register', 'newspress_customize_register' );

/* ============================================================
   Customizer Live Preview JS
   ============================================================ */
function newspress_customize_preview_js() {
    wp_enqueue_script(
        'newspress-customizer',
        NEWSPRESS_URI . '/js/customizer.js',
        array( 'customize-preview' ),
        NEWSPRESS_VERSION,
        true
    );
}
add_action( 'customize_preview_init', 'newspress_customize_preview_js' );
