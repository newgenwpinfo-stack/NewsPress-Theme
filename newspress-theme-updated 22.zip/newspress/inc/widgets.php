<?php
/**
 * NewsPress Custom Widgets
 * - NP_Stay_Connected_Widget  : Social counters (FB/Twitter/YouTube)
 * - NP_Popular_Posts_Widget   : Numbered list with thumbnails + load more
 * - NP_Popular_Cats_Widget    : Category list with post counts
 *
 * @package NewsPress
 */
defined( 'ABSPATH' ) || exit;

/* ============================================================
   1. STAY CONNECTED WIDGET
   ============================================================ */
class NP_Stay_Connected_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'np_stay_connected', __( '📡 Stay Connected', 'newspress' ), array(
            'description' => __( 'Social media fan/follower counts with action buttons.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title = apply_filters( 'widget_title', $instance['title'] ?? __( 'Stay Connected', 'newspress' ) );
        echo $args['before_widget'];
        if ( $title ) echo $args['before_title'] . esc_html( $title ) . $args['after_title'];

        $networks = array(
            'fb' => array(
                'label'      => __( 'Fans',      'newspress' ),
                'btn'        => __( 'LIKE',       'newspress' ),
                'icon_class' => 'np-sc-fb',
                'count_key'  => 'fb_count',
                'url_key'    => 'fb_url',
                'icon'       => '<svg viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
            ),
            'tw' => array(
                'label'      => __( 'Followers',  'newspress' ),
                'btn'        => __( 'FOLLOW',     'newspress' ),
                'icon_class' => 'np-sc-tw',
                'count_key'  => 'tw_count',
                'url_key'    => 'tw_url',
                'icon'       => '<svg viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
            ),
            'yt' => array(
                'label'      => __( 'Subscribers','newspress' ),
                'btn'        => __( 'SUBSCRIBE',  'newspress' ),
                'icon_class' => 'np-sc-yt',
                'count_key'  => 'yt_count',
                'url_key'    => 'yt_url',
                'icon'       => '<svg viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
            ),
        );
        ?>
        <div class="np-social-counter">
        <?php foreach ( $networks as $key => $net ) :
            $count = ! empty( $instance[ $net['count_key'] ] ) ? $instance[ $net['count_key'] ] : '';
            $url   = ! empty( $instance[ $net['url_key']   ] ) ? $instance[ $net['url_key']   ] : '#';
            if ( ! $count && $url === '#' ) continue;
        ?>
            <div class="np-social-counter-item <?php echo esc_attr( $net['icon_class'] ); ?>">
                <div class="np-sc-icon"><?php echo $net['icon']; // phpcs:ignore ?></div>
                <div class="np-sc-meta">
                    <div class="np-sc-count"><?php echo esc_html( $count ); ?></div>
                    <div class="np-sc-label"><?php echo esc_html( $net['label'] ); ?></div>
                </div>
                <a href="<?php echo esc_url( $url ); ?>" class="np-sc-btn" target="_blank" rel="noopener noreferrer">
                    <?php echo esc_html( $net['btn'] ); ?>
                </a>
            </div>
        <?php endforeach; ?>
        </div>
        <?php
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $fields = array(
            'title'    => array( 'label' => __( 'Title', 'newspress' ),               'default' => __( 'Stay Connected', 'newspress' ) ),
            'fb_count' => array( 'label' => __( 'Facebook fans count', 'newspress' ),  'default' => '' ),
            'fb_url'   => array( 'label' => __( 'Facebook URL', 'newspress' ),         'default' => '' ),
            'tw_count' => array( 'label' => __( 'Twitter followers count', 'newspress' ), 'default' => '' ),
            'tw_url'   => array( 'label' => __( 'Twitter URL', 'newspress' ),          'default' => '' ),
            'yt_count' => array( 'label' => __( 'YouTube subscribers count', 'newspress' ), 'default' => '' ),
            'yt_url'   => array( 'label' => __( 'YouTube URL', 'newspress' ),          'default' => '' ),
        );
        foreach ( $fields as $key => $f ) {
            $val = $instance[ $key ] ?? $f['default'];
            printf(
                '<p><label for="%s">%s</label><input class="widefat" id="%s" name="%s" type="text" value="%s"></p>',
                esc_attr( $this->get_field_id( $key ) ),
                esc_html( $f['label'] ),
                esc_attr( $this->get_field_id( $key ) ),
                esc_attr( $this->get_field_name( $key ) ),
                esc_attr( $val )
            );
        }
    }

    public function update( $new, $old ) {
        foreach ( array( 'title','fb_count','fb_url','tw_count','tw_url','yt_count','yt_url' ) as $k ) {
            $new[ $k ] = sanitize_text_field( $new[ $k ] ?? '' );
        }
        return $new;
    }
}

/* ============================================================
   2. POPULAR / RECENT POSTS WIDGET (numbered with thumbs)
   ============================================================ */
class NP_Popular_Posts_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'np_popular_posts', __( '🔥 Popular Posts (Numbered)', 'newspress' ), array(
            'description' => __( 'Numbered list of posts with thumbnails, date, and load-more link.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title   = apply_filters( 'widget_title', $instance['title'] ?? __( 'Most Popular', 'newspress' ) );
        $count   = (int) ( $instance['count'] ?? 5 );
        $orderby = $instance['orderby'] ?? 'comment_count';

        $q = new WP_Query( array(
            'post_type'           => 'post',
            'posts_per_page'      => $count,
            'orderby'             => $orderby,
            'order'               => 'DESC',
            'no_found_rows'       => true,
            'ignore_sticky_posts' => true,
        ) );

        if ( ! $q->have_posts() ) return;

        echo $args['before_widget'];
        if ( $title ) echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        ?>
        <ol class="np-numbered-posts">
        <?php $n = 0; while ( $q->have_posts() ) : $q->the_post(); $n++; ?>
            <li>
                <span class="np-num"><?php echo $n < 10 ? '0' . $n : $n; ?></span>
                <?php if ( has_post_thumbnail() ) : ?>
                    <a href="<?php the_permalink(); ?>">
                        <?php the_post_thumbnail( 'newspress-thumb', array( 'class' => 'np-num-thumb', 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ) ); ?>
                    </a>
                <?php endif; ?>
                <div class="np-num-body">
                    <h4 class="np-num-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                    <span class="np-num-date"><?php echo esc_html( get_the_date() ); ?></span>
                </div>
            </li>
        <?php endwhile; wp_reset_postdata(); ?>
        </ol>
        <?php if ( ! empty( $instance['load_more_text'] ) ) : ?>
            <a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ?: home_url( '/blog' ) ); ?>" class="np-load-more-link">
                <?php echo esc_html( $instance['load_more_text'] ); ?> &rsaquo;
            </a>
        <?php endif;
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $fields = array(
            'title'          => array( 'label' => __( 'Title', 'newspress' ),       'default' => __( 'Most Popular', 'newspress' ) ),
            'count'          => array( 'label' => __( 'Number of posts', 'newspress' ), 'default' => 5 ),
            'load_more_text' => array( 'label' => __( 'Load more link text (blank = hide)', 'newspress' ), 'default' => __( 'Load more', 'newspress' ) ),
        );
        foreach ( $fields as $key => $f ) {
            $val = $instance[ $key ] ?? $f['default'];
            printf(
                '<p><label for="%s">%s</label><input class="widefat" id="%s" name="%s" type="text" value="%s"></p>',
                esc_attr( $this->get_field_id( $key ) ),
                esc_html( $f['label'] ),
                esc_attr( $this->get_field_id( $key ) ),
                esc_attr( $this->get_field_name( $key ) ),
                esc_attr( $val )
            );
        }
        // Orderby select
        $orderby = $instance['orderby'] ?? 'comment_count';
        printf( '<p><label for="%s">%s</label><select class="widefat" id="%s" name="%s">',
            esc_attr( $this->get_field_id( 'orderby' ) ),
            esc_html__( 'Sort by', 'newspress' ),
            esc_attr( $this->get_field_id( 'orderby' ) ),
            esc_attr( $this->get_field_name( 'orderby' ) )
        );
        foreach ( array( 'comment_count' => __( 'Most Commented', 'newspress' ), 'date' => __( 'Most Recent', 'newspress' ) ) as $v => $l ) {
            printf( '<option value="%s"%s>%s</option>', esc_attr($v), selected($orderby, $v, false), esc_html($l) );
        }
        echo '</select></p>';
    }

    public function update( $new, $old ) {
        $new['title']          = sanitize_text_field( $new['title'] ?? '' );
        $new['count']          = absint( $new['count'] ?? 5 );
        $new['orderby']        = in_array( $new['orderby'] ?? '', array( 'comment_count', 'date' ) ) ? $new['orderby'] : 'comment_count';
        $new['load_more_text'] = sanitize_text_field( $new['load_more_text'] ?? '' );
        return $new;
    }
}

/* ============================================================
   3. POPULAR CATEGORIES WIDGET
   ============================================================ */
class NP_Popular_Cats_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'np_popular_cats', __( '🗂 Popular Categories', 'newspress' ), array(
            'description' => __( 'Lists categories with post counts.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title = apply_filters( 'widget_title', $instance['title'] ?? __( 'Popular Category', 'newspress' ) );
        $count = (int) ( $instance['count'] ?? 6 );
        $cats  = get_categories( array(
            'orderby'    => 'count',
            'order'      => 'DESC',
            'number'     => $count,
            'hide_empty' => true,
        ) );
        if ( empty( $cats ) ) return;

        echo $args['before_widget'];
        if ( $title ) echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        ?>
        <ul class="np-popular-cats">
        <?php foreach ( $cats as $cat ) : ?>
            <li>
                <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
                <span class="np-cat-count"><?php echo (int) $cat->count; ?></span>
            </li>
        <?php endforeach; ?>
        </ul>
        <?php
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $fields = array(
            'title' => array( 'label' => __( 'Title', 'newspress' ), 'default' => __( 'Popular Category', 'newspress' ) ),
            'count' => array( 'label' => __( 'Number of categories', 'newspress' ), 'default' => 6 ),
        );
        foreach ( $fields as $key => $f ) {
            $val = $instance[ $key ] ?? $f['default'];
            printf(
                '<p><label for="%s">%s</label><input class="widefat" id="%s" name="%s" type="text" value="%s"></p>',
                esc_attr( $this->get_field_id( $key ) ),
                esc_html( $f['label'] ),
                esc_attr( $this->get_field_id( $key ) ),
                esc_attr( $this->get_field_name( $key ) ),
                esc_attr( $val )
            );
        }
    }

    public function update( $new, $old ) {
        $new['title'] = sanitize_text_field( $new['title'] ?? '' );
        $new['count'] = absint( $new['count'] ?? 6 );
        return $new;
    }
}

/* ============================================================
   REGISTER ALL WIDGETS
   ============================================================ */
add_action( 'widgets_init', function() {
    register_widget( 'NP_Stay_Connected_Widget' );
    register_widget( 'NP_Popular_Posts_Widget' );
    register_widget( 'NP_Popular_Cats_Widget' );
} );

/* ============================================================
   4. ADVERTISEMENT WIDGET (with "- Advertisement -" label)
   ============================================================ */
class NP_Ad_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'np_ad_widget', __( '📢 Advertisement Block', 'newspress' ), array(
            'description' => __( 'Displays an ad image or code with an optional "Advertisement" label above it.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $show_label = ! empty( $instance['show_label'] );
        $ad_code    = $instance['ad_code'] ?? '';
        $ad_url     = $instance['ad_url']  ?? '';
        $ad_img     = $instance['ad_img']  ?? '';

        echo $args['before_widget'];
        if ( $show_label ) echo '<p class="np-ad-label">- ' . esc_html__( 'Advertisement', 'newspress' ) . ' -</p>';

        if ( $ad_code ) {
            echo '<div class="np-ad-wrap">' . do_shortcode( $ad_code ) . '</div>'; // phpcs:ignore
        } elseif ( $ad_img ) {
            echo '<div class="np-ad-wrap">';
            if ( $ad_url ) echo '<a href="' . esc_url( $ad_url ) . '" target="_blank" rel="noopener noreferrer nofollow">';
            echo '<img src="' . esc_url( $ad_img ) . '" alt="' . esc_attr__( 'Advertisement', 'newspress' ) . '" loading="lazy" style="max-width:100%;height:auto;display:block;margin:0 auto;">';
            if ( $ad_url ) echo '</a>';
            echo '</div>';
        }
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $fields = array(
            'ad_code'    => array( 'label' => __( 'Ad code / shortcode (paste AdSense or HTML)', 'newspress' ), 'default' => '' ),
            'ad_img'     => array( 'label' => __( 'Or: Image URL', 'newspress' ), 'default' => '' ),
            'ad_url'     => array( 'label' => __( 'Link URL (optional)', 'newspress' ), 'default' => '' ),
        );
        foreach ( $fields as $key => $f ) {
            $val = $instance[ $key ] ?? $f['default'];
            printf(
                '<p><label for="%s">%s</label><input class="widefat" id="%s" name="%s" type="text" value="%s"></p>',
                esc_attr( $this->get_field_id( $key ) ),
                esc_html( $f['label'] ),
                esc_attr( $this->get_field_id( $key ) ),
                esc_attr( $this->get_field_name( $key ) ),
                esc_attr( $val )
            );
        }
        $checked = ! empty( $instance['show_label'] ) ? 'checked' : '';
        printf(
            '<p><label><input type="checkbox" id="%s" name="%s" value="1" %s> %s</label></p>',
            esc_attr( $this->get_field_id( 'show_label' ) ),
            esc_attr( $this->get_field_name( 'show_label' ) ),
            $checked,
            esc_html__( 'Show "- Advertisement -" label', 'newspress' )
        );
    }

    public function update( $new, $old ) {
        $new['ad_code']    = wp_kses_post( $new['ad_code'] ?? '' );
        $new['ad_img']     = esc_url_raw( $new['ad_img'] ?? '' );
        $new['ad_url']     = esc_url_raw( $new['ad_url'] ?? '' );
        $new['show_label'] = ! empty( $new['show_label'] ) ? 1 : 0;
        return $new;
    }
}

add_action( 'widgets_init', function() {
    register_widget( 'NP_Ad_Widget' );
} );


/* ============================================================
   5. FOOTER ABOUT US WIDGET
   ============================================================ */
class NP_Footer_About_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'np_footer_about', __( '🦶 Footer: About Us', 'newspress' ), array(
            'description' => __( 'Footer about column: logo, description, contact email, social icons.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title       = $instance['title']       ?? get_bloginfo( 'name' );
        $logo        = $instance['logo']        ?? '';
        $about       = $instance['about']       ?? '';
        $contact_lbl = $instance['contact_lbl'] ?? __( 'Contact us:', 'newspress' );
        $contact_val = $instance['contact_val'] ?? get_option( 'admin_email' );

        echo $args['before_widget'];

        // Logo or text
        echo '<div class="np-footer-logo-col">';
        if ( $logo ) {
            echo '<a href="' . esc_url( home_url('/') ) . '"><img src="' . esc_url($logo) . '" alt="' . esc_attr($title) . '" loading="lazy" style="max-height:50px;width:auto;"></a>';
        } else {
            echo '<a href="' . esc_url( home_url('/') ) . '" class="np-footer-logo-text">' . esc_html($title) . '</a>';
        }
        echo '</div>';

        if ( $about ) echo '<p class="np-footer-about">' . esc_html($about) . '</p>';
        if ( $contact_val ) {
            echo '<p class="np-footer-contact">' . esc_html($contact_lbl) . ' <a href="mailto:' . esc_attr($contact_val) . '">' . esc_html($contact_val) . '</a></p>';
        }
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $fields = array(
            'title'       => array( 'label' => __( 'Site name (fallback if no logo)', 'newspress' ), 'default' => get_bloginfo('name') ),
            'logo'        => array( 'label' => __( 'Logo image URL (leave blank to use site name)', 'newspress' ), 'default' => '' ),
            'about'       => array( 'label' => __( 'About text', 'newspress' ), 'default' => '' ),
            'contact_lbl' => array( 'label' => __( 'Contact label', 'newspress' ), 'default' => __( 'Contact us:', 'newspress' ) ),
            'contact_val' => array( 'label' => __( 'Contact email / text', 'newspress' ), 'default' => get_option('admin_email') ),
        );
        foreach ( $fields as $key => $f ) {
            $val = $instance[ $key ] ?? $f['default'];
            printf(
                '<p><label for="%s">%s</label><input class="widefat" id="%s" name="%s" type="text" value="%s"></p>',
                esc_attr( $this->get_field_id( $key ) ), esc_html( $f['label'] ),
                esc_attr( $this->get_field_id( $key ) ), esc_attr( $this->get_field_name( $key ) ),
                esc_attr( $val )
            );
        }
    }

    public function update( $new, $old ) {
        foreach ( array('title','contact_lbl','contact_val') as $k ) $new[$k] = sanitize_text_field( $new[$k] ?? '' );
        $new['logo']  = esc_url_raw( $new['logo']  ?? '' );
        $new['about'] = sanitize_textarea_field( $new['about'] ?? '' );
        return $new;
    }
}

/* ============================================================
   6. FOOTER FOLLOW US WIDGET (social icon buttons)
   ============================================================ */
class NP_Footer_Follow_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'np_footer_follow', __( '🦶 Footer: Follow Us', 'newspress' ), array(
            'description' => __( 'Footer social icon links block.', 'newspress' ),
        ) );
    }

    public function widget( $args, $instance ) {
        $title = apply_filters( 'widget_title', $instance['title'] ?? __( 'Follow Us', 'newspress' ) );
        $networks = array(
            'fb' => array( 'class' => 'np-fsi-fb', 'label' => 'Facebook',  'svg' => '<svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>' ),
            'ig' => array( 'class' => 'np-fsi-ig', 'label' => 'Instagram', 'svg' => '<svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/></svg>' ),
            'vk' => array( 'class' => 'np-fsi-vk', 'label' => 'VK',        'svg' => '<svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93v6.14C2 20.67 3.33 22 8.93 22h6.14C20.67 22 22 20.67 22 15.07V8.93C22 3.33 20.67 2 15.07 2zm3.08 13.03h-1.56c-.59 0-.77-.47-1.83-1.54-.92-.9-1.32-.9-1.55-.9-.31 0-.4.09-.4.52v1.4c0 .37-.12.59-1.1.59-1.62 0-3.41-.98-4.67-2.8C5.77 10.05 5.33 7.87 5.33 7.4c0-.24.09-.46.52-.46h1.56c.39 0 .54.18.69.6.76 2.19 2.03 4.11 2.55 4.11.2 0 .29-.09.29-.58V9.16c-.06-1.04-.61-1.13-.61-1.5 0-.18.15-.37.39-.37h2.45c.33 0 .44.17.44.55v2.95c0 .33.15.44.24.44.2 0 .36-.11.72-.47 1.11-1.25 1.9-3.17 1.9-3.17.11-.24.29-.46.68-.46h1.56c.47 0 .57.24.47.55-.2.92-2.13 3.65-2.13 3.65-.17.27-.23.39 0 .69.17.23.72.71 1.09 1.14.68.76 1.2 1.4 1.34 1.84.15.43-.08.65-.51.65z"/></svg>' ),
        );

        echo $args['before_widget'];
        if ( $title ) echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        echo '<div class="np-footer-social-icons">';
        foreach ( $networks as $key => $net ) {
            $url = $instance[ $key . '_url' ] ?? '';
            if ( $url ) {
                echo '<a href="' . esc_url($url) . '" class="' . esc_attr($net['class']) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr($net['label']) . '">' . $net['svg'] . '</a>'; // phpcs:ignore
            }
        }
        echo '</div>';
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = $instance['title'] ?? __( 'Follow Us', 'newspress' );
        printf( '<p><label for="%s">%s</label><input class="widefat" id="%s" name="%s" type="text" value="%s"></p>',
            esc_attr($this->get_field_id('title')), esc_html__('Title','newspress'),
            esc_attr($this->get_field_id('title')), esc_attr($this->get_field_name('title')), esc_attr($title)
        );
        foreach ( array( 'fb' => 'Facebook URL', 'ig' => 'Instagram URL', 'vk' => 'VK URL' ) as $k => $lbl ) {
            $val = $instance[ $k . '_url' ] ?? '';
            printf( '<p><label for="%s">%s</label><input class="widefat" id="%s" name="%s" type="text" value="%s"></p>',
                esc_attr($this->get_field_id($k.'_url')), esc_html($lbl),
                esc_attr($this->get_field_id($k.'_url')), esc_attr($this->get_field_name($k.'_url')), esc_attr($val)
            );
        }
    }

    public function update( $new, $old ) {
        $new['title']  = sanitize_text_field( $new['title'] ?? '' );
        foreach ( array('fb','ig','vk') as $k ) $new[$k.'_url'] = esc_url_raw( $new[$k.'_url'] ?? '' );
        return $new;
    }
}

add_action( 'widgets_init', function() {
    register_widget( 'NP_Footer_About_Widget' );
    register_widget( 'NP_Footer_Follow_Widget' );
} );
