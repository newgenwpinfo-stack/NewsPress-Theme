<?php
/**
 * Single Post Template
 *
 * Layout controlled by:
 *  np_single_sidebar  — right | left | none
 *  np_single_width    — normal | narrow | wide
 *  np_single_image_style — full | inset | banner
 *
 * @package NewsPress
 */

get_header();

$image_style  = get_theme_mod( 'np_single_image_style', 'full' );
$show_caption = get_theme_mod( 'np_single_show_caption', true );
$show_updated = get_theme_mod( 'np_show_updated_date', false );
$date_format  = get_theme_mod( 'np_date_format', 'M j, Y' );

// Banner-style: full-width hero image above the container
if ( $image_style === 'banner' && has_post_thumbnail() && get_theme_mod( 'np_single_show_featured', true ) ) :
    the_post_thumbnail( 'newspress-wide', array( 'class' => 'np-banner-hero-img', 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => esc_attr( get_the_title() ) ) );
endif;
?>
<div class="np-container">
    <?php newspress_breadcrumbs(); ?>

    <div class="<?php echo esc_attr( newspress_single_content_class() ); ?>">
        <article id="post-<?php the_ID(); ?>" <?php post_class( 'np-single-article' ); ?>>

            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

            <header class="np-single-header">
                <?php if ( get_theme_mod( 'np_show_cats', true ) ) newspress_category_badge(); ?>

                <h1 class="np-single-title"><?php the_title(); ?></h1>

                <div class="np-single-meta">
                    <?php if ( get_theme_mod( 'np_show_author', true ) ) : ?>
                    <div class="np-meta-author">
                        <?php echo get_avatar( get_the_author_meta( 'ID' ), 32, '', '', array( 'class' => 'np-author-avatar' ) ); ?>
                        <span><?php esc_html_e( 'By', 'newspress' ); ?>
                            <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
                        </span>
                    </div>
                    <?php endif; ?>

                    <?php if ( get_theme_mod( 'np_show_date', true ) ) : ?>
                    <time class="np-meta-date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
                        <?php echo esc_html( get_the_date( $date_format ) ); ?>
                    </time>
                    <?php endif; ?>

                    <?php if ( $show_updated ) :
                        $updated = get_the_modified_date( $date_format );
                        if ( $updated !== get_the_date( $date_format ) ) : ?>
                        <span class="np-meta-updated">
                            <?php esc_html_e( 'Updated:', 'newspress' ); ?>
                            <?php echo esc_html( $updated ); ?>
                        </span>
                        <?php endif;
                    endif; ?>

                    <?php if ( get_theme_mod( 'np_show_reading_time', true ) ) : ?>
                        <span class="np-reading-time">&#9201; <?php echo esc_html( newspress_reading_time() ); ?></span>
                    <?php endif; ?>

                </div>
            </header>

            <?php
            // Featured image — not banner (already rendered above)
            if ( $image_style !== 'banner' && has_post_thumbnail() && get_theme_mod( 'np_single_show_featured', true ) ) :
                $img_class = 'np-featured-image np-featured-' . esc_attr( $image_style );
            ?>
            <figure class="<?php echo esc_attr( $img_class ); ?>">
                <?php the_post_thumbnail( 'newspress-wide', array(
                    'loading'       => 'eager',
                    'fetchpriority' => 'high',
                    'alt'           => esc_attr( get_the_title() ),
                ) ); ?>
                <?php if ( $show_caption ) :
                    $caption = wp_get_attachment_caption( get_post_thumbnail_id() );
                    if ( $caption ) : ?><figcaption><?php echo esc_html( $caption ); ?></figcaption><?php endif;
                endif; ?>
            </figure>
            <?php endif; ?>

            <!-- Share buttons: above content position -->
            <?php
            $share_pos = get_theme_mod( 'np_share_position', 'bottom' );
            if ( in_array( $share_pos, array( 'top', 'both' ), true ) ) {
                newspress_share_buttons();
            }
            ?>

            <div class="np-entry-content">
                <?php the_content( sprintf( esc_html__( 'Continue reading %s', 'newspress' ), '<span class="screen-reader-text">' . get_the_title() . '</span>' ) ); ?>
                <?php wp_link_pages( array( 'before' => '<div class="np-page-links">' . esc_html__( 'Pages:', 'newspress' ), 'after' => '</div>' ) ); ?>
            </div>

            <?php if ( get_theme_mod( 'np_show_tags', true ) ) newspress_post_tags(); ?>

            <!-- Share buttons: below content / both -->
            <?php if ( in_array( $share_pos, array( 'bottom', 'both' ), true ) ) newspress_share_buttons(); ?>

            <?php newspress_author_box(); ?>

            <?php endwhile; endif; ?>

            <!-- Prev / Next navigation -->
            <?php
            $prev = get_previous_post();
            $next = get_next_post();
            if ( $prev || $next ) :
            ?>
            <nav class="np-post-nav" aria-label="<?php esc_attr_e( 'Post navigation', 'newspress' ); ?>">
                <div class="np-post-nav-item np-prev">
                    <?php if ( $prev ) : ?>
                    <span class="np-post-nav-label">&#8592; <?php esc_html_e( 'Previous article', 'newspress' ); ?></span>
                    <a href="<?php echo esc_url( get_permalink( $prev ) ); ?>" class="np-post-nav-title"><?php echo esc_html( get_the_title( $prev ) ); ?></a>
                    <?php endif; ?>
                </div>
                <div class="np-post-nav-item np-next">
                    <?php if ( $next ) : ?>
                    <span class="np-post-nav-label"><?php esc_html_e( 'Next article', 'newspress' ); ?> &#8594;</span>
                    <a href="<?php echo esc_url( get_permalink( $next ) ); ?>" class="np-post-nav-title"><?php echo esc_html( get_the_title( $next ) ); ?></a>
                    <?php endif; ?>
                </div>
            </nav>
            <?php endif; ?>

            <!-- Related Posts -->
            <?php
            $related_count = (int) get_theme_mod( 'np_related_count', 3 );
            newspress_related_posts( $related_count );
            ?>

            <!-- Comments -->
            <?php if ( comments_open() || get_comments_number() ) : ?>
            <div class="np-comments-area">
                <?php comments_template(); ?>
            </div>
            <?php endif; ?>

        </article>

        <?php if ( newspress_single_show_sidebar() ) : ?>
        <aside id="np-sidebar" class="np-sidebar" role="complementary" aria-label="<?php esc_attr_e( 'Sidebar', 'newspress' ); ?>">
            <?php
            // Use single-specific sidebar if registered, fallback to main sidebar
            if ( is_active_sidebar( 'sidebar-single' ) ) {
                dynamic_sidebar( 'sidebar-single' );
            } else {
                dynamic_sidebar( 'sidebar-1' );
            }
            ?>
        </aside>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
