<?php
/**
 * Search Results Template
 *
 * @package NewsPress
 */

get_header();
?>
<div class="np-container">
    <?php newspress_breadcrumbs(); ?>

    <div class="<?php echo esc_attr( newspress_content_class() ); ?>">
        <div class="np-main">
            <header class="np-search-header">
                <h1 class="np-page-title">
                    <?php if ( have_posts() ) :
                        printf( esc_html__('Search results for: %s','newspress'), '<span>' . get_search_query() . '</span>');
                    else :
                        esc_html_e('Nothing Found','newspress');
                    endif; ?>
                </h1>
            </header>

            <?php if ( ! have_posts() ) : ?>
                <p><?php esc_html_e('Try different keywords.','newspress'); ?></p>
                <?php get_search_form(); ?>
            <?php else : ?>
            <div class="<?php echo esc_attr( newspress_grid_class() ); ?>">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php get_template_part('template-parts/content/card','grid'); ?>
                <?php endwhile; ?>
            </div>
            <?php newspress_pagination(); ?>
            <?php endif; ?>
        </div>

        <?php if ( newspress_show_sidebar() ) : ?>
        <aside class="np-sidebar" role="complementary"><?php dynamic_sidebar('sidebar-1'); ?></aside>
        <?php endif; ?>
    </div>
</div>
<?php get_footer(); ?>
