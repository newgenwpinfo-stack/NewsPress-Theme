<?php
/**
 * Page Template
 *
 * @package NewsPress
 */

get_header();
?>
<div class="np-container">
    <?php newspress_breadcrumbs(); ?>
    <div class="<?php echo esc_attr( newspress_content_class() ); ?>">
        <div class="np-main">
            <?php while ( have_posts() ) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="np-page-header">
                    <h1 class="np-page-title"><?php the_title(); ?></h1>
                </header>
                <?php if ( has_post_thumbnail() ) : ?>
                <div class="np-featured-image"><?php the_post_thumbnail('newspress-wide'); ?></div>
                <?php endif; ?>
                <div class="np-entry-content"><?php the_content(); ?></div>
            </article>
            <?php if ( comments_open() || get_comments_number() ) comments_template(); ?>
            <?php endwhile; ?>
        </div>
        <?php if ( newspress_show_sidebar() ) : ?>
        <aside class="np-sidebar" role="complementary"><?php dynamic_sidebar('sidebar-1'); ?></aside>
        <?php endif; ?>
    </div>
</div>
<?php get_footer(); ?>
