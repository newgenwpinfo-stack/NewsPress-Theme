<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
/**
 * Measure the scrollbar width and store as a CSS custom property.
 * Used by body.np-menu-open to prevent layout shift when scroll is locked.
 * Runs inline (synchronous) so the value is available before first paint.
 */
?>
<script>!function(){var s=document.documentElement,w=window.innerWidth-s.clientWidth;if(w>0)s.style.setProperty('--np-scrollbar-width',w+'px')}()</script>
<?php
/**
 * Output a <link rel="preload"> for the theme stylesheet BEFORE wp_head().
 * This tells the browser to start fetching the CSS file immediately,
 * even though it will be delivered as async by the style_loader_tag filter.
 */
$np_style_url = esc_url( get_stylesheet_uri() . '?ver=' . NEWSPRESS_VERSION );
echo '<link rel="preload" href="' . $np_style_url . '" as="style">' . "\n";
?>
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<script>
/* Dark/Light mode — manual only, deterministic, no OS/browser detection.
 * No saved preference => stays Light (server-rendered default).
 * Saved 'np-dark' = '1' => Dark. Saved '0' => Light (overrides any admin
 * default). Runs synchronously as the first thing after <body> opens so
 * there is no visible flash for returning visitors. */
(function(){
    try {
        var v = window.localStorage ? localStorage.getItem('np-dark') : null;
        if (v === '1') { document.body.classList.add('np-dark-mode'); }
        else if (v === '0') { document.body.classList.remove('np-dark-mode'); }
    } catch (e) {}
})();
</script>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#np-primary"><?php esc_html_e( 'Skip to content', 'newspress' ); ?></a>

<?php if ( get_theme_mod( 'np_show_progress_bar', true ) && is_singular('post') ) : ?>
<div id="np-read-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-label="<?php esc_attr_e('Reading progress','newspress'); ?>"></div>
<?php endif; ?>

<?php if ( is_active_sidebar( 'above-header' ) ) : ?>
<div class="np-above-header"><div class="np-container"><?php dynamic_sidebar( 'above-header' ); ?></div></div>
<?php endif; ?>

<!-- ========== TOP BAR ========== -->
<?php if ( get_theme_mod( 'np_show_topbar', true ) ) : ?>
<div class="np-topbar" role="banner">
    <div class="np-container">
        <div class="np-breaking-news">
            <?php
            $breaking_label = get_theme_mod( 'np_breaking_label', get_theme_mod( 'np_topbar_text', __('Breaking News','newspress') ) );
            echo '<span class="np-breaking-label">' . esc_html( $breaking_label ) . '</span>';
            $breaking_ids = newspress_get_breaking_news(8);
            if ( $breaking_ids ) :
            ?>
            <div class="np-breaking-ticker" aria-live="polite" aria-label="<?php esc_attr_e('Breaking news ticker','newspress'); ?>">
                <div class="np-breaking-ticker-inner">
                    <?php
                    // First set of links
                    foreach ( $breaking_ids as $pid ) :
                        echo '<a href="' . esc_url( get_permalink($pid) ) . '">' . esc_html( get_the_title($pid) ) . '</a>';
                        echo '<span aria-hidden="true" style="opacity:.4;padding:0 .25rem;">|</span>';
                    endforeach;
                    // Duplicate for seamless loop (CSS animates to -50%)
                    foreach ( $breaking_ids as $pid ) :
                        echo '<a href="' . esc_url( get_permalink($pid) ) . '" aria-hidden="true" tabindex="-1">' . esc_html( get_the_title($pid) ) . '</a>';
                        echo '<span aria-hidden="true" style="opacity:.4;padding:0 .25rem;">|</span>';
                    endforeach;
                    ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="np-topbar-right">
            <?php if ( get_theme_mod( 'np_topbar_date', true ) ) : ?>
                <span class="np-topbar-date"><?php echo esc_html( date_i18n( get_option('date_format') ) ); ?></span>
            <?php endif; ?>

            <?php if ( has_nav_menu( 'topbar' ) ) : ?>
                <?php wp_nav_menu( [
                    'theme_location' => 'topbar',
                    'menu_class'     => 'np-topbar-menu',
                    'container'      => false,
                    'depth'          => 1,
                    'fallback_cb'    => false,
                ] ); ?>
            <?php endif; ?>

            <div class="np-social-links">
                <?php
                $socials = [
                    'np_social_facebook'  => [ 'Facebook',  'fb'  ],
                    'np_social_twitter'   => [ 'Twitter/X', 'tw'  ],
                    'np_social_instagram' => [ 'Instagram', 'ig'  ],
                    'np_social_youtube'   => [ 'YouTube',   'yt'  ],
                    'np_social_linkedin'  => [ 'LinkedIn',  'li'  ],
                    'np_social_tiktok'    => [ 'TikTok',    'tk'  ],
                    'np_social_rss'       => [ 'RSS',       'rss' ],
                ];
                foreach ( $socials as $mod => $info ) :
                    $url = get_theme_mod( $mod, '' );
                    if ( $url ) :
                ?>
                    <a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $info[0] ); ?>" class="np-social-<?php echo esc_attr( $info[1] ); ?>"><?php echo newspress_social_icon( $info[1] ); ?></a>
                <?php endif; endforeach; ?>
            </div>

            <?php if ( get_theme_mod( 'np_dark_mode_toggle', true ) ) : ?>
                <button type="button"
                        id="np-dark-toggle"
                        class="np-theme-toggle"
                        aria-pressed="false"
                        aria-label="<?php esc_attr_e( 'Switch to Night mode', 'newspress' ); ?>">
                    <span class="np-theme-toggle-icon" aria-hidden="true">☾</span>
                    <span class="np-theme-toggle-text"><?php esc_html_e( 'Night', 'newspress' ); ?></span>
                </button>
                <script>
                /* Sets the button's label/icon/aria-pressed to match the
                 * already-resolved body state (see the bootstrap script
                 * right after <body>) before the page finishes parsing —
                 * avoids a visible label flash for returning dark-mode
                 * visitors. Click handling lives in js/main.js (deferred). */
                (function(){
                    try {
                        var btn = document.getElementById('np-dark-toggle');
                        if (!btn) return;
                        var icon = btn.querySelector('.np-theme-toggle-icon');
                        var text = btn.querySelector('.np-theme-toggle-text');
                        var L = {
                            night:   <?php echo wp_json_encode( __( 'Night', 'newspress' ) ); ?>,
                            day:     <?php echo wp_json_encode( __( 'Day', 'newspress' ) ); ?>,
                            toNight: <?php echo wp_json_encode( __( 'Switch to Night mode', 'newspress' ) ); ?>,
                            toDay:   <?php echo wp_json_encode( __( 'Switch to Day mode', 'newspress' ) ); ?>
                        };
                        function render(dark) {
                            btn.setAttribute('aria-pressed', dark ? 'true' : 'false');
                            btn.setAttribute('aria-label', dark ? L.toDay : L.toNight);
                            if (icon) icon.textContent = dark ? '\u2600' : '\u263e';
                            if (text) text.textContent = dark ? L.day : L.night;
                        }
                        window.NPThemeToggle = { render: render };
                        render( document.body.classList.contains('np-dark-mode') );
                    } catch (e) {}
                })();
                </script>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ========== HEADER ========== -->
<?php do_action( 'newspress_before_header' ); ?>
<?php
$header_style = get_theme_mod( 'np_header_style', 'classic' );
$sticky_class = get_theme_mod( 'np_sticky_header', true ) ? 'np-sticky' : '';
?>
<header id="np-masthead" class="np-site-header <?php echo esc_attr($sticky_class . ' np-header-' . $header_style); ?>" role="banner">
    <div class="np-container">
        <div class="np-header-inner np-header-<?php echo esc_attr($header_style); ?>">
            <!-- Branding -->
            <div class="np-site-branding">
                <?php if ( has_custom_logo() ) : ?>
                    <div class="np-site-logo"><?php the_custom_logo(); ?></div>
                <?php endif; ?>

                <?php if ( ! has_custom_logo() || get_theme_mod('np_header_style','classic') !== 'minimal' ) : ?>
                <div class="np-site-name">
                    <?php if ( get_theme_mod( 'np_show_site_title', true ) ) : ?>
                        <?php if ( is_front_page() && is_home() ) : ?>
                            <h1 class="np-site-title"><a href="<?php echo esc_url( home_url('/') ); ?>" rel="home"><?php bloginfo('name'); ?></a></h1>
                        <?php else : ?>
                            <p class="np-site-title"><a href="<?php echo esc_url( home_url('/') ); ?>" rel="home"><?php bloginfo('name'); ?></a></p>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if ( get_theme_mod( 'np_show_tagline', true ) ) : ?>
                        <?php $tagline = get_bloginfo('description'); if ($tagline) : ?>
                            <p class="np-site-tagline"><?php echo esc_html($tagline); ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <?php
            // ── Header Ad Zone ──────────────────────────────────────────
            $np_ad_enable  = get_theme_mod( 'np_header_ad_enable', false );
            $np_ad_code    = trim( get_theme_mod( 'np_header_ad_code', '' ) );
            $np_ad_w       = absint( get_theme_mod( 'np_header_ad_width',  728 ) );
            $np_ad_h       = absint( get_theme_mod( 'np_header_ad_height',  90 ) );
            $np_ad_align   = get_theme_mod( 'np_header_ad_align', 'center' );

            if ( $np_ad_enable ) :
                $np_ad_style = 'display:flex;justify-content:' . esc_attr( $np_ad_align ) . ';align-items:center;width:100%;';
                $np_slot_style = 'width:' . $np_ad_w . 'px;max-width:100%;height:' . $np_ad_h . 'px;overflow:hidden;';
            ?>
            <div class="np-header-ad" style="<?php echo $np_ad_style; ?>">
                <div class="np-ad-slot" style="<?php echo $np_slot_style; ?>">
                    <?php if ( $np_ad_code ) : ?>
                        <?php echo $np_ad_code; // Ad code — admin-entered, not escaped ?>
                    <?php elseif ( is_active_sidebar( 'above-header' ) ) : ?>
                        <?php dynamic_sidebar( 'above-header' ); ?>
                    <?php elseif ( current_user_can( 'manage_options' ) ) : ?>
                        <div style="width:100%;height:100%;background:#f0f0f0;border:2px dashed #ccc;display:flex;align-items:center;justify-content:center;font-size:12px;color:#999;font-family:monospace;">
                            Ad <?php echo $np_ad_w; ?>×<?php echo $np_ad_h; ?> — add code in Customizer → Header Ad
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Search -->
            <?php if ( get_theme_mod( 'np_show_search', true ) ) : ?>
            <div class="np-header-search">
                <form role="search" method="get" action="<?php echo esc_url( home_url('/') ); ?>" aria-label="<?php esc_attr_e('Site search','newspress'); ?>">
                    <input type="search" name="s" placeholder="<?php echo esc_attr( get_theme_mod( 'np_search_placeholder', __( 'Search news…', 'newspress' ) ) ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" aria-label="<?php esc_attr_e('Search','newspress'); ?>">
                    <button type="submit" aria-label="<?php esc_attr_e('Search','newspress'); ?>">&#128269;</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
</header>

<!-- ========== PRIMARY NAV ========== -->
<nav class="np-main-nav" id="np-navigation" aria-label="<?php esc_attr_e('Primary Navigation','newspress'); ?>">
    <div class="np-container">
        <button class="np-menu-toggle"
                aria-controls="np-primary-menu"
                aria-expanded="false"
                aria-label="<?php esc_attr_e('Open navigation menu','newspress'); ?>"
                data-label="<?php esc_attr_e('Menu','newspress'); ?>">
            <?php /* Icon and label injected by nav.js after DOM ready */ ?>
            <span class="np-toggle-icon" aria-hidden="true">&#9776;</span>
            <span class="np-toggle-label"><?php esc_html_e('Menu','newspress'); ?></span>
        </button>

        <?php wp_nav_menu( [
            'theme_location' => 'primary',
            'menu_id'        => 'np-primary-menu',
            'menu_class'     => 'np-nav-menu',
            'container'      => false,
            'walker'         => new NewsPress_Nav_Walker(),
            'fallback_cb'    => function() {
                echo '<ul class="np-nav-menu" id="np-primary-menu"><li><a href="' . esc_url(admin_url('nav-menus.php')) . '">' . esc_html__('Set up Primary Menu','newspress') . '</a></li></ul>';
            },
            'items_wrap'     => '<ul id="%1$s" class="%2$s" role="list">'
                                . '<li class="np-menu-close-item" role="none">'
                                . '<button class="np-menu-close" aria-label="' . esc_attr__('Close navigation menu','newspress') . '" onclick="this.closest(\'#np-primary-menu\').classList.remove(\'np-open\');document.querySelector(\'.np-menu-toggle\').setAttribute(\'aria-expanded\',\'false\');document.body.classList.remove(\'np-menu-open\');">'
                                . '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>'
                                . '<span class="screen-reader-text">' . esc_html__('Close menu','newspress') . '</span>'
                                . '</button>'
                                . '</li>'
                                . '%3$s</ul>',
        ] ); ?>
    </div>
</nav>

<!-- ========== SECONDARY NAV ========== -->
<?php if ( get_theme_mod( 'np_show_secondary_nav', true ) && has_nav_menu('secondary') ) : ?>
<nav class="np-secondary-nav" aria-label="<?php esc_attr_e('Categories','newspress'); ?>">
    <div class="np-container">
        <?php wp_nav_menu( [
            'theme_location' => 'secondary',
            'container'      => false,
            'menu_class'     => '',
            'depth'          => 1,
            'fallback_cb'    => false,
        ] ); ?>
    </div>
</nav>
<?php endif; ?>

<?php if ( is_active_sidebar('below-header') ) : ?>
<div class="np-below-header"><div class="np-container"><?php dynamic_sidebar('below-header'); ?></div></div>
<?php endif; ?>

<!-- ========== MAIN WRAPPER ========== -->
<div id="np-page" class="np-page-wrapper">
<main id="np-primary" class="np-main-content" role="main">
