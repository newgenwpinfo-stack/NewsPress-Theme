<?php
/**
 * Main Index / Homepage Template
 *
 * Layout driven by the Homepage Builder (Customizer → Homepage → Sections).
 * Each section is an independent category block with its own layout, count, and style.
 * The hero section and breaking ticker are rendered separately above the builder.
 *
 * @package NewsPress
 */

get_header();

$nav_style = get_theme_mod( 'np_nav_style', 'pagination' );
$per_page  = absint( get_theme_mod( 'np_home_posts_count', 9 ) ) ?: 9;
$paged     = max( 1, get_query_var( 'paged' ) );

// Main query — only used for pagination; builder sections have their own queries
$main_query = new WP_Query( array(
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'posts_per_page' => $per_page,
    'paged'          => $paged,
    'no_found_rows'  => ( $nav_style !== 'pagination' ),
) );
// Make available to template-functions so default section reuses it
$GLOBALS['np_main_query'] = $main_query;
?>
<div class="np-container">

    <!-- BREAKING NEWS TICKER -->
    <?php if ( get_theme_mod( 'np_show_breaking', true ) ) :
        $breaking_ids = newspress_get_breaking_news( 12 );
        if ( $breaking_ids ) : ?>
    <div class="np-scroll-ticker" aria-label="<?php esc_attr_e( 'Breaking news ticker', 'newspress' ); ?>">
        <span class="np-scroll-ticker-label"><?php echo esc_html( get_theme_mod( 'np_breaking_label', 'Latest' ) ); ?></span>
        <div class="np-scroll-ticker-track" aria-hidden="true">
            <div class="np-scroll-ticker-inner" id="np-ticker">
                <?php foreach ( array_merge( $breaking_ids, $breaking_ids ) as $pid ) : ?>
                    <a href="<?php echo esc_url( get_permalink( $pid ) ); ?>"><?php echo esc_html( get_the_title( $pid ) ); ?></a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; endif; ?>

    <!-- AD SLOT: Below ticker -->
    <?php if ( is_active_sidebar( 'before-content' ) ) : ?>
        <div class="np-ad-area"><?php dynamic_sidebar( 'before-content' ); ?></div>
    <?php endif; ?>

    <!-- HERO SECTION -->
    <?php newspress_render_hero(); ?>

    <!-- MAIN CONTENT + SIDEBAR -->
    <div class="<?php echo esc_attr( newspress_content_class() ); ?>">
        <div class="np-main">

            <?php
            // ── Homepage Builder ──────────────────────────────────────────
            // Always renders via the builder. Each section has its own query.
            // Pagination is shown after the builder when the default "latest"
            // section is active (i.e. no custom JSON sections configured).
            $sections      = newspress_get_home_sections();
            $has_custom    = ( get_theme_mod( 'np_home_sections', '' ) !== '' );
            $layout        = get_theme_mod( 'np_home_posts_layout', 'grid-3' );

            newspress_render_homepage_builder();

            // Show pagination only for the default "latest posts" section
            // (custom builder sections control their own counts per block)
            if ( ! $has_custom ) :
                if ( $nav_style === 'loadmore' && $main_query->max_num_pages > 1 ) : ?>
                    <div class="np-load-more-wrap">
                        <button id="np-load-more" class="np-btn"
                            data-page="2"
                            data-layout="<?php echo esc_attr( $layout ); ?>"
                            data-max="<?php echo esc_attr( $main_query->max_num_pages ); ?>">
                            <?php esc_html_e( 'Load More Stories', 'newspress' ); ?>
                        </button>
                    </div>
                <?php else :
                    newspress_pagination( $main_query );
                endif;
            endif; ?>

        </div><!-- .np-main -->

        <?php if ( newspress_show_sidebar() ) : ?>
        <aside id="np-sidebar" class="np-sidebar<?php echo get_theme_mod( 'np_sticky_sidebar', false ) ? ' np-sticky' : ''; ?>" role="complementary" aria-label="<?php esc_attr_e( 'Sidebar', 'newspress' ); ?>">
            <?php
            if ( is_active_sidebar( 'sidebar-home' ) ) {
                dynamic_sidebar( 'sidebar-home' );
            } else {
                dynamic_sidebar( 'sidebar-1' );
            }
            ?>
        </aside>
        <?php endif; ?>
    </div><!-- .np-site-content -->

    <?php if ( is_active_sidebar( 'after-content' ) ) : ?>
        <div class="np-after-content"><?php dynamic_sidebar( 'after-content' ); ?></div>
    <?php endif; ?>

</div><!-- .np-container -->

<?php get_footer(); ?>
