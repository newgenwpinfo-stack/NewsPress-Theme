<?php
/**
 * Footer Template
 *
 * @package NewsPress
 */
?>

</main><!-- #np-primary -->
</div><!-- #np-page -->

<?php do_action( 'newspress_before_footer' ); ?>
<!-- ========== FOOTER ========== -->
<footer id="np-colophon" class="np-footer" role="contentinfo">
    <div class="np-footer-top">
        <div class="np-container">
            <?php
            $cols        = (int) get_theme_mod( 'np_footer_cols', '4' );
            $col_class   = 'np-footer-widgets np-footer-cols-' . $cols;
            $active_cols = 0;

            for ( $i = 1; $i <= 4; $i++ ) {
                if ( is_active_sidebar( 'footer-widget-' . $i ) ) $active_cols++;
            }
            ?>
            <div class="<?php echo esc_attr( $col_class ); ?>">
                <?php for ( $i = 1; $i <= 4; $i++ ) : ?>
                    <?php if ( is_active_sidebar( 'footer-widget-' . $i ) ) : ?>
                        <div class="np-footer-widget">
                            <?php dynamic_sidebar( 'footer-widget-' . $i ); ?>
                        </div>
                    <?php endif; ?>
                <?php endfor; ?>
            </div>
        </div>
    </div>

    <?php
    /* ── Footer second row: Logo + About Us + Follow Us ── */
    $show_footer_info = get_theme_mod( 'np_footer_show_info', true );
    if ( $show_footer_info ) :
        $about_text    = get_theme_mod( 'np_footer_about_text', '' );
        $contact_email = get_theme_mod( 'np_footer_contact_email', '' );
        $contact_label = get_theme_mod( 'np_footer_contact_label', __( 'Contact us:', 'newspress' ) );
        $show_follow   = get_theme_mod( 'np_footer_show_follow', true );
    ?>
    <div class="np-footer-info-row">
        <div class="np-container">
            <div class="np-footer-info-cols">
                <div class="np-footer-logo-col">
                    <?php if ( has_custom_logo() ) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="np-footer-logo-text"><?php bloginfo( 'name' ); ?></a>
                    <?php endif; ?>
                    <?php if ( $about_text ) : ?>
                        <p class="np-footer-about"><?php echo wp_kses_post( $about_text ); ?></p>
                    <?php endif; ?>
                    <?php if ( $contact_email ) : ?>
                        <p class="np-footer-contact"><?php echo esc_html( $contact_label ); ?> <a href="mailto:<?php echo esc_attr( $contact_email ); ?>"><?php echo esc_html( $contact_email ); ?></a></p>
                    <?php endif; ?>
                </div>
                <?php if ( $show_follow ) : ?>
                <div class="np-footer-follow-col">
                    <h4 class="np-footer-col-title"><?php esc_html_e( 'Follow Us', 'newspress' ); ?></h4>
                    <div class="np-footer-social-icons">
                        <?php
                        $follow_links = array(
                            'np_social_facebook'  => array( 'class' => 'np-fsi-fb',  'label' => 'Facebook',  'letter' => 'f' ),
                            'np_social_instagram' => array( 'class' => 'np-fsi-ig',  'label' => 'Instagram', 'letter' => 'in' ),
                            'np_social_twitter'   => array( 'class' => 'np-fsi-tw',  'label' => 'Twitter',   'letter' => 'x' ),
                            'np_social_youtube'   => array( 'class' => 'np-fsi-yt',  'label' => 'YouTube',   'letter' => 'yt' ),
                        );
                        foreach ( $follow_links as $mod => $s ) :
                            $url = get_theme_mod( $mod, '' );
                            if ( $url ) :
                        ?>
                            <a href="<?php echo esc_url( $url ); ?>" class="<?php echo esc_attr( $s['class'] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $s['label'] ); ?>"><?php echo esc_html( strtoupper( $s['letter'] ) ); ?></a>
                        <?php endif; endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="np-footer-bottom">
        <div class="np-container">
            <div class="np-footer-copyright">
                <?php echo wp_kses_post( get_theme_mod( 'np_footer_copyright', '&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '. All Rights Reserved.' ) ); ?>
            </div>

            <?php if ( has_nav_menu( 'footer-1' ) ) : ?>
            <nav aria-label="<?php esc_attr_e('Footer Navigation','newspress'); ?>">
                <?php wp_nav_menu( [
                    'theme_location' => 'footer-1',
                    'container'      => false,
                    'menu_class'     => 'np-footer-nav',
                    'depth'          => 1,
                    'fallback_cb'    => false,
                ] ); ?>
            </nav>
            <?php endif; ?>

            <div class="np-footer-social">
                <?php
                $socials = [
                    'np_social_facebook'  => 'fb',
                    'np_social_twitter'   => 'tw',
                    'np_social_instagram' => 'ig',
                    'np_social_youtube'   => 'yt',
                ];
                foreach ( $socials as $mod => $class ) :
                    $url = get_theme_mod( $mod, '' );
                    if ( $url ) :
                ?>
                    <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" class="np-footer-social-<?php echo esc_attr($class); ?>" aria-label="<?php echo esc_attr(ucfirst($class)); ?>"><?php echo esc_html(strtoupper($class)); ?></a>
                <?php endif; endforeach; ?>
            </div>
        </div>
    </div>
</footer>

<?php if ( get_theme_mod( 'np_footer_show_back_top', true ) ) : ?>
<button id="np-back-top" aria-label="<?php esc_attr_e('Back to top','newspress'); ?>" title="<?php esc_attr_e('Back to top','newspress'); ?>">&#8679;</button>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
