/**
 * NewsPress Customizer Live Preview
 * Binds every postMessage setting to a CSS variable or DOM update.
 * Controls using transport:'refresh' reload the iframe automatically.
 *
 * @package NewsPress
 */
(function () {
    'use strict';

    /* ── Helper: set a CSS custom property on :root ── */
    function setVar(prop, value) {
        document.documentElement.style.setProperty(prop, value);
    }

    /* ── Helper: set a CSS property with unit suffix ── */
    function setVarPx(prop, value) {
        setVar(prop, value + 'px');
    }

    /* ── Helper: bind a setting to a CSS var (with optional unit) ── */
    function bindVar(id, prop, unit) {
        wp.customize(id, function (value) {
            value.bind(function (v) {
                setVar(prop, unit ? v + unit : v);
            });
        });
    }

    /* ── Helper: bind a setting to px CSS var ── */
    function bindPx(id, prop) { bindVar(id, prop, 'px'); }

    /* ── Helper: bind a number divided by 10 (line-height trick) ── */
    function bindDiv10(id, prop) {
        wp.customize(id, function (value) {
            value.bind(function (v) {
                setVar(prop, (parseInt(v, 10) / 10).toFixed(1));
            });
        });
    }

    /* ================================================================
       COLORS  →  CSS variables (already working, keep + expand)
    ================================================================ */
    var colorMap = [
        ['np_color_primary',    '--np-primary'],
        ['np_color_secondary',  '--np-secondary'],
        ['np_color_accent',     '--np-accent'],
        ['np_color_text',       '--np-text'],
        ['np_color_muted',      '--np-text-muted'],
        ['np_color_bg',         '--np-bg'],
        ['np_color_bg_alt',     '--np-bg-alt'],
        ['np_color_header_bg',  '--np-header-bg'],
        ['np_color_topbar_bg',  '--np-topbar-bg'],
        ['np_color_topbar_text','--np-topbar-text'],
        ['np_color_footer_bg',  '--np-footer-bg'],
        ['np_color_footer_text','--np-footer-text'],
        ['np_color_nav_bg',     '--np-nav-bg'],
        ['np_color_nav_text',   '--np-nav-text'],
        // Back-to-top colors
        ['np_btt_bg',           '--np-btt-bg'],
        ['np_btt_color',        '--np-btt-color'],
    ];
    colorMap.forEach(function (pair) {
        bindVar(pair[0], pair[1]);
    });

    /* ================================================================
       LAYOUT  →  CSS variables + DOM class switching
    ================================================================ */
    bindPx('np_container_width', '--np-container');
    bindPx('np_sidebar_width',   '--np-sidebar-width');
    bindPx('np_border_radius',   '--np-radius');

    // Sidebar position — switches CSS class on .np-site-content live in preview
    // Handles homepage (np_sidebar_pos), single (np_single_sidebar), archive (np_archive_sidebar)
    function npApplySidebarClass(v) {
        var els = document.querySelectorAll('.np-site-content');
        var sidebar = document.getElementById('np-sidebar');
        els.forEach(function(el) {
            el.classList.remove('np-no-sidebar', 'np-left-sidebar');
            if (v === 'none') el.classList.add('np-no-sidebar');
            if (v === 'left') el.classList.add('np-left-sidebar');
        });
        if (sidebar) sidebar.style.display = (v === 'none') ? 'none' : '';
    }
    wp.customize('np_sidebar_pos',     function(val) { val.bind(npApplySidebarClass); });
    wp.customize('np_single_sidebar',  function(val) { val.bind(npApplySidebarClass); });
    wp.customize('np_archive_sidebar', function(val) { val.bind(npApplySidebarClass); });

    // Widget Style — swaps body class, CSS handles the rest
    var widgetStyleClasses = ['np-widget-style-flat','np-widget-style-shadowed','np-widget-style-minimal'];
    wp.customize('np_widget_style', function(val) {
        val.bind(function(v) {
            widgetStyleClasses.forEach(function(c) { document.body.classList.remove(c); });
            if (v && v !== 'boxed') document.body.classList.add('np-widget-style-' + v);
        });
    });

    // Widget Title Style — swaps body class
    var widgetTitleClasses = ['np-widget-title-background','np-widget-title-left-border','np-widget-title-plain'];
    wp.customize('np_widget_title_style', function(val) {
        val.bind(function(v) {
            widgetTitleClasses.forEach(function(c) { document.body.classList.remove(c); });
            if (v && v !== 'underline') document.body.classList.add('np-widget-title-' + v);
        });
    });

    // Widget Font Size — updates CSS variable directly
    wp.customize('np_widget_font_size', function(val) {
        val.bind(function(v) {
            document.documentElement.style.setProperty('--np-font-size-widget', v + 'px');
        });
    });

    // Breaking news ticker show/hide
    wp.customize('np_show_breaking', function(value) {
        value.bind(function(v) {
            var el = document.querySelector('.np-scroll-ticker');
            if (el) el.style.display = v ? '' : 'none';
        });
    });

    // Top bar show/hide
    wp.customize('np_show_topbar', function(value) {
        value.bind(function(v) {
            var el = document.querySelector('.np-topbar');
            if (el) el.style.display = v ? '' : 'none';
        });
    });

    // Category bar show/hide
    wp.customize('np_show_secondary_nav', function(value) {
        value.bind(function(v) {
            var el = document.querySelector('.np-secondary-nav');
            if (el) el.style.display = v ? '' : 'none';
        });
    });

    // Header / menu / footer width -> CSS variables (live); 0 falls back to container width
    ['np_header_width:--np-header-width', 'np_nav_width:--np-nav-width', 'np_footer_width:--np-footer-width'].forEach(function (pair) {
        var p = pair.split(':');
        wp.customize(p[0], function (value) {
            value.bind(function (v) {
                v = parseInt(v, 10) || 0;
                setVar(p[1], v > 0 ? v + 'px' : 'var(--np-container)');
            });
        });
    });

    // Header dimensions -> CSS variables (live)
    bindPx('np_logo_height',        '--np-logo-height');
    bindPx('np_logo_height_mobile', '--np-logo-height-mobile');
    bindPx('np_header_padding',     '--np-header-pad');
    bindPx('np_site_title_size',    '--np-site-title-size');

    // Header search placeholder text (live)
    wp.customize('np_search_placeholder', function(value) {
        value.bind(function(v) {
            var el = document.querySelector('.np-header-search input[type="search"]');
            if (el) el.setAttribute('placeholder', v);
        });
    });

    // Header search show/hide
    wp.customize('np_show_search', function(value) {
        value.bind(function(v) {
            var el = document.querySelector('.np-header-search');
            if (el) el.style.display = v ? '' : 'none';
        });
    });

    // Site title show/hide
    wp.customize('np_show_site_title', function(value) {
        value.bind(function(v) {
            var el = document.querySelector('.np-site-title');
            if (el) el.style.display = v ? '' : 'none';
        });
    });

    // Tagline show/hide
    wp.customize('np_show_tagline', function(value) {
        value.bind(function(v) {
            var el = document.querySelector('.np-site-tagline');
            if (el) el.style.display = v ? '' : 'none';
        });
    });

    // Breaking news label text
    wp.customize('np_breaking_label', function(value) {
        value.bind(function(v) {
            var el = document.querySelector('.np-scroll-ticker-label, .np-breaking-label');
            if (el) el.textContent = v;
        });
    });

    /* ================================================================
       TYPOGRAPHY — Global sizes
    ================================================================ */
    bindPx('np_font_size',        '--np-font-size');
    bindPx('np_font_size_widget', '--np-font-size-widget');
    bindPx('np_font_size_meta',   '--np-font-size-meta');
    bindDiv10('np_font_lh_body',  '--np-lh-body');

    /* ================================================================
       TYPOGRAPHY — Heading sizes
    ================================================================ */
    bindPx('np_h1_size', '--np-h1-size');
    bindPx('np_h2_size', '--np-h2-size');
    bindPx('np_h3_size', '--np-h3-size');
    bindPx('np_h4_size', '--np-h4-size');

    /* ================================================================
       TYPOGRAPHY — Post / Single
    ================================================================ */
    bindPx('np_font_size_post',       '--np-font-size-post');
    bindPx('np_font_size_post_title', '--np-font-size-post-title');
    bindDiv10('np_font_lh_post',      '--np-lh-post');

    /* ================================================================
       TYPOGRAPHY — Cards
    ================================================================ */
    bindPx('np_font_size_card_title',   '--np-font-size-card-title');
    bindPx('np_font_size_card_excerpt', '--np-font-size-card-excerpt');
    bindPx('np_font_size_card_meta',    '--np-font-size-card-meta');

    /* ================================================================
       BACK-TO-TOP BUTTON
    ================================================================ */
    bindPx('np_btt_size',   '--np-btt-size');
    bindPx('np_btt_icon',   '--np-btt-icon');
    bindPx('np_btt_radius', '--np-btt-radius');
    bindPx('np_btt_bottom', '--np-btt-bottom');
    bindPx('np_btt_right',  '--np-btt-right');

    wp.customize('np_btt_cursor', function (value) {
        value.bind(function (v) {
            setVar('--np-btt-cursor', v);
        });
    });

    /* ================================================================
       PAGINATION
    ================================================================ */
    wp.customize('np_pag_align', function (value) {
        value.bind(function (v) {
            var els = document.querySelectorAll('.np-pagination, .navigation.pagination .nav-links');
            els.forEach(function (el) { el.style.justifyContent = v; });
        });
    });
    bindPx('np_pag_gap', '--np-pag-gap');  // fallback var approach
    wp.customize('np_pag_gap', function (value) {
        value.bind(function (v) {
            var els = document.querySelectorAll('.np-pagination, .navigation.pagination .nav-links');
            els.forEach(function (el) { el.style.gap = v + 'px'; });
        });
    });
    wp.customize('np_pag_size', function (value) {
        value.bind(function (v) {
            var els = document.querySelectorAll('.np-pagination a, .np-pagination span, .navigation.pagination .page-numbers');
            els.forEach(function (el) {
                el.style.minWidth = v + 'px';
                el.style.height   = v + 'px';
            });
        });
    });
    wp.customize('np_pag_font_size', function (value) {
        value.bind(function (v) {
            var els = document.querySelectorAll('.np-pagination a, .np-pagination span, .navigation.pagination .page-numbers');
            els.forEach(function (el) { el.style.fontSize = v + 'px'; });
        });
    });
    wp.customize('np_pag_radius', function (value) {
        value.bind(function (v) {
            var els = document.querySelectorAll('.np-pagination a, .np-pagination span, .navigation.pagination .page-numbers');
            els.forEach(function (el) { el.style.borderRadius = v + 'px'; });
        });
    });
    wp.customize('np_pag_margin_top', function (value) {
        value.bind(function (v) {
            var margin = (parseInt(v, 10) / 10).toFixed(1) + 'rem';
            var els = document.querySelectorAll('.np-pagination, .navigation.pagination');
            els.forEach(function (el) { el.style.margin = margin + ' 0'; });
        });
    });

    /* ================================================================
       SITE IDENTITY
    ================================================================ */
    wp.customize('blogname', function (value) {
        value.bind(function (v) {
            var el = document.querySelector('.np-site-title a');
            if (el) el.textContent = v;
        });
    });
    wp.customize('blogdescription', function (value) {
        value.bind(function (v) {
            var el = document.querySelector('.np-site-tagline');
            if (el) el.textContent = v;
        });
    });

    /* ================================================================
       CUSTOM CSS
    ================================================================ */
    wp.customize('np_custom_css', function (value) {
        value.bind(function (v) {
            var style = document.getElementById('newspress-custom-css');
            if (!style) {
                style = document.createElement('style');
                style.id = 'newspress-custom-css';
                document.head.appendChild(style);
            }
            style.textContent = v;
        });
    });

    /* ============================================================
       INJECT CUSTOMIZER STYLES for reset buttons
    ============================================================ */
    (function() {
        var s = document.createElement('style');
        s.textContent = [
            /* Section-level reset bar */
            '.np-reset-section-btn{display:block;width:calc(100% - 24px);margin:10px 12px 4px;padding:5px 10px;background:#f6f7f7;border:1px solid #c3c4c7;border-radius:3px;font-size:11px;cursor:pointer;color:#50575e;text-align:left;transition:background .15s,color .15s;}',
            '.np-reset-section-btn:hover{background:#2271b1!important;color:#fff!important;border-color:#2271b1!important;}',
            /* Per-control default button */
            '.np-def-btn{display:inline-flex;align-items:center;gap:4px;margin-top:5px;padding:3px 8px;background:#f0f0f0;border:1px solid #ccc;border-radius:3px;font-size:10px;cursor:pointer;color:#555;white-space:nowrap;transition:background .15s,color .15s;vertical-align:middle;}',
            '.np-def-btn:hover{background:#2271b1;color:#fff;border-color:#2271b1;}',
            '.np-def-btn .np-def-swatch{display:inline-block;width:10px;height:10px;border-radius:2px;border:1px solid rgba(0,0,0,.15);flex-shrink:0;}',
            /* Color control row layout */
            '.customize-control-color .np-def-btn{margin-left:4px;}',
        ].join('');
        document.head.appendChild(s);
    })();

    /* ============================================================
       HELPER: reset one control to its default
    ============================================================ */
    function npResetCtrl(ctrl, container) {
        if (!ctrl || !ctrl.setting) return;
        var def = ctrl.setting.default;
        if (def === undefined || def === null) return;
        ctrl.setting.set(def);

        // Update range slider UI
        var rangeEl = container ? container.querySelector('#np-range-' + ctrl.id) : null;
        if (rangeEl) {
            rangeEl.value = parseInt(def, 10) || 0;
            rangeEl.dispatchEvent(new Event('input', {bubbles: true}));
            var badge = rangeEl.nextElementSibling;
            var unit  = rangeEl.closest('[id^="customize-control"]');
            var unitStr = unit ? (unit.getAttribute('data-unit') || '') : '';
            if (badge && badge.tagName === 'SPAN') badge.textContent = def + unitStr;
        }
    }

    /* ============================================================
       PER-CONTROL DEFAULT BUTTON
       Adds a small "↩ Default: #d32f2f" button under each control
       that has a default value. Color controls show a swatch.
    ============================================================ */
    function npAddDefButton(ctrl, controlEl) {
        if (!ctrl.setting || ctrl.setting.default === undefined || ctrl.setting.default === null) return;
        if (controlEl.querySelector('.np-def-btn')) return; // already added

        var def     = ctrl.setting.default;
        var isColor = (typeof def === 'string' && /^#[0-9a-f]{3,6}$/i.test(def));
        var isRange = controlEl.classList.contains('customize-control-newspress_range');
        var isEmpty = (def === '' || def === false || def === 0);
        if (isEmpty && !isColor) return; // skip controls with no meaningful default to show

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'np-def-btn';
        btn.title = 'Reset to default: ' + def;

        if (isColor) {
            var swatch = document.createElement('span');
            swatch.className = 'np-def-swatch';
            swatch.style.background = def;
            btn.appendChild(swatch);
        }

        var lbl = document.createElement('span');
        lbl.textContent = '↩ ' + (isColor ? def : 'Default: ' + def);
        btn.appendChild(lbl);

        btn.addEventListener('click', function(e) {
            e.preventDefault();
            npResetCtrl(ctrl, controlEl.closest('.customize-pane-child, #customize-controls'));
        });

        // Append after the control's existing content
        var target = controlEl.querySelector('.customize-control-description, .wp-picker-container, .customize-control-content');
        if (!target) target = controlEl;

        // For color controls, place button after the color picker row
        if (isColor) {
            var pickerRow = controlEl.querySelector('.wp-picker-holder, .color-picker-hex');
            // Insert after description if exists, otherwise end of control
            var desc = controlEl.querySelector('.description.customize-control-description');
            if (desc) {
                desc.insertAdjacentElement('afterend', btn);
            } else {
                controlEl.appendChild(btn);
            }
        } else {
            controlEl.appendChild(btn);
        }
    }

    /* ============================================================
       RESET SECTION TO DEFAULTS  +  per-control default buttons
    ============================================================ */
    if (window.wp && wp.customize) {
        wp.customize.section.each(function(section) {
            section.expanded.bind(function(isExpanded) {
                if (!isExpanded) return;
                var container = section.contentContainer[0];
                if (!container) return;

                /* ── Per-control default buttons (add to every control) ── */
                section.controls().forEach(function(ctrl) {
                    var ctrlEl = container.querySelector('#customize-control-' + ctrl.id);
                    if (ctrlEl) npAddDefButton(ctrl, ctrlEl);
                });

                /* ── Section-level bulk reset bar ── */
                if (container.querySelector('.np-reset-section-btn')) return;
                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'np-reset-section-btn';
                btn.innerHTML = '&#8635; Reset all ' + section.params.title + ' to defaults';

                btn.addEventListener('click', function() {
                    var controls = section.controls();
                    var toReset  = controls.filter(function(c) {
                        return c.setting && c.setting.default !== undefined && c.setting.default !== null;
                    });
                    if (!toReset.length) return;
                    if (!window.confirm('Reset all ' + toReset.length + ' setting(s) in "' + section.params.title + '" to defaults?')) return;
                    toReset.forEach(function(c) { npResetCtrl(c, container); });
                });

                var firstCtrl = container.querySelector('.customize-control');
                if (firstCtrl) container.insertBefore(btn, firstCtrl);
                else container.appendChild(btn);
            });
        });
    }


    /* ================================================================
       TYPOGRAPHY — Font family live preview
       Injects Google Font <link> on-the-fly and updates CSS vars
    ================================================================ */
    function npFontStack(font) {
        if (!font || font === 'sys:default') return 'Georgia,"Times New Roman",serif';
        // Strip sys: prefix for system fonts
        var name = font.indexOf('sys:') === 0 ? font.slice(4) : font;
        var serifFallback  = 'Georgia,"Times New Roman",serif';
        var sansFallback   = '"Helvetica Neue",Arial,sans-serif';
        // Detect if likely serif
        var serifHints = ['Georgia','Merriweather','Lora','PT Serif','Playfair','Garamond',
            'Crimson','Libre Baskerville','Spectral','Vollkorn','Alegreya','Bitter',
            'Domine','Gelasio','Arvo','Frank Ruhl','Zilla','EB Garamond','DM Serif',
            'Source Serif','Noto Serif','IBM Plex Serif'];
        var isSerif = serifHints.some(function(h){ return name.indexOf(h) !== -1; });
        return '"' + name + '",' + (isSerif ? serifFallback : sansFallback);
    }

    function npLoadGoogleFont(font) {
        if (!font || font.indexOf('sys:') === 0) return; // system font, no load needed
        var id = 'np-gf-' + font.replace(/[^a-z0-9]/gi, '-').toLowerCase();
        if (document.getElementById(id)) return; // already loaded
        var url = 'https://fonts.googleapis.com/css2?family=' +
            encodeURIComponent(font) + ':ital,wght@0,400;0,700;0,900;1,400&display=swap';
        var link = document.createElement('link');
        link.id = id;
        link.rel = 'stylesheet';
        link.href = url;
        document.head.appendChild(link);
    }

    /* Update the server-rendered <style id="newspress-vars"> tag directly.
       This is more reliable than setProperty on :root because it replaces
       the exact same rule the server output — no specificity conflict. */
    function npUpdateFontVar(prop, font) {
        npLoadGoogleFont(font);
        var stack = npFontStack(font);

        // Method 1: update the newspress-vars <style> tag inline text
        var styleTag = document.getElementById('newspress-vars');
        if (styleTag) {
            // Replace the existing var value inside the :root{} block
            var re = new RegExp('(' + prop.replace('--', '--') + ':)[^;]+;');
            if (re.test(styleTag.textContent)) {
                styleTag.textContent = styleTag.textContent.replace(re, '$1' + stack + ';');
                return;
            }
        }

        // Method 2: fallback — inject a new <style> override after newspress-vars
        var overId = 'np-font-override-' + prop.replace(/[^a-z0-9]/gi, '-');
        var override = document.getElementById(overId);
        if (!override) {
            override = document.createElement('style');
            override.id = overId;
            document.head.appendChild(override);
        }
        override.textContent = ':root{' + prop + ':' + stack + '!important;}';
    }

    wp.customize('np_font_body', function(value) {
        value.bind(function(font) {
            npUpdateFontVar('--np-font-body', font);
        });
    });

    wp.customize('np_font_heading', function(value) {
        value.bind(function(font) {
            npUpdateFontVar('--np-font-heading', font);
        });
    });


    /* ================================================================
       FLOAT / LIFT EFFECT — 4-zone live preview
    ================================================================ */

    function npHex2rgba(hex, opacity) {
        hex = hex.replace('#','');
        if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
        var r = parseInt(hex.substring(0,2),16);
        var g = parseInt(hex.substring(2,4),16);
        var b = parseInt(hex.substring(4,6),16);
        return 'rgba('+r+','+g+','+b+','+opacity.toFixed(2)+')';
    }

    function npGetF(id, def) {
        return (wp.customize && wp.customize(id)) ? wp.customize(id).get() : def;
    }

    function npBuildZoneCSS() {
        var lift    = parseInt(npGetF('np_float_lift', 4), 10);
        var dur     = parseInt(npGetF('np_float_duration', 220), 10);
        var color   = npGetF('np_float_shadow_color', '#000000');
        var opacity = parseInt(npGetF('np_float_shadow_opacity', 18), 10) / 100;
        var blur    = parseInt(npGetF('np_float_shadow_blur', 20), 10);
        var spread  = parseInt(npGetF('np_float_shadow_spread', 0), 10);
        var scale   = parseInt(npGetF('np_float_scale', 105), 10) / 100;
        var bg      = npGetF('np_float_card_bg', '');

        var shadow = npHex2rgba(color, opacity);

        // Direction → concrete X/Y (matches PHP dir_map exactly)
        var dir     = npGetF('np_float_shadow_dir', 'bottom');
        var customX = parseInt(npGetF('np_float_shadow_x', 0), 10);
        var customY = parseInt(npGetF('np_float_shadow_y', 8), 10);
        var dirMap  = {
            'bottom':       [0, lift],
            'bottom-right': [lift, lift],
            'bottom-left':  [-lift, lift],
            'top':          [0, -lift],
            'top-right':    [lift, -lift],
            'top-left':     [-lift, -lift],
            'right':        [lift, 0],
            'left':         [-lift, 0],
            'center':       [0, 0],
            'custom':       [customX, customY]
        };
        var xy         = dirMap[dir] || [0, lift];
        var sx         = xy[0], sy = xy[1];
        // Use concrete px values — NO CSS vars — matches PHP output exactly
        var liftShadow = sx + 'px ' + sy + 'px ' + blur + 'px ' + spread + 'px ' + shadow;
        var liftTF     = 'translateY(' + (-lift) + 'px)';
        var trans      = 'box-shadow ' + dur + 'ms ease, transform ' + dur + 'ms ease';
        var transImg   = 'transform ' + dur + 'ms ease';

        function zoneRules(mode, cardSels, imgSels, imgParentHovers) {
            if (mode === 'off') return '';
            var css = '';
            if (cardSels.length) {
                var cardStr = cardSels.join(', ');
                css += cardStr + ' { transition: ' + trans + '; }';
                if (mode === 'always') {
                    css += cardStr + ' { transform: ' + liftTF + '; box-shadow: ' + liftShadow + '; }';
                } else {
                    css += cardSels.map(function(s){ return s+':hover'; }).join(', ') +
                        ' { transform: ' + liftTF + '; box-shadow: ' + liftShadow + '; }';
                }
            }
            if (imgSels.length) {
                css += imgSels.join(', ') + ' { transition: ' + transImg + '; }';
                if (scale > 1) {
                    if (mode === 'always') {
                        css += imgSels.join(', ') + ' { transform: scale(' + scale + '); }';
                    } else {
                        css += imgParentHovers.join(', ') + ' { transform: scale(' + scale + '); }';
                    }
                }
            }
            return css;
        }

        var zCards  = npGetF('np_float_zone_cards',  'hover');
        var zHero   = npGetF('np_float_zone_hero',   'hover');
        var zSingle = npGetF('np_float_zone_single', 'always');
        var zWidget = npGetF('np_float_zone_widget', 'hover');

        var css = '';

        // Zone 1: Post Cards
        css += zoneRules(zCards,
            ['.np-card', '.np-section-card'],
            ['.np-card .np-card-thumb img'],
            ['.np-card:hover .np-card-thumb img']
        );
        // Zone 2: Hero & section images
        css += zoneRules(zHero,
            ['.np-hero-main', '.np-hero-side', '.np-magazine-main', '.np-magazine-side'],
            ['.np-hero-main img', '.np-hero-side img', '.np-magazine-main img', '.np-magazine-side img'],
            ['.np-hero-main:hover img', '.np-hero-side:hover img', '.np-magazine-main:hover img', '.np-magazine-side:hover img']
        );
        // Zone 3: Single post / page images
        css += zoneRules(zSingle,
            [],
            ['body.np-single .np-featured-image img', 'body.np-single .np-entry-content img',
             'body.np-page .np-featured-image img',   'body.np-page .np-entry-content img'],
            ['body.np-single .np-featured-image img:hover', 'body.np-single .np-entry-content img:hover',
             'body.np-page .np-featured-image img:hover',   'body.np-page .np-entry-content img:hover']
        );
        // Zone 4: Widget & sidebar cards
        css += zoneRules(zWidget,
            ['.np-sidebar .np-card', '.widget .np-card', '.np-numbered-post-item'],
            ['.np-sidebar .np-card .np-card-thumb img'],
            ['.np-sidebar .np-card:hover .np-card-thumb img']
        );
        // Related posts follows cards zone
        css += zoneRules(zCards,
            ['.np-related-item'],
            ['.np-related-item img'],
            ['.np-related-item:hover img']
        );

        if (bg) css += '.np-card { background: ' + bg + '; }';
        return css;
    }

    function npApplyFloatOverride() {
        var styleId = 'np-float-preview';
        var style = document.getElementById(styleId);
        if (!style) {
            style = document.createElement('style');
            style.id = styleId;
            document.head.appendChild(style);
        }
        style.textContent = npBuildZoneCSS();
    }

    var floatWatchIds = [
        'np_float_zone_cards', 'np_float_zone_hero', 'np_float_zone_single', 'np_float_zone_widget',
        'np_float_lift', 'np_float_duration', 'np_float_shadow_color', 'np_float_shadow_opacity',
        'np_float_shadow_blur', 'np_float_shadow_spread', 'np_float_scale', 'np_float_card_bg',
        'np_float_shadow_dir', 'np_float_shadow_x', 'np_float_shadow_y'
    ];
    floatWatchIds.forEach(function(id) {
        wp.customize(id, function(value) {
            value.bind(function() { npApplyFloatOverride(); });
        });
    });

    // Show/hide custom X/Y controls based on direction selection
    function npToggleCustomXY(dir) {
        var xRow = document.getElementById('customize-control-np_float_shadow_x');
        var yRow = document.getElementById('customize-control-np_float_shadow_y');
        var isCustom = (dir === 'custom');
        if (xRow) xRow.style.display = isCustom ? '' : 'none';
        if (yRow) yRow.style.display = isCustom ? '' : 'none';
    }
    wp.customize('np_float_shadow_dir', function(value) {
        value.bind(function(dir) {
            npToggleCustomXY(dir);
            npApplyFloatOverride();
        });
        // Init on load — run after a tick so DOM is ready
        setTimeout(function() { npToggleCustomXY(value.get()); }, 300);
    });

    // Run once on load to initialise
    npApplyFloatOverride();


})();
