/**
 * NewsPress Homepage Section Builder
 * Runs inside the Customizer controls panel (not the preview iframe).
 */
( function( $ ) {
    'use strict';

    var categories = npSectionBuilderData.categories || [];
    var layouts    = npSectionBuilderData.layouts    || {};

    // ── helpers ──────────────────────────────────────────────────
    function readJSON() {
        var raw = $( '#np-sections-json' ).val().trim();
        if ( ! raw ) return [];
        try { return JSON.parse( raw ); } catch(e) { return []; }
    }

    function writeJSON( sections ) {
        $( '#np-sections-json' ).val( JSON.stringify( sections ) ).trigger( 'change' );
    }

    function catOptions( selected ) {
        return categories.map( function( c ) {
            var sel = ( parseInt( selected, 10 ) === c.id ) ? ' selected' : '';
            return '<option value="' + c.id + '"' + sel + '>' + c.name + '</option>';
        } ).join( '' );
    }

    function layoutOptions( selected ) {
        return Object.keys( layouts ).map( function( key ) {
            var sel = ( selected === key ) ? ' selected' : '';
            return '<option value="' + key + '"' + sel + '>' + layouts[ key ] + '</option>';
        } ).join( '' );
    }

    // ── render a single section row ───────────────────────────────
    function buildRow( sec, idx ) {
        var enabled = sec.enabled !== false;
        var count   = sec.count   || 6;
        var title   = sec.title   || '';
        var showMore = sec.show_more !== false;

        return $( '<div>', {
            'class'        : 'np-section-row',
            'data-idx'     : idx,
            'style'        : 'background:#fff;border:1px solid #ddd;border-radius:4px;padding:10px;margin-bottom:8px;'
        } ).html(
            // Header bar
            '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">' +
                '<span class="np-drag-handle dashicons dashicons-move" title="Drag to reorder" style="cursor:grab;color:#aaa;flex-shrink:0;"></span>' +
                '<strong style="flex:1;font-size:12px;" class="np-row-label">' + rowLabel( sec ) + '</strong>' +
                '<label style="font-size:11px;display:flex;align-items:center;gap:4px;cursor:pointer;">' +
                    '<input type="checkbox" class="np-sec-enabled"' + ( enabled ? ' checked' : '' ) + '> On' +
                '</label>' +
                '<button type="button" class="np-remove-section button-link" style="color:#a00;font-size:18px;line-height:1;padding:0 4px;" title="Remove">&times;</button>' +
            '</div>' +
            // Fields
            '<table style="width:100%;border-collapse:collapse;font-size:12px;">' +
                '<tr>' +
                    '<td style="padding:3px 4px;width:40%;color:#555;">Category</td>' +
                    '<td><select class="np-sec-cat" style="width:100%">' + catOptions( sec.cat_id ) + '</select></td>' +
                '</tr>' +
                '<tr>' +
                    '<td style="padding:3px 4px;color:#555;">Layout</td>' +
                    '<td><select class="np-sec-layout" style="width:100%">' + layoutOptions( sec.layout || 'grid-3' ) + '</select></td>' +
                '</tr>' +
                '<tr>' +
                    '<td style="padding:3px 4px;color:#555;">Post count</td>' +
                    '<td><input type="number" class="np-sec-count" value="' + count + '" min="1" max="24" style="width:60px;"></td>' +
                '</tr>' +
                '<tr>' +
                    '<td style="padding:3px 4px;color:#555;">Section title</td>' +
                    '<td><input type="text" class="np-sec-title" value="' + escAttr( title ) + '" placeholder="(optional)" style="width:100%;"></td>' +
                '</tr>' +
                '<tr>' +
                    '<td style="padding:3px 4px;color:#555;">Show more link</td>' +
                    '<td><input type="checkbox" class="np-sec-showmore"' + ( showMore ? ' checked' : '' ) + '></td>' +
                '</tr>' +
            '</table>'
        );
    }

    function rowLabel( sec ) {
        var cat = categories.find( function(c){ return c.id === parseInt( sec.cat_id, 10 ); } );
        var catName = cat ? cat.name : 'Latest Posts';
        return escHtml( catName ) + ' &mdash; ' + ( sec.layout || 'grid-3' );
    }

    function escAttr( s ) { return String( s ).replace( /"/g, '&quot;' ).replace( /</g, '&lt;' ); }
    function escHtml( s ) { return String( s ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' ); }

    // ── collect data from all rows → JSON ────────────────────────
    function collectSections() {
        var sections = [];
        $( '#np-section-list .np-section-row' ).each( function() {
            var $r = $( this );
            sections.push( {
                type      : 'category',
                cat_id    : parseInt( $r.find( '.np-sec-cat' ).val(), 10 ),
                layout    : $r.find( '.np-sec-layout' ).val(),
                count     : parseInt( $r.find( '.np-sec-count' ).val(), 10 ) || 6,
                title     : $r.find( '.np-sec-title' ).val(),
                show_more : $r.find( '.np-sec-showmore' ).is( ':checked' ),
                enabled   : $r.find( '.np-sec-enabled' ).is( ':checked' ),
            } );
        } );
        return sections;
    }

    // ── render all rows from current JSON ────────────────────────
    function renderAll() {
        var $list = $( '#np-section-list' ).empty();
        var sections = readJSON();
        if ( ! sections.length ) {
            $list.append( '<p style="color:#888;font-size:12px;text-align:center;padding:12px 0;">No sections yet — click "+ Add Section" below.</p>' );
            return;
        }
        sections.forEach( function( sec, idx ) {
            $list.append( buildRow( sec, idx ) );
        } );
        initSortable();
    }

    // ── sortable drag-to-reorder ──────────────────────────────────
    function initSortable() {
        if ( $.fn.sortable ) {
            $( '#np-section-list' ).sortable( {
                handle   : '.np-drag-handle',
                axis     : 'y',
                update   : function() { writeJSON( collectSections() ); }
            } );
        }
    }

    // ── event delegation ─────────────────────────────────────────
    $( document ).on( 'change input', '#np-section-list .np-sec-cat, #np-section-list .np-sec-layout, #np-section-list .np-sec-count, #np-section-list .np-sec-title, #np-section-list .np-sec-enabled, #np-section-list .np-sec-showmore', function() {
        // Update row label
        var $row = $( this ).closest( '.np-section-row' );
        var sec  = {
            cat_id : $row.find( '.np-sec-cat' ).val(),
            layout : $row.find( '.np-sec-layout' ).val(),
        };
        $row.find( '.np-row-label' ).html( rowLabel( sec ) );
        writeJSON( collectSections() );
    } );

    $( document ).on( 'click', '.np-remove-section', function() {
        $( this ).closest( '.np-section-row' ).remove();
        if ( ! $( '#np-section-list .np-section-row' ).length ) {
            writeJSON( [] );
            renderAll(); // show empty state
        } else {
            writeJSON( collectSections() );
        }
    } );

    $( document ).on( 'click', '#np-add-section', function() {
        // Remove "no sections" placeholder if present
        $( '#np-section-list p' ).remove();
        var sections = readJSON();
        var newSec = { type: 'category', cat_id: 0, layout: 'grid-3', count: 6, title: '', show_more: true, enabled: true };
        sections.push( newSec );
        $( '#np-section-list' ).append( buildRow( newSec, sections.length - 1 ) );
        initSortable();
        writeJSON( collectSections() );
    } );

    // ── init on Customizer ready ──────────────────────────────────
    $( document ).ready( function() {
        // Slight delay to ensure control HTML is in DOM
        setTimeout( renderAll, 300 );
    } );

} )( jQuery );
