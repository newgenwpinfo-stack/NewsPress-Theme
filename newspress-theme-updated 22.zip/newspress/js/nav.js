/**
 * NewsPress Navigation — Mobile & Tablet Menu
 *
 * Handles:
 *  - Hamburger toggle (open/close off-canvas panel)
 *  - Body scroll lock when menu is open
 *  - Sub-menu expand/collapse via dedicated toggle buttons
 *  - Close on Escape key
 *  - Close on outside click/tap
 *  - Focus trap inside open menu (accessibility)
 *  - Keyboard arrow navigation
 *  - ARIA attribute maintenance
 *
 * Design decisions:
 *  - Pure vanilla JS, zero jQuery dependency
 *  - Uses CSS class toggling only — no inline style manipulation
 *  - Deferred-safe: wrapped in DOMContentLoaded + readyState guard
 *  - Cache-plugin safe: IIFE with no global pollution
 *  - Touch-safe: touchend fires before click — flag prevents double-trigger
 *
 * @package NewsPress
 */

(function () {
    'use strict';

    /* ── Utilities ─────────────────────────────────────────────── */
    var qs  = function (s, ctx) { return (ctx || document).querySelector(s); };
    var qsa = function (s, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(s)); };

    /* ── State ──────────────────────────────────────────────────── */
    var menuOpen    = false;
    var lastFocused = null; // element focused before menu opened — restored on close

    /* ── Elements (resolved in init) ───────────────────────────── */
    var toggle, menu, nav, overlay;

    /* ═══════════════════════════════════════════════════════════════
       OPEN / CLOSE
    ═══════════════════════════════════════════════════════════════ */

    function openMenu() {
        if (menuOpen) return;
        menuOpen = true;

        lastFocused = document.activeElement;

        menu.classList.add('np-open');
        toggle.setAttribute('aria-expanded', 'true');
        toggle.classList.add('np-toggle-active');

        // Body scroll lock — saves scrollY so we can restore it
        document.body.classList.add('np-menu-open');

        // Show overlay
        if (overlay) overlay.classList.add('np-overlay-visible');

        // Move focus into menu for keyboard users
        var firstLink = qs('a, button', menu);
        if (firstLink) firstLink.focus();

        // Update toggle icon
        updateToggleIcon(true);
    }

    function closeMenu(returnFocus) {
        if (!menuOpen) return;
        menuOpen = false;

        menu.classList.remove('np-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.classList.remove('np-toggle-active');

        document.body.classList.remove('np-menu-open');

        if (overlay) overlay.classList.remove('np-overlay-visible');

        // Collapse all open sub-menus
        qsa('.np-sub-open', menu).forEach(function (li) {
            li.classList.remove('np-sub-open');
            var btn = qs('.np-sub-toggle', li);
            if (btn) btn.setAttribute('aria-expanded', 'false');
        });

        // Restore focus
        if (returnFocus !== false && lastFocused && typeof lastFocused.focus === 'function') {
            lastFocused.focus();
        }

        updateToggleIcon(false);
    }

    function toggleMenu() {
        if (menuOpen) {
            closeMenu(true);
        } else {
            openMenu();
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       TOGGLE ICON — hamburger ↔ ✕
    ═══════════════════════════════════════════════════════════════ */

    function updateToggleIcon(isOpen) {
        var icon = qs('.np-toggle-icon', toggle);
        if (!icon) return;
        // Swap between ☰ (hamburger) and ✕ (close)
        icon.innerHTML = isOpen
            ? '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>'
            : '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><line x1="3" y1="7" x2="21" y2="7"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="17" x2="21" y2="17"/></svg>';
    }

    /* ═══════════════════════════════════════════════════════════════
       SUB-MENU TOGGLE
    ═══════════════════════════════════════════════════════════════ */

    function handleSubToggle(btn) {
        var li  = btn.closest('.menu-item-has-children');
        var sub = li && qs('.sub-menu', li);
        if (!li || !sub) return;

        var isOpen = li.classList.contains('np-sub-open');

        // Close sibling sub-menus at the same level
        var parent   = li.parentElement;
        var siblings = parent ? qsa(':scope > .menu-item-has-children.np-sub-open', parent) : [];
        siblings.forEach(function (s) {
            if (s !== li) {
                s.classList.remove('np-sub-open');
                var sibBtn = qs('.np-sub-toggle', s);
                if (sibBtn) sibBtn.setAttribute('aria-expanded', 'false');
            }
        });

        // Toggle this item
        li.classList.toggle('np-sub-open', !isOpen);
        btn.setAttribute('aria-expanded', String(!isOpen));

        // Move focus to first sub-menu item when opening
        if (!isOpen) {
            var firstSubLink = qs('a', sub);
            if (firstSubLink) setTimeout(function () { firstSubLink.focus(); }, 50);
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       FOCUS TRAP — keeps Tab/Shift+Tab inside open menu
    ═══════════════════════════════════════════════════════════════ */

    function trapFocus(e) {
        if (!menuOpen || e.key !== 'Tab') return;

        var focusable = qsa(
            'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])',
            menu
        );
        if (!focusable.length) return;

        var first = focusable[0];
        var last  = focusable[focusable.length - 1];

        if (e.shiftKey && document.activeElement === first) {
            e.preventDefault();
            last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first.focus();
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       KEYBOARD NAVIGATION — arrow keys move between items
    ═══════════════════════════════════════════════════════════════ */

    function handleMenuKeyboard(e) {
        if (!menuOpen) return;

        // Escape — close menu
        if (e.key === 'Escape') {
            e.stopPropagation();
            closeMenu(true);
            return;
        }

        // Arrow keys on top-level items
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            var items = qsa('.np-nav-menu > li > a', menu);
            var idx   = items.indexOf(document.activeElement);
            if (idx === -1) return;
            e.preventDefault();
            var next = e.key === 'ArrowDown'
                ? items[Math.min(idx + 1, items.length - 1)]
                : items[Math.max(idx - 1, 0)];
            if (next) next.focus();
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       TOUCH — prevent 300ms delay and double-trigger
    ═══════════════════════════════════════════════════════════════ */

    function addTouchSafety(element, handler) {
        var touched = false;

        element.addEventListener('touchend', function (e) {
            touched = true;
            handler(e);
            // Reset after click would have fired
            setTimeout(function () { touched = false; }, 600);
        }, { passive: false });

        element.addEventListener('click', function (e) {
            if (!touched) handler(e);
        });
    }

    /* ═══════════════════════════════════════════════════════════════
       OVERLAY — semi-transparent backdrop
    ═══════════════════════════════════════════════════════════════ */

    function createOverlay() {
        var el = document.createElement('div');
        el.className = 'np-nav-overlay';
        el.setAttribute('aria-hidden', 'true');
        document.body.appendChild(el);
        return el;
    }

    /* ═══════════════════════════════════════════════════════════════
       DESKTOP: RESET any mobile-only state on window resize
    ═══════════════════════════════════════════════════════════════ */

    function handleResize() {
        if (window.innerWidth > 768 && menuOpen) {
            // Silently close without returning focus — user resized
            menuOpen = false;
            menu.classList.remove('np-open');
            toggle.setAttribute('aria-expanded', 'false');
            toggle.classList.remove('np-toggle-active');
            document.body.classList.remove('np-menu-open');
            if (overlay) overlay.classList.remove('np-overlay-visible');
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       INIT
    ═══════════════════════════════════════════════════════════════ */

    function init() {
        toggle = qs('.np-menu-toggle');
        menu   = qs('#np-primary-menu');
        nav    = qs('#np-navigation') || qs('.np-main-nav');

        // Bail if either critical element is missing
        if (!toggle || !menu) return;

        // Upgrade toggle button HTML with SVG icon + screen-reader label
        toggle.innerHTML =
            '<span class="np-toggle-icon" aria-hidden="true">' +
                '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true">' +
                    '<line x1="3" y1="7" x2="21" y2="7"/>' +
                    '<line x1="3" y1="12" x2="21" y2="12"/>' +
                    '<line x1="3" y1="17" x2="21" y2="17"/>' +
                '</svg>' +
            '</span>' +
            '<span class="np-toggle-label">' + (toggle.getAttribute('data-label') || 'Menu') + '</span>';

        // Create overlay
        overlay = createOverlay();

        /* ── Close button inside panel ── */
        var closeBtn = qs('.np-menu-close', menu);
        if (closeBtn) {
            addTouchSafety(closeBtn, function (e) {
                e.preventDefault();
                e.stopPropagation();
                closeMenu(true);
            });
        }

        /* ── Toggle button ── */
        addTouchSafety(toggle, function (e) {
            e.preventDefault();
            e.stopPropagation();
            toggleMenu();
        });

        /* ── Sub-menu toggle buttons ── */
        qsa('.np-sub-toggle', menu).forEach(function (btn) {
            addTouchSafety(btn, function (e) {
                e.preventDefault();
                e.stopPropagation();
                handleSubToggle(btn);
            });
        });

        /* ── Overlay tap — close menu ── */
        addTouchSafety(overlay, function (e) {
            e.preventDefault();
            closeMenu(true);
        });

        /* ── Keyboard events ── */
        document.addEventListener('keydown', function (e) {
            trapFocus(e);
            handleMenuKeyboard(e);
        });

        /* ── Outside click (desktop fallback) ── */
        document.addEventListener('click', function (e) {
            if (!menuOpen) return;
            if (menu.contains(e.target) || toggle.contains(e.target)) return;
            closeMenu(true);
        });

        /* ── Resize ── */
        var resizeTimer;
        window.addEventListener('resize', function () {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(handleResize, 100);
        }, { passive: true });

        /* ── Desktop: hover-based sub-menus still work ── */
        // No JS needed — CSS :hover handles desktop dropdowns
        // But prevent touch devices from triggering :hover permanently
        // by adding pointer-fine detection class to <html>
        if (window.matchMedia && window.matchMedia('(pointer: fine)').matches) {
            document.documentElement.classList.add('np-pointer-fine');
        }
    }

    /* ── Safe DOM-ready: works with defer, async, and without ── */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        // DOM already parsed (script is defer/at bottom)
        init();
    }

})();
