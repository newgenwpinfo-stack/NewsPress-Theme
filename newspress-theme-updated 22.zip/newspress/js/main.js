/**
 * NewsPress Main JavaScript
 * @package NewsPress
 */
(function () {
    'use strict';

    function qs(s, c)  { return (c || document).querySelector(s); }
    function qsa(s, c) { return (c || document).querySelectorAll(s); }

    function init() {

        /* Navigation (mobile toggle, sub-menus, focus trap) handled by js/nav.js */

        /* ── Scroll: Sticky header + progress bar + back-to-top ── */
        var stickyHeader = qs('.np-site-header');
        var progressBar  = qs('#np-read-progress');
        var backTop      = qs('#np-back-top');
        var scrollTick   = false;

        function onScroll() {
            var y = window.pageYOffset || document.documentElement.scrollTop;
            if (stickyHeader) stickyHeader.classList.toggle('np-scrolled', y > 80);
            if (progressBar) {
                var dh  = document.documentElement.scrollHeight - document.documentElement.clientHeight;
                var pct = dh > 0 ? Math.min(100, (y / dh) * 100) : 0;
                progressBar.style.width = pct + '%';
            }
            if (backTop) backTop.classList.toggle('np-visible', y > 400);
            scrollTick = false;
        }

        if (stickyHeader || progressBar || backTop) {
            window.addEventListener('scroll', function () {
                if (!scrollTick) { scrollTick = true; window.requestAnimationFrame(onScroll); }
            }, { passive: true });
            onScroll();
        }

        if (backTop) {
            backTop.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        /* ── Breaking News Ticker ── */
        var ticker = qs('.np-breaking-ticker-inner');
        if (ticker) {
            ticker.addEventListener('mouseenter', function () { ticker.style.animationPlayState = 'paused'; });
            ticker.addEventListener('mouseleave', function () { ticker.style.animationPlayState = 'running'; });
        }

        /* ── Dark Mode ──
         * Initial state + button label are already resolved by the two
         * inline scripts in header.php (no OS/browser detection anywhere —
         * manual only). This just handles the click. */
        var darkToggle = qs('#np-dark-toggle');
        if (darkToggle) {
            darkToggle.addEventListener('click', function () {
                var active = document.body.classList.toggle('np-dark-mode');
                try { localStorage.setItem('np-dark', active ? '1' : '0'); } catch (e) {}
                if (window.NPThemeToggle && typeof window.NPThemeToggle.render === 'function') {
                    window.NPThemeToggle.render(active);
                }
            });
        }

        /* ── Section Tabs ── */
        qsa('.np-tabs').forEach(function (tabs) {
            var links = qsa('.np-tab-nav li', tabs);
            var panes = qsa('.np-tab-pane', tabs);
            links.forEach(function (li, i) {
                var a = li.querySelector('a');
                if (!a) return;
                a.addEventListener('click', function (e) {
                    e.preventDefault();
                    links.forEach(function (l) { l.classList.remove('np-active'); });
                    panes.forEach(function (p) { p.classList.remove('np-active'); });
                    li.classList.add('np-active');
                    if (panes[i]) panes[i].classList.add('np-active');
                });
            });
            if (links[0]) links[0].classList.add('np-active');
            if (panes[0]) panes[0].classList.add('np-active');
        });

        /* ── AJAX Load More ── */
        var loadMore = qs('#np-load-more');
        if (loadMore && typeof npData !== 'undefined') {
            var lmBusy = false;
            loadMore.addEventListener('click', function () {
                if (lmBusy) return;
                lmBusy = true;
                var btn    = this;
                var page   = parseInt(btn.getAttribute('data-page')) || 2;
                var layout = btn.getAttribute('data-layout') || 'grid-3';
                btn.textContent = btn.getAttribute('data-loading') || 'Loading\u2026';
                btn.disabled = true;
                var fd = new FormData();
                fd.append('action', 'newspress_load_more');
                fd.append('nonce',  npData.nonce);
                fd.append('page',   page);
                fd.append('layout', layout);
                fetch(npData.ajaxUrl, { method: 'POST', body: fd })
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        if (data.success && data.data.html) {
                            var wrap = qs('#np-posts-container');
                            if (wrap) {
                                var tmp = document.createElement('div');
                                tmp.innerHTML = data.data.html;
                                while (tmp.firstChild) wrap.appendChild(tmp.firstChild);
                            }
                            btn.setAttribute('data-page', page + 1);
                            if (!data.data.has_more) {
                                if (btn.parentElement) btn.parentElement.remove();
                            } else {
                                btn.textContent = 'Load More Stories';
                                btn.disabled = false;
                            }
                        }
                        lmBusy = false;
                    })
                    .catch(function () {
                        btn.textContent = 'Load More Stories';
                        btn.disabled = false;
                        lmBusy = false;
                    });
            });
        }

        /* ── Copy Share Button ── */
        var copyBtn = qs('.np-share-copy');
        if (copyBtn && navigator.clipboard) {
            copyBtn.addEventListener('click', function () {
                var url = copyBtn.getAttribute('data-url') || location.href;
                navigator.clipboard.writeText(url).then(function () {
                    copyBtn.textContent = '\u2713 Copied';
                    setTimeout(function () { copyBtn.textContent = 'Copy'; }, 2000);
                });
            });
        }

        /* ── Sticky Sidebar ── */
        var stickySidebar = qs('#np-sidebar.np-sticky');
        if (stickySidebar) {
            function setStickyTop() {
                var ab = qs('#wpadminbar');
                stickySidebar.style.top = (ab ? ab.offsetHeight + 12 : 80) + 'px';
            }
            setStickyTop();
            window.addEventListener('resize', setStickyTop, { passive: true });
        }

    } // end init()

    /* ── Safe DOM-ready call — works with defer and without ── */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
