<?php
/**
 * 404 Template
 *
 * @package NewsPress
 */

get_header();
?>
<div class="np-container">
    <div class="np-site-content np-no-sidebar" style="min-height:50vh;display:flex;align-items:center;justify-content:center;">
        <section class="np-error-404" style="text-align:center;max-width:500px;">
            <h1 style="font-size:5rem;color:var(--np-primary);line-height:1;">404</h1>
            <h2><?php esc_html_e('Page Not Found','newspress'); ?></h2>
            <p><?php esc_html_e('The page you were looking for doesn\'t exist. Try searching or browse our latest news.','newspress'); ?></p>
            <?php get_search_form(); ?>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="np-btn" style="display:inline-block;margin-top:1rem;"><?php esc_html_e('← Back to Home','newspress'); ?></a>
        </section>
    </div>
</div>
<?php get_footer(); ?>
